'use strict';
const { REST, Routes, Collection, SlashCommandBuilder } = require('discord.js');
const { V10CommandService } = require('../features/v10/command-service');

class CommandHandler {
  constructor(client) {
    this.client = client;
    this.client.commands = new Collection();
    const legacy = [
      new SlashCommandBuilder().setName('pay').setDescription('💸 Chuyển King xu cho người chơi (Admin Bot)'),
      new SlashCommandBuilder().setName('thumon').setDescription('📤 Tạo panel Bán Money (Admin Bot)').addStringOption(o => o.setName('stock').setDescription('📦 Stock Money, ví dụ 100m').setRequired(true)).addStringOption(o => o.setName('rt_1m').setDescription('💰 RT / 1M, ví dụ 50').setRequired(true)),
      new SlashCommandBuilder().setName('banmon').setDescription('🛒 Tạo panel Mua Money (Admin Bot)').addStringOption(o => o.setName('stock').setDescription('📦 Stock Money, ví dụ 100m').setRequired(true)).addStringOption(o => o.setName('rt_1m').setDescription('💰 RT / 1M, ví dụ 50').setRequired(true)),
      new SlashCommandBuilder().setName('upstock').setDescription('📦 Cộng thêm stock cho panel bằng Message ID').addStringOption(o => o.setName('message_id').setDescription('🆔 Message ID của panel Mua/Bán').setRequired(true)).addStringOption(o => o.setName('stock').setDescription('📦 Stock cộng thêm').setRequired(true)).addStringOption(o => o.setName('rt_1m').setDescription('💰 RT / 1M mới').setRequired(false)),
      new SlashCommandBuilder().setName('status').setDescription('📡 Kiểm tra trạng thái hệ thống (Admin Bot)'),
      new SlashCommandBuilder().setName('checkbot').setDescription('🤖 Kiểm tra bot Minecraft (Admin Bot)'),
      new SlashCommandBuilder().setName('thongke').setDescription('📊 Xem thống kê giao dịch (Admin Bot)'),
      new SlashCommandBuilder().setName('bdsd').setDescription('📈 Xem biến động Pay (Admin Bot)'),
      new SlashCommandBuilder().setName('lichsu').setDescription('📜 Xem lịch sử hệ thống (Admin Bot)')
    ];
    const v10 = V10CommandService.buildCommands();
    this.commandsData = [...legacy, ...v10].map(x => x.toJSON());
    const names = this.commandsData.map(x => String(x.name));
    if (new Set(names).size !== names.length) throw new Error(`Duplicate slash command detected: ${names.join(', ')}`);
    this.commandManifestHash = require('crypto').createHash('sha256').update(JSON.stringify(this.commandsData)).digest('hex').slice(0, 20);
  }

  loadCommands() {
    for (const command of this.commandsData) console.log(`[CommandHandler] Loaded /${command.name}`);
  }

  getCommandNames() { return this.commandsData.map(x => `/${x.name}`); }
  getManifest() { return { version: 10, count: this.commandsData.length, names: this.getCommandNames(), hash: this.commandManifestHash }; }

  async registerSlashCommands(token, clientId, cleanupGuildId = '') {
    if (!token || !clientId) throw new Error('Thiếu DISCORD_TOKEN hoặc CLIENT_ID.');
    const rest = new REST({ version: '10' }).setToken(token);
    const body = this.commandsData;
    if (cleanupGuildId) {
      await rest.put(Routes.applicationGuildCommands(clientId, cleanupGuildId), { body });
      console.log(`[CommandHandler] ✅ V10 registered ${body.length} command(s) in guild ${cleanupGuildId} • manifest=${this.commandManifestHash}`);
      return;
    }
    await rest.put(Routes.applicationCommands(clientId), { body });
    console.log(`[CommandHandler] ✅ V10 registered ${body.length} global command(s) • manifest=${this.commandManifestHash}`);
  }
}

module.exports = CommandHandler;
