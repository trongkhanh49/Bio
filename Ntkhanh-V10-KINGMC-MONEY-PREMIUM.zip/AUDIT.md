# Ntkhanh Bot — Full Audit & Fix Report (v5)

## Phạm vi

Đã rà lại toàn bộ source có trong bản Bot-Ntkhanh-fixed-v4 và thực hiện thêm một vòng audit từ lỗi cú pháp, cấu hình, state persistence, concurrency/race-condition, HTTP, Discord interaction, Minecraft action, AutoBank, Pay idempotency đến Spigot wrapper.

Không có source mới nào được thêm chỉ để làm demo. Các file legacy được giữ khi có khả năng người dùng còn tham chiếu tới chúng, nhưng entrypoint runtime chính vẫn là `index.js`.

## Lỗi đã phát hiện và đã sửa

### CRITICAL

1. **API worker có thể bị mở nếu quên `WORKER_SECRET`**
   - Đã bắt buộc secret cho mọi `/api/*`; thiếu secret thì process worker/MC dừng ngay từ startup.
   - So sánh secret bằng `crypto.timingSafeEqual` sau khi kiểm tra độ dài.

2. **Race-condition giữa các Minecraft action dùng state chung**
   - Các action `balance/stats/order/ah/leaderboard/bounty/online/pay` đều dùng guard `currentAction/targetPlayer`.
   - Listener và timeout được cleanup khi success/fail/throw.

3. **`getBalance()` có thể bỏ lỡ phản hồi server rất nhanh**
   - Listener `messagestr` được gắn trước khi gọi `/balance`.

4. **Pay có nguy cơ chuyển tiền trùng khi timeout/reconnect/restart**
   - Thêm journal persistent `data/pay_operations.json`.
   - Mỗi Pay có operation ID; `success` trả lại kết quả cũ, `started/unknown` không tự gửi lại.

5. **HTTP timeout của Pay có thể không phản ánh kết quả thật của Minecraft**
   - Timeout/reconnect sau khi lệnh Pay có thể đã gửi được đánh dấu `payOutcomeUnknown`.
   - Không tự động coi đây là Pay thất bại và không tự retry mù.

6. **Race stock: hai người có thể cùng giữ vượt stock**
   - Khóa toàn bộ chuỗi kiểm tra khả dụng → giữ stock → tạo order.

7. **Crash giữa lúc trừ stock và ghi state**
   - Có `stockDeductionIntent` gồm `baseStock/amount/targetStock`.
   - Startup reconcile lại state; nếu stock đã ở target thì hoàn tất trạng thái mà không trừ lần hai.
   - Nếu stock thực tế không khớp cả base lẫn target thì chuyển `manual_review` thay vì đoán.

8. **Lỗi history log có thể làm thao tác state chính bị báo thất bại**
   - `history.json` là audit log phụ; lỗi ghi history không còn làm fail tạo/cập nhật/xóa order/panel.
   - Nếu cả history và backup hỏng, file lỗi được cô lập và tạo history mới để hệ thống chính tiếp tục chạy.

9. **Duplicate AutoBank có thể chạm cùng order trong lúc xử lý async**
   - `processing` lock ở order và `scanning/emittedAt/acknowledged` ở AutoBank.

### HIGH

10. **Chat Minecraft có thể bị giả mạo bằng player chat**
    - Proof phải là message hệ thống phù hợp, có bot name + amount + cụm từ thành công; các dạng `<Player> ...`/`Player: ...` bị loại.

11. **Một message có thể khớp nhiều đơn cùng amount**
    - Chỉ tự match khi xác định được đúng buyer hoặc chỉ có duy nhất một ứng viên.
    - Ambiguous proof bị bỏ qua để Admin xử lý, không giao/hoàn tiền nhầm.

12. **Message cũ có thể hoàn tất order mới**
    - Order lưu `awaitSinceAt`; chat trước mốc này không được dùng làm proof.

13. **Reservation pending có thể giữ stock vô hạn**
    - TTL mặc định 30 phút cho `pending_confirm`.
    - Chỉ trạng thái trước xác nhận mới bị expire; không dùng TTL để xóa đơn đã liên quan đến tiền thật.

14. **Admin confirm/reject/pay có race-condition**
    - Dùng `processing` lock.
    - Interaction được defer trước các thao tác async.
    - Hủy/confirm kiểm tra lại state mới nhất trước khi ghi.

15. **Ticket double-click có thể tạo 2 channel**
    - Thêm `ticketProcessing` lock.
    - Nếu state save thất bại sau khi tạo channel, channel orphan được rollback.

16. **HTTP body không giới hạn đúng theo byte khi dùng UTF-8**
    - `readBody()` kiểm tra `content-length` và tổng số byte thực tế của chunks, tối đa 20 KB.

17. **Worker notify có thể treo vô hạn**
    - Timeout 5 giây và destroy request khi quá hạn.

18. **HTTP Worker trả JSON lỗi nhưng code vẫn cố parse như bình thường**
    - Parse có kiểm soát; JSON lỗi/HTTP lỗi được chuyển thành error rõ ràng.

19. **AutoBank nhận nhầm giao dịch tiền ra hoặc giao dịch không xác định chiều**
    - Chỉ nhận các direction/type tiền vào đã biết hoặc creditAmount rõ ràng.
    - Unknown direction fail-closed.

20. **`bank` có thể start dù endpoint cấu hình sai**
    - Validate URL tại constructor; `start()` không chạy khi `configError` tồn tại.

21. **Stock lookup với dữ liệu số hỏng có thể tạo kết quả sai**
    - `getReservedStock/getAvailableStock` fail-closed với số không an toàn.

22. **Pay result state có thể bị lưu sai khi persistence lỗi**
    - Nếu Minecraft đã phản hồi nhưng Pay journal/state không ghi được, kết quả được chuyển thành unknown/manual review; không auto retry.

23. **Wrapper thiếu node_modules nhưng vẫn có thể restart Node liên tục**
    - Wrapper kiểm tra `discord.js`, `mineflayer`, `dotenv` trước khi tạo subprocess; thiếu thì disable plugin với thông báo rõ.

24. **ProcessMonitor có thể coi crash nhanh là lần chạy ổn định**
    - Crash counter chỉ reset khi process thực sự sống ít nhất 60 giây.
    - Giới hạn 5 crash liên tiếp để tránh vòng restart CPU.

25. **Log reader có thể đọc nhầm process sau restart**
    - Mỗi reader giữ reference tới đúng `Process` child được tạo.

26. **Stop wrapper có thể bỏ subprocess nếu process không chịu exit**
    - `destroy()` trước, sau 3 giây dùng `destroyForcibly()` trong daemon thread.

### MEDIUM / LOW / MAINTENANCE

27. **Body JSON quá lớn hoặc JSON hỏng trước đây có thể gây reject không kiểm soát**
    - Có `settled` guard và mã lỗi `BODY_TOO_LARGE`/`INVALID_JSON`.

28. **`/api/chat?since=` không hợp lệ**
    - Trả HTTP 400 thay vì tự chuyển giá trị sai thành 0.

29. **`/api/pay` không có requestId hợp lệ**
    - Bắt buộc `requestId` đúng format để idempotency luôn có khóa ổn định.

30. **AutoBank query `rows` có thể bị nhân đôi/ghép sai URL**
    - Dùng `URL` + `searchParams.set()`.

31. **AutoBank status response có nhiều kiểu biểu diễn**
    - Chấp nhận các trạng thái success rõ ràng (`success`, `true`, `1`, `ok`) và fail-closed với trạng thái khác.

32. **State JSON hỏng có thể làm mất dữ liệu bằng cách fallback về rỗng**
    - `store` dùng backup `.bak`, atomic temp+rename và phục hồi bản backup hợp lệ.

33. **Giới hạn lịch sử order có thể vô tình xóa order đang hoạt động**
    - Chỉ prune các trạng thái terminal cũ; order active/manual review không bị cắt.

34. **Panel có thể bị xóa khỏi mảng chỉ vì vượt số lượng**
    - Không cắt panel tự động vì panel còn liên kết stock/order.

35. **Dependency/script legacy không cần thiết**
    - `package.json` chỉ giữ `discord.js`, `dotenv`, `mineflayer`; bỏ script debug không tồn tại và postinstall Puppeteer không dùng.

36. **Thiếu ENV mẫu**
    - `.env.example` bao phủ toàn bộ `process.env.*` được dùng trực tiếp trong source (41 biến).

37. **Render master thiếu quyền Pay Admin**
    - Thêm `PAY_ADMIN_IDS`.

38. **Source legacy có thể bị chạy nhầm entrypoint**
    - `discord-bot.js` được chuyển thành compatibility shim; `index.js` là entrypoint chính.
    - Các file `commands/*.js` chỉ là wrapper tương thích cho service hiện tại.

39. **Minecraft version hard-code**
    - Chuyển sang `MC_VERSION`, mặc định `1.20.1`, và wrapper truyền `minecraft-bot.version`.

40. **AFK GUI click có thể thao tác khi window chưa mở**
    - Kiểm tra `currentWindow`, `slots` và retry thay vì click mù.

41. **RTP có thể đánh dấu READY trước khi click thành công**
    - Chỉ set READY sau khi click thành công; nếu GUI lỗi thì retry.

42. **Leaderboard/Bounty có thể chờ full 10 dòng vô hạn**
    - Có partial settle sau khi nhận được kết quả hợp lệ nhưng chưa đủ 10 dòng, đồng thời vẫn có hard timeout.

## Kiểm thử cuối

### Static

- Toàn bộ `.js` trong source: `node --check` — **PASS**.
- Toàn bộ `.json`: parse bằng Python `json` — **PASS**.
- `spigot-wrapper` YAML — **PASS**.
- 41 biến `process.env.*` được dùng trực tiếp đều có trong `.env.example` — **PASS**.

### Runtime/behavioral với stub

Để không giả vờ có kết nối Discord/Minecraft thật trong môi trường audit, các test runtime dùng stub cho dependency/API:

- Concurrent stock reservation — **PASS**.
- Player-chat payment spoof — **PASS**.
- Genuine unique game payment proof — **PASS**.
- Pay journal success + idempotent replay — **PASS**.
- Pay unknown outcome + retry block — **PASS**.
- AutoBank incoming/outgoing/unknown direction — **PASS**.
- Corrupt state + `.bak` recovery — **PASS**.
- History failure không làm fail state chính — **PASS**.
- HTTP `/health` — **200 PASS**.
- HTTP `/api/*` không secret — **401 PASS**.
- HTTP invalid `since` — **400 PASS**.
- HTTP Pay khi Minecraft chưa ready — **409 PASS**.
- Java wrapper compile với Bukkit API stubs — **PASS**.

## Giới hạn kiểm tra

- Không có network/dependency registry ổn định trong môi trường audit: `npm install` không thể xác nhận online vì lỗi DNS `EAI_AGAIN`.
- Không có Maven/Spigot dependency đầy đủ nên Java được compile bằng Bukkit API stubs tối thiểu, chưa phải package Maven thật.
- Chưa chạy trực tiếp Discord Gateway, Mineflayer với server Minecraft thực, VietQR, hoặc API AutoBank thật trong môi trường audit.
- Vì vậy không thể tuyên bố kiểm chứng live end-to-end; phần đó phụ thuộc token/API/server thật của hệ thống triển khai.

## File chính đã thay đổi trong vòng audit

- `index.js`
- `mc-bot.js`
- `payment/service.js`
- `payment/store.js`
- `payment/pay-operations.js`
- `autobank.js`
- `package.json`
- `.env.example`
- `render.yaml`
- `README.md`
- `discord-bot.js`
- `handlers/commandHandler.js`
- `spigot-wrapper/src/main/java/vn/kingmc/statsbot/ProcessMonitor.java`
- `spigot-wrapper/src/main/java/vn/kingmc/statsbot/StatsBotWrapper.java`
- `spigot-wrapper/src/main/resources/config.yml`

## Ghi chú triển khai bắt buộc

1. Master và Worker phải dùng cùng `WORKER_SECRET`.
2. `data/` phải nằm trên persistent disk/storage nếu cần giữ order và Pay journal sau redeploy.
3. Nếu Pay rơi vào `unknown/manual_review`, không gửi lại cùng operation bằng cách đổi ID mới trước khi xác minh trạng thái giao dịch thực tế.
4. Với server Minecraft dùng protocol khác `1.20.1`, đặt `MC_VERSION`/`minecraft-bot.version` đúng với server.

---

# V3 PLUS ADDENDUM — 2026-09-22

Bản hiện tại tiếp tục giữ nguyên đúng **10 slash command** và không thêm command mới. Đã bổ sung/làm cứng các lớp cache, token-bucket rate-limit, priority queue, resource pool, structured logger, metrics và message guard.

### Bổ sung nổi bật
- `core/cache.js`: TTL/LRU + stale-while-revalidate + single-flight.
- `core/rateLimiter.js`: token bucket cho interaction/HTTP/renderer/AutoBank.
- `core/taskQueue.js`: priority/concurrency/dedupe/overload protection.
- `core/resourcePool.js`: giới hạn tạo resource đồng thời, waiter timeout, shutdown dispose.
- `core/logger.js`: JSONL + redaction + rotation, không để lỗi log làm sập business flow.
- `core/messageGuard.js`: Unicode normalization, fingerprint, anti-link/phishing/mass-mention/repetition và đọc `sensitive_words.json`.
- `payment/service.js`: status/checkbot cache, stats trong `/checkbot`, DM queue, HTTP/interaction rate limit, graceful shutdown, chat poll lifecycle.
- `mc-bot.js`: pay queue ưu tiên, dedupe/idempotency, chat buffer clamp, stats cache, metrics và structured log.
- `payment/qr.js`: validation dữ liệu QR chặt hơn.
- `index.js`: HTTP rate limit, checkbot+stats API, queued worker notify và graceful shutdown.

### Verification
- `node --check` toàn bộ `.js`: PASS.
- JSON parse toàn bộ `.json`: PASS.
- Smoke tests core: PASS.
- Command manifest đầu vào/đầu ra: **10/10 unchanged**.
- GIF encoder output được ImageMagick nhận dạng hợp lệ.

Live Discord/Minecraft/AutoBank/VietQR chưa được chạy trong audit vì môi trường đóng gói không chứa credential/server thật.

# V10 SUPER ADDENDUM — 2026-09-22

## Command manifest

The bot now registers the following V10 groups:

- `/bot` — info, status, uptime, ping, latency, health, stats, permissions, commands
- `/server` — info, stats, channels, roles, emojis, audit, logs
- `/mc` — status, info, version, players, ping, uptime, stats, performance, resources
- `/mcworker` — list, start, stop, restart, status, reconnect, logs, console
- `/mcadmin` — command, plugins, world, backup, restore, config
- `/auto` — schedule, queue, task, recurring, history, cancel
- `/security` — anti-spam, anti-flood, anti-raid, anti-nuke, anti-webhook, anti-link, anti-invite, anti-mention, anti-command, rate-limit, protection-status
- `/backup` — create, restore, list, delete, schedule, status
- `/logs` — discord, minecraft, bot, errors, warnings, security, worker, export
- `/system` — health, resources, cache, database, modules, dependencies, reload, maintenance
- `/user` — sold, bought, orders, stats

Legacy Money commands remain registered for compatibility.

## User isolation

`/user` filters by the current interaction user ID and only accepts Money order types `thu` and `ban`. It does not expose `pay`, premium listings or other users' order data.

## V10 systems

All ten requested large systems have implementation modules or runtime integration: monitoring, worker management, reconnect control, queues/jobs, verbose logging, config management, scheduling, authenticated API bridge, backup/recovery and global error-boundary handling.

## Security

Twenty security flags are persisted in `data/v10-config.json`, with runtime detection for spam/flood/raid candidates, destructive mass-action thresholds, bot additions, webhook changes, mentions, links/invites and token/secret patterns. High-risk messages can be deleted with `SECURITY_AUTO_DELETE=1`. Anti-nuke detection does not perform irreversible mass remediation automatically.

## Packaging verification

- JavaScript syntax check: PASS for all source `.js` files.
- JSON parse: PASS for all `.json` files.
- Existing smoke test: PASS (`SMOKE_OK`).
- V10 command manifest test: PASS (11 requested V10 groups).
- User ledger isolation test: PASS.
- Final archive check: pending final packaging only.

## Live-service limitation

No claim is made that Discord Gateway, real Minecraft protocol, VietQR or bank provider live calls were executed in this packaging environment. Those checks depend on deployment credentials, external network and the actual server.
