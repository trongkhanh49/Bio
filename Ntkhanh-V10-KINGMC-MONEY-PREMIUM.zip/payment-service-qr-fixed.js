'use strict';
/**
 * Compatibility shim. Bản QR cũ từng là một PaymentService thứ hai và có thể
 * làm lệch state/command khi deployment import nhầm file. Giữ module path cũ
 * nhưng route toàn bộ sang PaymentService nâng cấp duy nhất.
 */
const PaymentService = require('./payment/service');
class PaymentServiceQrFixed extends PaymentService {}
module.exports = PaymentServiceQrFixed;
