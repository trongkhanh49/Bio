'use strict';
const fs = require('fs');
const path = require('path');
const { StructuredLogger } = require('./logger');

class PersistentJson {
  constructor(file, fallback, options = {}) {
    this.file = path.resolve(file);
    this.backupFile = `${this.file}.bak`;
    this.fallback = fallback;
    this.logger = options.logger || new StructuredLogger({ name: `store-${path.basename(this.file, '.json')}`, dir: path.join(path.dirname(this.file), 'logs') });
    this.maxHistory = Number(options.maxHistory) || 10000;
    fs.mkdirSync(path.dirname(this.file), { recursive: true });
  }

  cloneFallback() {
    return this.fallback && typeof this.fallback === 'object' ? JSON.parse(JSON.stringify(this.fallback)) : this.fallback;
  }

  read() {
    if (!fs.existsSync(this.file)) {
      const initial = this.cloneFallback();
      this.write(initial, { backup: false });
      return initial;
    }
    try {
      return JSON.parse(fs.readFileSync(this.file, 'utf8'));
    } catch (error) {
      try {
        const restored = JSON.parse(fs.readFileSync(this.backupFile, 'utf8'));
        this.write(restored, { backup: false });
        void this.logger.warn('Persistent JSON restored from backup', { file: this.file, error: error?.message });
        return restored;
      } catch (backupError) {
        const corrupt = `${this.file}.corrupt-${Date.now()}`;
        try { fs.renameSync(this.file, corrupt); } catch {}
        const fresh = this.cloneFallback();
        this.write(fresh, { backup: false });
        void this.logger.error('Persistent JSON corrupt; fresh state created', { file: this.file, corrupt, error: error?.message, backupError: backupError?.message });
        return fresh;
      }
    }
  }

  write(value, options = {}) {
    const tmp = `${this.file}.${process.pid}.${Date.now()}.tmp`;
    if (options.backup !== false && fs.existsSync(this.file)) {
      const backupTmp = `${this.backupFile}.${process.pid}.${Date.now()}.tmp`;
      try { fs.copyFileSync(this.file, backupTmp); fs.renameSync(backupTmp, this.backupFile); } catch {} finally { try { if (fs.existsSync(backupTmp)) fs.unlinkSync(backupTmp); } catch {} }
    }
    fs.writeFileSync(tmp, JSON.stringify(value, null, 2), 'utf8');
    fs.renameSync(tmp, this.file);
    return value;
  }
}

module.exports = { PersistentJson };
