'use strict';
const path = require('path');
const { TaskQueue } = require('./taskQueue');
const { StructuredLogger } = require('./logger');

class JobSystem {
  constructor(options = {}) {
    this.logger = new StructuredLogger({ name: 'jobs', dir: path.join(process.cwd(), 'data', 'logs') });
    this.queue = new TaskQueue({ name: 'v10-jobs', concurrency: Math.max(1, Number(options.concurrency) || 2), maxPending: Math.max(50, Number(options.maxPending) || 1000) });
    this.jobs = new Map();
    for (const event of ['queued', 'start', 'finish']) this.queue.on(event, payload => void this.logger.debug(`JobQueue ${event}`, payload));
  }

  submit(name, task, meta = {}, options = {}) {
    const id = `${String(name || 'JOB').toUpperCase()}-${Date.now()}-${Math.random().toString(36).slice(2, 8).toUpperCase()}`;
    this.jobs.set(id, { id, name, status: 'queued', createdAt: new Date().toISOString(), meta });
    const promise = this.queue.enqueue(async () => {
      this.jobs.get(id).status = 'running';
      this.jobs.get(id).startedAt = new Date().toISOString();
      try {
        const result = await task();
        this.jobs.get(id).status = 'completed';
        this.jobs.get(id).result = result;
        return result;
      } catch (error) {
        this.jobs.get(id).status = 'failed';
        this.jobs.get(id).error = error?.message || String(error);
        throw error;
      } finally {
        this.jobs.get(id).finishedAt = new Date().toISOString();
        void this.logger.info('Job finished', this.jobs.get(id));
      }
    }, { priority: options.priority || 0, dedupeKey: options.dedupeKey || '', meta: { name, id } });
    promise.catch(() => {});
    return { id, promise };
  }

  get(id) { return this.jobs.get(String(id)) || null; }
  history(limit = 100) { return [...this.jobs.values()].slice(-Math.max(1, Math.min(1000, Number(limit) || 100))).reverse(); }
  snapshot() { return { queue: this.queue.snapshot(), jobCount: this.jobs.size, recent: this.history(10) }; }
}

module.exports = { JobSystem };
