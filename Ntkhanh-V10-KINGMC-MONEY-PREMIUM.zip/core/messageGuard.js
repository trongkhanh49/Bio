'use strict';
const crypto = require('crypto');
const fs = require('fs');
const path = require('path');

// Không dùng /g cho các regex kiểm tra boolean: RegExp global giữ lastIndex và
// có thể khiến cùng một tin nhắn lúc đúng lúc sai khi được xử lý liên tiếp.
const CHAT_RISK_PATTERNS = [
  { code: 'mass_mention', re: /@everyone|@here/i, severity: 'high' },
  { code: 'discord_invite', re: /(?:https?:\/\/)?(?:www\.)?(?:discord\.gg|discord(?:app)?\.com\/invite)\/[a-z0-9-]+/i, severity: 'high' },
  { code: 'telegram_link', re: /(?:https?:\/\/)?(?:www\.)?t\.me\/[a-z0-9_+\/-]+/i, severity: 'high' },
  { code: 'credential_bait', re: /(?:free|giveaway|quà|gift).{0,80}(?:nitro|gift|login|password|mat khau|dang nhap)/i, severity: 'high' },
  { code: 'phishing_protocol', re: /(?:javascript:|data:text\/html|vbscript:)/i, severity: 'critical' }
];
const PLAYER_PREFIX = /^(?:<[^>]{1,32}>\s*|[A-Za-z0-9_]{3,16}\s*[»>:]\s*)/;
const AUTH_WORDS = /\b(?:login|register|dang nhap|dang ky)\b/i;
const PAYMENT_WORDS = /(?:pay|paid|sent|da chuyen|chuyen thanh cong|thanh cong|money)/i;
const REPEAT_PATTERN = /(.)\1{10,}/u;
const CONTROL_PATTERN = /[\u0000-\u001f\u007f]/g;
const URL_PATTERN = /(?:https?:\/\/|www\.)[^\s]{6,}/i;

let sensitiveConfig = null;
try {
  const file = path.join(process.cwd(), 'config', 'sensitive_words.json');
  if (fs.existsSync(file)) sensitiveConfig = JSON.parse(fs.readFileSync(file, 'utf8'));
} catch {}
const SENSITIVE_WORDS = Array.isArray(sensitiveConfig?.badWords)
  ? sensitiveConfig.badWords.map(v => normalizeLite(v)).filter(Boolean).slice(0, 500)
  : [];

function normalizeLite(value) {
  return String(value || '')
    .normalize('NFD')
    .replace(/[\u0300-\u036f]/g, '')
    .replace(/Đ/g, 'D').replace(/đ/g, 'd')
    .replace(/\s+/g, ' ')
    .trim()
    .toLowerCase();
}

function normalizeMinecraftText(value) {
  return String(value || '')
    .normalize('NFKC')
    .replace(/\u200B|\u200C|\u200D|\uFEFF/g, '')
    .normalize('NFD')
    .replace(/[\u0300-\u036f]/g, '')
    .replace(/Đ/g, 'D').replace(/đ/g, 'd')
    .replace(CONTROL_PATTERN, ' ')
    .replace(/[ \t\r\n]+/g, ' ')
    .trim();
}

function fingerprint(text) {
  return crypto.createHash('sha1').update(normalizeMinecraftText(text).toLowerCase()).digest('hex');
}

function inspectMinecraftMessage(raw, meta = {}) {
  const text = normalizeMinecraftText(raw);
  const lower = text.toLowerCase();
  const playerChat = Boolean(meta.isPlayerChat) || PLAYER_PREFIX.test(text);
  const riskHits = CHAT_RISK_PATTERNS.filter(rule => rule.re.test(text)).map(rule => rule.code);
  const repeated = REPEAT_PATTERN.test(text);
  const urlLike = URL_PATTERN.test(text);
  const sensitiveHits = sensitiveConfig?.enabled
    ? SENSITIVE_WORDS.filter(word => word.length >= 3 && lower.includes(word)).slice(0, 12)
    : [];
  const suspicious = riskHits.length > 0;
  const highRisk = riskHits.some(code => ['mass_mention', 'discord_invite', 'telegram_link', 'credential_bait', 'phishing_protocol'].includes(code)) || repeated;
  const authPrompt = AUTH_WORDS.test(lower);
  const paymentLike = PAYMENT_WORDS.test(lower);
  const serverLike = !playerChat && !suspicious;
  return {
    text,
    lower,
    fingerprint: fingerprint(text),
    playerChat,
    suspicious,
    highRisk,
    riskHits,
    repeated,
    urlLike,
    sensitiveHits,
    sensitive: sensitiveHits.length > 0,
    authPrompt,
    paymentLike,
    serverLike,
    source: String(meta.source || 'unknown'),
    receivedAt: Date.now()
  };
}

function clampChatBuffer(buffer, max = 1500) {
  if (!Array.isArray(buffer)) return [];
  return buffer.slice(-Math.max(10, Number(max) || 1500));
}

module.exports = { normalizeMinecraftText, fingerprint, inspectMinecraftMessage, clampChatBuffer };
