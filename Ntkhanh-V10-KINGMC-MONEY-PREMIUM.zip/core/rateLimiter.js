'use strict';

class TokenBucketLimiter {
  constructor(options = {}) {
    this.capacity = Math.max(1, Number(options.capacity) || 10);
    this.refillPerSecond = Math.max(0.01, Number(options.refillPerSecond) || 1);
    this.maxKeys = Math.max(100, Number(options.maxKeys) || 5000);
    this.map = new Map();
    this.denied = 0;
  }

  _refill(bucket, now) {
    const elapsed = Math.max(0, now - bucket.updatedAt) / 1000;
    bucket.tokens = Math.min(this.capacity, bucket.tokens + elapsed * this.refillPerSecond);
    bucket.updatedAt = now;
  }

  consume(key, cost = 1) {
    const k = String(key || 'anonymous');
    const amount = Math.max(0.01, Number(cost) || 1);
    const now = Date.now();
    let bucket = this.map.get(k);
    if (!bucket) {
      bucket = { tokens: this.capacity, updatedAt: now, hits: 0 };
      this.map.set(k, bucket);
    }
    this._refill(bucket, now);
    bucket.hits++;

    if (bucket.tokens >= amount) {
      bucket.tokens -= amount;
      this._trim();
      return { allowed: true, remaining: bucket.tokens, retryAfterMs: 0 };
    }

    this.denied++;
    const missing = amount - bucket.tokens;
    const retryAfterMs = Math.ceil((missing / this.refillPerSecond) * 1000);
    this._trim();
    return { allowed: false, remaining: Math.max(0, bucket.tokens), retryAfterMs };
  }

  assert(key, cost = 1, message = 'Bạn thao tác quá nhanh, vui lòng thử lại sau.') {
    const result = this.consume(key, cost);
    if (!result.allowed) {
      const error = new Error(`${message} (${Math.ceil(result.retryAfterMs / 1000)}s)`);
      error.code = 'RATE_LIMITED';
      error.retryAfterMs = result.retryAfterMs;
      throw error;
    }
    return result;
  }

  reset(key) { this.map.delete(String(key)); }

  _trim() {
    if (this.map.size <= this.maxKeys) return;
    const entries = [...this.map.entries()].sort((a, b) => a[1].updatedAt - b[1].updatedAt);
    const remove = Math.max(1, this.map.size - this.maxKeys);
    for (const [key] of entries.slice(0, remove)) this.map.delete(key);
  }

  snapshot() {
    return {
      keys: this.map.size,
      denied: this.denied,
      capacity: this.capacity,
      refillPerSecond: this.refillPerSecond
    };
  }
}

module.exports = { TokenBucketLimiter };
