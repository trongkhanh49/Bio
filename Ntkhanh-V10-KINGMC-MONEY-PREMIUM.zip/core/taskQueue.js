'use strict';
const { EventEmitter } = require('events');

/** Priority queue async. Dedupe key chống cùng một thao tác bị submit nhiều lần. */
class TaskQueue extends EventEmitter {
  constructor(options = {}) {
    super();
    this.name = String(options.name || 'queue');
    this.concurrency = Math.max(1, Number(options.concurrency) || 1);
    this.maxPending = Math.max(this.concurrency, Number(options.maxPending) || 100);
    this.items = [];
    this.running = 0;
    this.sequence = 0;
    this.dedupe = new Map();
    this.completed = 0;
    this.failed = 0;
    this.rejected = 0;
  }

  get size() { return this.items.length; }
  get active() { return this.running; }

  enqueue(task, options = {}) {
    if (typeof task !== 'function') throw new TypeError('TaskQueue cần một function.');
    const key = options.dedupeKey ? String(options.dedupeKey) : '';
    if (key && this.dedupe.has(key)) return this.dedupe.get(key);
    if (this.items.length + this.running >= this.maxPending) {
      this.rejected++;
      const error = new Error(`Hàng đợi ${this.name} đang quá tải.`);
      error.code = 'QUEUE_OVERLOADED';
      throw error;
    }

    const priority = Number.isFinite(Number(options.priority)) ? Number(options.priority) : 0;
    const item = {
      id: ++this.sequence,
      priority,
      createdAt: Date.now(),
      run: task,
      key,
      meta: options.meta || {},
      resolve: null,
      reject: null
    };
    const promise = new Promise((resolve, reject) => {
      item.resolve = resolve;
      item.reject = reject;
    });
    if (key) this.dedupe.set(key, promise);
    this.items.push(item);
    this.items.sort((a, b) => b.priority - a.priority || a.createdAt - b.createdAt || a.id - b.id);
    this.emit('queued', this.snapshot());
    this._drain();
    return promise;
  }

  _drain() {
    while (this.running < this.concurrency && this.items.length) {
      const item = this.items.shift();
      this.running++;
      this.emit('start', { ...this.snapshot(), itemId: item.id });
      Promise.resolve().then(item.run).then(result => {
        this.completed++;
        item.resolve(result);
        this.emit('finish', { ...this.snapshot(), itemId: item.id, ok: true });
      }).catch(error => {
        this.failed++;
        item.reject(error);
        this.emit('finish', { ...this.snapshot(), itemId: item.id, ok: false, error: error?.message || String(error) });
      }).finally(() => {
        this.running = Math.max(0, this.running - 1);
        if (item.key) this.dedupe.delete(item.key);
        this._drain();
      });
    }
  }

  clear(error = null) {
    const err = error || new Error(`Hàng đợi ${this.name} bị dừng.`);
    err.code ||= 'QUEUE_CLEARED';
    const pending = this.items.splice(0);
    for (const item of pending) {
      if (item.key) this.dedupe.delete(item.key);
      item.reject(err);
    }
    return pending.length;
  }

  snapshot() {
    return {
      name: this.name,
      waiting: this.items.length,
      running: this.running,
      concurrency: this.concurrency,
      maxPending: this.maxPending,
      completed: this.completed,
      failed: this.failed,
      rejected: this.rejected,
      head: this.items[0] ? { id: this.items[0].id, priority: this.items[0].priority, ageMs: Date.now() - this.items[0].createdAt, ...this.items[0].meta } : null
    };
  }
}

module.exports = { TaskQueue };
