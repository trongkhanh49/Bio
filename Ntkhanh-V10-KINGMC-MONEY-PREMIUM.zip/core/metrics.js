'use strict';

class MetricsRegistry {
  constructor() {
    this.startedAt = Date.now();
    this.counters = new Map();
    this.timers = new Map();
    this.gauges = new Map();
  }

  inc(name, value = 1, labels = {}) {
    const key = this._key(name, labels);
    this.counters.set(key, (this.counters.get(key) || 0) + (Number(value) || 0));
  }

  set(name, value, labels = {}) {
    this.gauges.set(this._key(name, labels), Number(value) || 0);
  }

  observe(name, ms, labels = {}) {
    const key = this._key(name, labels);
    const current = this.timers.get(key) || { count: 0, totalMs: 0, maxMs: 0, minMs: Infinity };
    const n = Math.max(0, Number(ms) || 0);
    current.count++;
    current.totalMs += n;
    current.maxMs = Math.max(current.maxMs, n);
    current.minMs = Math.min(current.minMs, n);
    this.timers.set(key, current);
  }

  timed(name, labels = {}) {
    const started = Date.now();
    return () => this.observe(name, Date.now() - started, labels);
  }

  async measure(name, task, labels = {}) {
    const end = this.timed(name, labels);
    try { return await task(); }
    finally { end(); }
  }

  _key(name, labels) {
    const pairs = Object.entries(labels || {}).sort(([a], [b]) => a.localeCompare(b)).map(([k, v]) => `${k}=${String(v)}`);
    return pairs.length ? `${name}{${pairs.join(',')}}` : String(name);
  }

  snapshot() {
    const counters = Object.fromEntries(this.counters.entries());
    const gauges = Object.fromEntries(this.gauges.entries());
    const timings = {};
    for (const [key, value] of this.timers.entries()) {
      timings[key] = {
        ...value,
        avgMs: value.count ? Number((value.totalMs / value.count).toFixed(2)) : 0,
        minMs: Number.isFinite(value.minMs) ? value.minMs : 0
      };
    }
    return { uptimeMs: Date.now() - this.startedAt, counters, gauges, timings };
  }
}

module.exports = { MetricsRegistry };
