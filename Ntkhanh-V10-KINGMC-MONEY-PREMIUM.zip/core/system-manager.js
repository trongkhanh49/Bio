'use strict';
const os = require('os');
const path = require('path');
const { EventEmitter } = require('events');
const { MetricsRegistry } = require('./metrics');
const { StructuredLogger } = require('./logger');
const { ConfigManager } = require('./config-manager');

const SYSTEMS = [
  ['botHealth', 'Bot Health & Monitoring System'],
  ['workerManager', 'Minecraft Worker Manager'],
  ['autoReconnect', 'Auto Reconnect System'],
  ['queueJob', 'Queue & Job System'],
  ['advancedLogging', 'Advanced Logging System'],
  ['configManagement', 'Config Management System'],
  ['scheduler', 'Scheduler / Automation System'],
  ['webApiBridge', 'Web/API Bridge System'],
  ['backupRecovery', 'Backup & Recovery System'],
  ['globalErrorRecovery', 'Global Error Recovery System']
];

class SystemManager extends EventEmitter {
  constructor(options = {}) {
    super();
    this.config = options.config || new ConfigManager();
    this.metrics = options.metrics || new MetricsRegistry();
    this.logger = options.logger || new StructuredLogger({ name: 'system', dir: path.join(process.cwd(), 'data', 'logs') });
    this.client = options.client || null;
    this.localMcBot = options.localMcBot || null;
    this.startedAt = Date.now();
    this.heartbeat = null;
    this.lastSnapshot = null;
    this.jobQueue = null;
    this.scheduler = null;
  }

  attach({ client, localMcBot, jobQueue, scheduler } = {}) {
    if (client) this.client = client;
    if (localMcBot) this.localMcBot = localMcBot;
    if (jobQueue) this.jobQueue = jobQueue;
    if (scheduler) this.scheduler = scheduler;
  }

  start() {
    this.config.load();
    if (this.heartbeat) clearInterval(this.heartbeat);
    this.heartbeat = setInterval(() => this.collect(), 5000);
    this.heartbeat.unref?.();
    this.collect();
    void this.logger.info('V10 System Manager started', { systems: this.list() });
  }

  stop() { if (this.heartbeat) clearInterval(this.heartbeat); this.heartbeat = null; }

  collect() {
    const mem = process.memoryUsage();
    const cpus = os.cpus();
    const snapshot = {
      at: new Date().toISOString(),
      uptimeMs: Date.now() - this.startedAt,
      node: process.version,
      platform: `${process.platform}/${process.arch}`,
      pid: process.pid,
      cpu: { count: cpus.length, load1m: os.loadavg()[0] },
      memory: { rss: mem.rss, heapUsed: mem.heapUsed, heapTotal: mem.heapTotal, external: mem.external, arrayBuffers: mem.arrayBuffers },
      discord: this.client ? { ready: Boolean(this.client.isReady?.()), guilds: this.client.guilds?.cache?.size || 0, user: this.client.user?.tag || null, wsPing: this.client.ws?.ping ?? null } : null,
      minecraft: this.localMcBot?.getStatusSnapshot?.() || null,
      queue: this.jobQueue?.snapshot?.() || null,
      scheduler: this.scheduler?.snapshot?.() || null,
      enabledSystems: this.config.snapshot().systems
    };
    this.lastSnapshot = snapshot;
    this.metrics.set('process_rss_bytes', mem.rss);
    this.metrics.set('process_heap_used_bytes', mem.heapUsed);
    this.metrics.set('cpu_load_1m', os.loadavg()[0]);
    this.emit('heartbeat', snapshot);
    return snapshot;
  }

  list() {
    const cfg = this.config.config?.systems || {};
    return SYSTEMS.map(([key, name]) => ({ key, name, enabled: cfg[key] !== false }));
  }

  toggle(key, enabled) { return this.config.setSystem(key, enabled); }
  health() { return this.lastSnapshot || this.collect(); }
  resources() { const s = this.health(); return { cpu: s.cpu, memory: s.memory, node: s.node, platform: s.platform, pid: s.pid }; }
  status() { return { version: 10, maintenance: Boolean(this.config.config?.maintenance), systems: this.list(), health: this.health(), metrics: this.metrics.snapshot() }; }
}

module.exports = { SystemManager, SYSTEMS };
