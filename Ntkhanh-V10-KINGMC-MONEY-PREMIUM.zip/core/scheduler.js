'use strict';
const fs = require('fs');
const path = require('path');
const { PersistentJson } = require('./persistent-json');
const { StructuredLogger } = require('./logger');

class SchedulerService {
  constructor(options = {}) {
    this.store = new PersistentJson(path.join(process.cwd(), 'data', 'schedules.json'), { schedules: [], history: [] });
    this.logger = new StructuredLogger({ name: 'scheduler', dir: path.join(process.cwd(), 'data', 'logs') });
    this.handlers = new Map();
    this.timer = null;
    this.startedAt = null;
    this.owner = options.owner || null;
  }

  register(name, handler) { this.handlers.set(String(name), handler); }

  start() {
    if (this.timer) clearInterval(this.timer);
    this.startedAt = Date.now();
    this.timer = setInterval(() => void this.tick(), 5000);
    this.timer.unref?.();
    void this.tick();
    void this.logger.info('Scheduler started', { schedules: this.list().length });
  }

  stop() { if (this.timer) clearInterval(this.timer); this.timer = null; }

  list() { return this.store.read().schedules || []; }
  history() { return (this.store.read().history || []).slice(-500).reverse(); }

  create(input = {}) {
    const data = this.store.read();
    const entry = {
      id: `${String(input.name || 'TASK').replace(/[^A-Za-z0-9_-]/g, '_')}-${Date.now()}`,
      name: String(input.name || 'task'),
      intervalMs: Math.max(5000, Number(input.intervalMs) || 60000),
      enabled: input.enabled !== false,
      nextRunAt: Date.now() + Math.max(5000, Number(input.delayMs) || Number(input.intervalMs) || 60000),
      payload: input.payload || {},
      createdAt: new Date().toISOString(),
      createdBy: input.createdBy || null,
      runs: 0,
      failures: 0
    };
    data.schedules.push(entry);
    data.history.push({ at: new Date().toISOString(), action: 'schedule_created', id: entry.id, name: entry.name });
    data.history = data.history.slice(-5000);
    this.store.write(data);
    void this.logger.info('Schedule created', entry);
    return entry;
  }

  cancel(id) {
    const data = this.store.read();
    const index = data.schedules.findIndex(x => String(x.id) === String(id));
    if (index < 0) return null;
    const [removed] = data.schedules.splice(index, 1);
    data.history.push({ at: new Date().toISOString(), action: 'schedule_cancelled', id: removed.id });
    data.history = data.history.slice(-5000);
    this.store.write(data);
    void this.logger.info('Schedule cancelled', { id: removed.id });
    return removed;
  }

  async tick() {
    const data = this.store.read();
    let changed = false;
    for (const schedule of data.schedules) {
      if (!schedule.enabled || Number(schedule.nextRunAt) > Date.now()) continue;
      schedule.runs = Number(schedule.runs || 0) + 1;
      schedule.lastRunAt = new Date().toISOString();
      schedule.nextRunAt = Date.now() + Math.max(5000, Number(schedule.intervalMs) || 60000);
      changed = true;
      const handler = this.handlers.get(schedule.name);
      if (!handler) {
        schedule.failures = Number(schedule.failures || 0) + 1;
        data.history.push({ at: new Date().toISOString(), action: 'schedule_no_handler', id: schedule.id, name: schedule.name });
        continue;
      }
      try {
        await handler(schedule.payload, schedule);
        data.history.push({ at: new Date().toISOString(), action: 'schedule_run', id: schedule.id, name: schedule.name, ok: true });
        void this.logger.info('Schedule executed', { id: schedule.id, name: schedule.name });
      } catch (error) {
        schedule.failures = Number(schedule.failures || 0) + 1;
        data.history.push({ at: new Date().toISOString(), action: 'schedule_run', id: schedule.id, name: schedule.name, ok: false, error: error?.message || String(error) });
        void this.logger.error('Schedule execution failed', { id: schedule.id, name: schedule.name, error: error?.message || String(error) });
      }
    }
    if (changed) {
      data.history = data.history.slice(-5000);
      this.store.write(data);
    }
  }

  snapshot() { return { running: Boolean(this.timer), startedAt: this.startedAt ? new Date(this.startedAt).toISOString() : null, schedules: this.list().length, next: this.list().sort((a, b) => Number(a.nextRunAt) - Number(b.nextRunAt)).slice(0, 5) }; }
}

module.exports = { SchedulerService };
