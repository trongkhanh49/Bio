'use strict';
const { EventEmitter } = require('events');

/**
 * Resource pool có giới hạn tạo đồng thời, waiter timeout và shutdown an toàn.
 * Dùng cho các tài nguyên nặng như Puppeteer browser/page hoặc client ngoài.
 */
class ResourcePool extends EventEmitter {
  constructor(factory, options = {}) {
    super();
    if (typeof factory !== 'function') throw new TypeError('ResourcePool cần factory function.');
    this.factory = factory;
    this.dispose = typeof options.dispose === 'function' ? options.dispose : null;
    this.size = Math.max(1, Number(options.size) || 1);
    this.acquireTimeoutMs = Math.max(250, Number(options.acquireTimeoutMs) || 30000);
    this.idle = [];
    this.busy = new Set();
    this.waiters = [];
    this.creating = 0;
    this.created = 0;
    this.closed = false;
  }

  async _create() {
    if (this.closed) throw new Error('ResourcePool đã đóng.');
    if (this.busy.size + this.creating >= this.size) throw new Error('ResourcePool đạt giới hạn resource.');
    this.creating++;
    try {
      const resource = await this.factory();
      this.created++;
      if (this.closed) {
        if (this.dispose) await Promise.resolve().then(() => this.dispose(resource)).catch(() => {});
        throw new Error('ResourcePool đã đóng trong lúc tạo resource.');
      }
      return resource;
    } finally {
      this.creating = Math.max(0, this.creating - 1);
    }
  }

  async acquire(timeoutMs = this.acquireTimeoutMs) {
    if (this.closed) throw new Error('ResourcePool đã đóng.');
    if (this.idle.length) {
      const resource = this.idle.pop();
      this.busy.add(resource);
      this.emit('acquire', this.snapshot());
      return resource;
    }

    if (this.busy.size + this.creating < this.size) {
      const resource = await this._create();
      this.busy.add(resource);
      this.emit('acquire', this.snapshot());
      return resource;
    }

    return new Promise((resolve, reject) => {
      let settled = false;
      let timer = null;
      const waiter = {
        resolve: value => {
          if (settled) return;
          settled = true;
          if (timer) clearTimeout(timer);
          resolve(value);
        },
        reject: error => {
          if (settled) return;
          settled = true;
          if (timer) clearTimeout(timer);
          reject(error);
        }
      };
      timer = setTimeout(() => {
        const index = this.waiters.indexOf(waiter);
        if (index >= 0) this.waiters.splice(index, 1);
        const error = new Error('ResourcePool timeout.');
        error.code = 'RESOURCE_TIMEOUT';
        waiter.reject(error);
      }, Math.max(250, Number(timeoutMs) || this.acquireTimeoutMs));
      this.waiters.push(waiter);
      this.emit('wait', this.snapshot());
    });
  }

  release(resource) {
    if (!resource) return;
    if (!this.busy.delete(resource)) return;
    if (this.closed) return;

    const waiter = this.waiters.shift();
    if (waiter) {
      this.busy.add(resource);
      waiter.resolve(resource);
    } else {
      this.idle.push(resource);
    }
    this.emit('release', this.snapshot());
  }

  async use(task, timeoutMs = this.acquireTimeoutMs) {
    const resource = await this.acquire(timeoutMs);
    try {
      return await task(resource);
    } finally {
      this.release(resource);
    }
  }

  async close(dispose = null) {
    this.closed = true;
    for (const waiter of this.waiters.splice(0)) waiter.reject(new Error('ResourcePool đã đóng.'));

    const resources = [...this.idle, ...this.busy];
    this.idle.length = 0;
    this.busy.clear();
    const disposer = typeof dispose === 'function' ? dispose : this.dispose;
    if (disposer) {
      await Promise.all(resources.map(resource => Promise.resolve().then(() => disposer(resource)).catch(() => {})));
    }
    this.emit('close', this.snapshot());
  }

  snapshot() {
    return {
      size: this.size,
      created: this.created,
      creating: this.creating,
      idle: this.idle.length,
      busy: this.busy.size,
      waiting: this.waiters.length,
      closed: this.closed
    };
  }
}

module.exports = { ResourcePool };
