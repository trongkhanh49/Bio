'use strict';
const fs = require('fs');
const path = require('path');
const EventEmitter = require('events');
const { StructuredLogger } = require('./logger');

const DEFAULTS = {
  version: 10,
  maintenance: false,
  logLevel: process.env.LOG_LEVEL || 'debug',
  systems: {
    botHealth: true,
    workerManager: true,
    autoReconnect: true,
    queueJob: true,
    advancedLogging: true,
    configManagement: true,
    scheduler: true,
    webApiBridge: true,
    backupRecovery: true,
    globalErrorRecovery: true
  },
  security: {
    antiSpam: true,
    antiFlood: true,
    antiRaid: true,
    antiNuke: true,
    antiMassBan: true,
    antiMassKick: true,
    antiMassRoleDelete: true,
    antiMassChannelDelete: true,
    antiMassChannelCreate: true,
    antiMassRoleCreate: true,
    antiBotAdd: true,
    antiWebhookAbuse: true,
    antiMentionSpam: true,
    antiLinkSpam: true,
    antiInviteSpam: true,
    antiTokenSecretLeak: true,
    antiCommandSpam: true,
    antiMcConnectionSpam: true,
    antiWorkerAbuse: true,
    rateLimit: true
  }
};

class ConfigManager extends EventEmitter {
  constructor(file = path.join(process.cwd(), 'data', 'v10-config.json')) {
    super();
    this.file = path.resolve(file);
    this.logger = new StructuredLogger({ name: 'config', dir: path.join(process.cwd(), 'data', 'logs') });
    this.config = null;
    this.lastReloadAt = null;
  }

  merge(base, override) {
    if (Array.isArray(base) || Array.isArray(override)) return override ?? base;
    if (base && typeof base === 'object' && override && typeof override === 'object') {
      const out = { ...base };
      for (const [k, v] of Object.entries(override)) out[k] = this.merge(out[k], v);
      return out;
    }
    return override ?? base;
  }

  ensure() {
    fs.mkdirSync(path.dirname(this.file), { recursive: true });
    if (!fs.existsSync(this.file)) {
      fs.writeFileSync(this.file, JSON.stringify(DEFAULTS, null, 2), 'utf8');
    }
  }

  load() {
    this.ensure();
    let parsed = {};
    try { parsed = JSON.parse(fs.readFileSync(this.file, 'utf8')); }
    catch (error) {
      const backup = `${this.file}.bak`;
      try { parsed = JSON.parse(fs.readFileSync(backup, 'utf8')); }
      catch { parsed = {}; }
      void this.logger.error('Config parse failed; fallback applied', { file: this.file, error: error?.message });
    }
    this.config = this.merge(DEFAULTS, parsed);
    this.lastReloadAt = new Date().toISOString();
    this.emit('reload', this.snapshot());
    void this.logger.info('Configuration loaded', { version: this.config.version, maintenance: this.config.maintenance, systems: this.config.systems });
    return this.config;
  }

  save() {
    this.ensure();
    const tmp = `${this.file}.${process.pid}.${Date.now()}.tmp`;
    const backup = `${this.file}.bak`;
    if (fs.existsSync(this.file)) try { fs.copyFileSync(this.file, backup); } catch {}
    fs.writeFileSync(tmp, JSON.stringify(this.config, null, 2), 'utf8');
    fs.renameSync(tmp, this.file);
    this.emit('change', this.snapshot());
    void this.logger.info('Configuration saved', { version: this.config.version });
    return this.config;
  }

  snapshot() {
    return {
      version: Number(this.config?.version || 10),
      maintenance: Boolean(this.config?.maintenance),
      logLevel: this.config?.logLevel || 'debug',
      systems: { ...(this.config?.systems || {}) },
      security: { ...(this.config?.security || {}) },
      lastReloadAt: this.lastReloadAt
    };
  }

  reload() { return this.load(); }
  isEnabled(name) { return this.config?.systems?.[name] !== false; }
  setSystem(name, enabled) {
    if (!this.config) this.load();
    if (!Object.prototype.hasOwnProperty.call(this.config.systems, name)) throw new Error(`System không tồn tại: ${name}`);
    this.config.systems[name] = Boolean(enabled);
    this.save();
    return this.snapshot();
  }

  setSecurity(name, enabled) {
    if (!this.config) this.load();
    if (!Object.prototype.hasOwnProperty.call(this.config.security, name)) throw new Error(`Security module không tồn tại: ${name}`);
    this.config.security[name] = Boolean(enabled);
    this.save();
    return this.snapshot();
  }
}

module.exports = { ConfigManager, DEFAULTS };
