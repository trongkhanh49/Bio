'use strict';

/**
 * Tiny in-process TTL/LRU cache with stale-while-revalidate support.
 * Không giữ Promise lỗi trong cache và có single-flight để nhiều user cùng
 * gọi một resource chỉ tạo 1 request mạng.
 */
class TTLCache {
  constructor(options = {}) {
    this.max = Math.max(10, Number(options.max) || 1000);
    this.ttlMs = Math.max(250, Number(options.ttlMs) || 30_000);
    this.staleMs = Math.max(0, Number(options.staleMs) || 0);
    this.name = String(options.name || 'cache');
    this.map = new Map();
    this.inflight = new Map();
    this.hits = 0;
    this.misses = 0;
    this.evictions = 0;
  }

  _now() { return Date.now(); }

  _touch(key, item) {
    this.map.delete(key);
    this.map.set(key, item);
  }

  _trim() {
    while (this.map.size > this.max) {
      const first = this.map.keys().next().value;
      if (first === undefined) break;
      this.map.delete(first);
      this.evictions++;
    }
  }

  get(key, options = {}) {
    const k = String(key);
    const item = this.map.get(k);
    if (!item) {
      this.misses++;
      return options.meta ? { hit: false, value: undefined, stale: false } : undefined;
    }

    const age = this._now() - item.createdAt;
    const fresh = age <= item.ttlMs;
    const stale = !fresh && age <= item.ttlMs + item.staleMs;
    if (!fresh && !stale) {
      this.map.delete(k);
      this.misses++;
      return options.meta ? { hit: false, value: undefined, stale: false } : undefined;
    }

    this.hits++;
    this._touch(k, item);
    return options.meta ? { hit: true, value: item.value, stale } : item.value;
  }

  set(key, value, ttlMs = this.ttlMs, staleMs = this.staleMs) {
    const k = String(key);
    this.map.set(k, {
      value,
      createdAt: this._now(),
      ttlMs: Math.max(250, Number(ttlMs) || this.ttlMs),
      staleMs: Math.max(0, Number(staleMs) || this.staleMs)
    });
    this._trim();
    return value;
  }

  delete(key) {
    return this.map.delete(String(key));
  }

  clear() {
    this.map.clear();
    this.inflight.clear();
  }

  async getOrSet(key, loader, options = {}) {
    const k = String(key);
    const hit = this.get(k, { meta: true });
    if (hit.hit && !hit.stale) return hit.value;

    const previous = hit.value;
    if (hit.stale && previous !== undefined && options.revalidate === true) {
      void this._singleFlight(k, loader, options).catch(() => {});
      return previous;
    }
    return this._singleFlight(k, loader, options);
  }

  async _singleFlight(key, loader, options = {}) {
    if (this.inflight.has(key)) return this.inflight.get(key);
    const run = Promise.resolve().then(loader).then(value => {
      if (value !== undefined && value !== null) {
        this.set(key, value, options.ttlMs, options.staleMs);
      }
      return value;
    }).finally(() => this.inflight.delete(key));
    this.inflight.set(key, run);
    return run;
  }

  stats() {
    return {
      name: this.name,
      size: this.map.size,
      max: this.max,
      hits: this.hits,
      misses: this.misses,
      hitRate: this.hits + this.misses ? Number((this.hits / (this.hits + this.misses)).toFixed(4)) : 0,
      inflight: this.inflight.size,
      evictions: this.evictions
    };
  }
}

module.exports = { TTLCache };
