'use strict';
const fs = require('fs');
const path = require('path');

const SECRET_KEYS = /token|password|secret|authorization|cookie|api[_-]?key|private[_-]?key/i;

function redact(value, depth = 0) {
  if (depth > 6) return '[MAX_DEPTH]';
  if (value === null || value === undefined) return value;
  if (typeof value === 'string') {
    return value
      .replace(/(Bearer\s+)[A-Za-z0-9._-]+/gi, '$1[REDACTED]')
      .replace(/(token|password|secret|authorization|api[_-]?key)\s*[:=]\s*[^\s,;]+/gi, '$1=[REDACTED]')
      .slice(0, 4000);
  }
  if (Array.isArray(value)) return value.slice(0, 100).map(v => redact(v, depth + 1));
  if (typeof value === 'object') {
    const out = {};
    for (const [key, child] of Object.entries(value).slice(0, 100)) out[key] = SECRET_KEYS.test(key) ? '[REDACTED]' : redact(child, depth + 1);
    return out;
  }
  return value;
}

class StructuredLogger {
  constructor(options = {}) {
    this.dir = path.resolve(options.dir || path.join(process.cwd(), 'data', 'logs'));
    this.name = String(options.name || 'bot');
    this.level = String(options.level || process.env.LOG_LEVEL || 'info').toLowerCase();
    this.queue = Promise.resolve();
    this.maxBytes = Math.max(256 * 1024, Number(options.maxBytes) || Number(process.env.LOG_MAX_BYTES) || 20 * 1024 * 1024);
    this.sessionId = `${process.pid}-${Date.now().toString(36)}-${Math.random().toString(36).slice(2, 8)}`;
    fs.mkdirSync(this.dir, { recursive: true });
  }

  _levelWeight(level) { return ({ debug: 10, info: 20, warn: 30, error: 40, fatal: 50 }[level] || 20); }
  _date() { return new Date().toISOString().slice(0, 10); }
  _file() { return path.join(this.dir, `${this.name}-${this._date()}.jsonl`); }
  _should(level) { return this._levelWeight(level) >= this._levelWeight(this.level); }

  log(level, message, meta = {}) {
    const normalized = String(level || 'info').toLowerCase();
    if (!this._should(normalized)) return Promise.resolve(false);
    const entry = {
      at: new Date().toISOString(),
      level: normalized,
      logger: this.name,
      pid: process.pid,
      sessionId: this.sessionId,
      host: require('os').hostname(),
      message: String(message || '').slice(0, 8000),
      meta: redact(meta)
    };
    const line = JSON.stringify(entry) + '\n';
    this.queue = this.queue.then(() => this._append(line), () => this._append(line));
    return this.queue.then(() => true, () => false);
  }

  async _append(line) {
    const file = this._file();
    try {
      const stat = fs.existsSync(file) ? fs.statSync(file) : null;
      if (stat && stat.size + Buffer.byteLength(line) > this.maxBytes) {
        const archive = file.replace(/\.jsonl$/, `-${Date.now()}.jsonl`);
        try { fs.renameSync(file, archive); } catch {}
      }
      fs.appendFileSync(file, line, 'utf8');
    } catch (error) {
      // Không throw log lỗi ngược vào business flow.
      try { console.error('[StructuredLogger]', error?.message || error); } catch {}
    }
  }

  debug(message, meta) { return this.log('debug', message, meta); }
  info(message, meta) { return this.log('info', message, meta); }
  warn(message, meta) { return this.log('warn', message, meta); }
  error(message, meta) { return this.log('error', message, meta); }
  fatal(message, meta) { return this.log('fatal', message, meta); }
}

module.exports = { StructuredLogger, redact };
