'use strict';

function escapeHtml(value) {
  return String(value ?? '')
    .replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;').replace(/'/g, '&#039;');
}

function formatVnd(value) {
  return `${Math.round(Number(value) || 0).toLocaleString('vi-VN')}đ`;
}

function premiumCardTemplate(listing, options = {}) {
  const skin = escapeHtml(listing.skinPreviewUrl || listing.skinUrl || '');
  const avatar = escapeHtml(listing.avatarUrl || `https://mc-heads.net/avatar/${encodeURIComponent(listing.username)}/256.png`);
  const cape = listing.capeUrl
    ? `<img class="cape" src="${escapeHtml(listing.capeUrl)}" alt="Minecraft cape">`
    : `<div class="empty">NO CAPE DETECTED</div>`;
  const theme = escapeHtml(options.theme || 'KINGMC');
  const timestamp = escapeHtml(new Date(listing.createdAt || Date.now()).toLocaleString('vi-VN'));

  return `<!doctype html>
<html lang="vi">
<head>
<meta charset="utf-8"><meta name="viewport" content="width=1600, initial-scale=1">
<title>${escapeHtml(listing.username)} • ${theme}</title>
<style>
:root{--bg:#070a12;--panel:rgba(255,255,255,.075);--line:rgba(255,255,255,.12);--text:#f4f7fb;--muted:#98a4b7;--accent:#8b5cf6;--accent2:#22d3ee}
*{box-sizing:border-box}html,body{margin:0;padding:0;background:radial-gradient(1000px 600px at 20% -10%,rgba(139,92,246,.34),transparent 60%),radial-gradient(900px 600px at 100% 100%,rgba(34,211,238,.22),transparent 58%),var(--bg);color:var(--text);font-family:Inter,Segoe UI,Arial,sans-serif}body{width:1600px;min-height:1000px;padding:54px;display:flex;justify-content:center;align-items:center}
.shell{width:1490px;min-height:900px;padding:44px;border:1px solid var(--line);border-radius:42px;background:linear-gradient(145deg,rgba(25,31,48,.8),rgba(9,13,23,.9));backdrop-filter:blur(28px);box-shadow:0 40px 120px rgba(0,0,0,.58),inset 0 1px rgba(255,255,255,.05)}
.top{display:flex;justify-content:space-between;align-items:center;gap:30px}.brand{letter-spacing:4px;font-weight:900;font-size:19px;color:#d7dcf0}.badge{padding:12px 18px;border-radius:999px;border:1px solid rgba(255,255,255,.13);background:rgba(255,255,255,.06);font-weight:800;font-size:14px;letter-spacing:1px}.hero{display:flex;align-items:center;gap:22px;margin-top:22px}.avatar{width:72px;height:72px;border-radius:22px;object-fit:cover;background:#0b1020;border:1px solid var(--line);box-shadow:0 10px 30px rgba(0,0,0,.35)}.title{font-size:66px;line-height:1;font-weight:950;letter-spacing:-2px}.sub{margin-top:9px;color:var(--muted);font-size:18px}.grid{display:grid;grid-template-columns:1.03fr .97fr;gap:24px;margin-top:34px}.panel{border:1px solid var(--line);border-radius:30px;background:var(--panel);padding:26px;box-shadow:inset 0 1px rgba(255,255,255,.04)}.rows{display:grid;gap:2px}.row{display:flex;justify-content:space-between;gap:24px;padding:17px 0;border-bottom:1px solid rgba(255,255,255,.08)}.row:last-child{border-bottom:0}.label{color:var(--muted);font-size:16px}.value{font-size:23px;font-weight:850;text-align:right;word-break:break-word}.price{font-size:37px}.note{margin-top:22px;padding:20px;border-radius:22px;background:rgba(0,0,0,.22);border:1px solid rgba(255,255,255,.07);line-height:1.6;font-size:17px;color:#dfe7f4}.visuals{display:grid;grid-template-columns:1fr 1fr;gap:18px}.visual{min-height:500px;padding:18px;border-radius:24px;background:rgba(0,0,0,.18);border:1px solid rgba(255,255,255,.08);display:flex;flex-direction:column;justify-content:center;align-items:center;overflow:hidden}.visual h3{width:100%;margin:0 0 14px;color:#aeb8cb;letter-spacing:2px;font-size:13px}.skin{width:100%;height:420px;object-fit:contain;filter:drop-shadow(0 25px 25px rgba(0,0,0,.35));}.cape{width:100%;height:420px;object-fit:contain;image-rendering:auto}.empty{display:flex;align-items:center;justify-content:center;height:420px;color:#68738a;letter-spacing:2px;font-weight:800}.bottom{display:flex;justify-content:space-between;gap:20px;margin-top:23px;padding-top:18px;border-top:1px solid rgba(255,255,255,.07);color:#738097;font-size:13px}.glow{position:absolute;inset:auto 0 0 0;height:160px;background:linear-gradient(transparent,rgba(139,92,246,.11));pointer-events:none}
</style></head><body><div class="shell"><div class="top"><div class="brand">${theme} • PREMIUM MARKET</div><div class="badge">VERIFIED MINECRAFT PROFILE</div></div>
<div class="hero"><img class="avatar" src="${avatar}" alt="Avatar"><div><div class="title">${escapeHtml(listing.username)}</div><div class="sub">Minecraft Premium Account • ${escapeHtml(listing.skinModel || 'classic')} model • UUID ${escapeHtml(listing.uuidFormatted || listing.uuid || 'N/A')}</div></div></div>
<div class="grid"><div class="panel"><div class="rows"><div class="row"><div class="label">Giá bán</div><div class="value price">${escapeHtml(formatVnd(listing.price))}</div></div><div class="row"><div class="label">Cape</div><div class="value">${escapeHtml(listing.capeName || (listing.capeUrl ? 'Detected' : 'Không có'))}</div></div><div class="row"><div class="label">Skin Model</div><div class="value">${escapeHtml(listing.skinModel || 'classic')}</div></div><div class="row"><div class="label">UUID</div><div class="value">${escapeHtml(listing.uuidFormatted || 'N/A')}</div></div></div><div class="note"><strong>Ghi chú</strong><br>${escapeHtml(listing.note || 'Không có ghi chú.')}</div></div>
<div class="visuals"><div class="visual"><h3>3D BODY PREVIEW</h3><img class="skin" src="${skin}" alt="Minecraft skin body"></div><div class="visual"><h3>CAPE PREVIEW</h3>${cape}</div></div></div>
<div class="bottom"><span>Profile xác minh qua Minecraft profile/session services.</span><span>${timestamp}</span></div><div class="glow"></div></div></body></html>`;
}

function spinFrameTemplate(listing, angleDeg = 0) {
  const skin = escapeHtml(listing.skinPreviewUrl || listing.skinUrl || '');
  const avatar = escapeHtml(listing.avatarUrl || `https://mc-heads.net/avatar/${encodeURIComponent(listing.username)}/256.png`);
  return `<!doctype html><html><head><meta charset="utf-8"><style>
html,body{margin:0;width:760px;height:760px;background:transparent;overflow:hidden;font-family:Inter,Segoe UI,Arial,sans-serif}.stage{width:760px;height:760px;position:relative;display:flex;align-items:center;justify-content:center}.halo{position:absolute;width:560px;height:560px;border-radius:50%;background:radial-gradient(circle,rgba(139,92,246,.28),rgba(34,211,238,.06) 55%,transparent 70%);filter:blur(3px)}.card{position:absolute;inset:24px;border-radius:42px;border:1px solid rgba(255,255,255,.13);background:linear-gradient(145deg,rgba(24,31,50,.94),rgba(6,10,18,.94));box-shadow:0 30px 80px rgba(0,0,0,.48),inset 0 1px rgba(255,255,255,.06);display:flex;flex-direction:column;align-items:center;justify-content:center}.avatar{width:64px;height:64px;border-radius:18px;object-fit:cover;border:1px solid rgba(255,255,255,.11);margin-bottom:10px}.name{font-size:28px;font-weight:900;margin-bottom:10px}.price{font-size:20px;color:#cbd4e5;margin-bottom:20px}.viewport{width:540px;height:520px;display:flex;align-items:center;justify-content:center;perspective:1200px}.spin{width:430px;height:430px;object-fit:contain;transform:rotateY(${Number(angleDeg)||0}deg) scaleX(.92);filter:drop-shadow(0 30px 30px rgba(0,0,0,.55))}.shine{position:absolute;inset:0;background:linear-gradient(120deg,transparent 30%,rgba(255,255,255,.06) 50%,transparent 70%);pointer-events:none}</style></head><body><div class="stage"><div class="halo"></div><div class="card"><img class="avatar" src="${avatar}"><div class="name">${escapeHtml(listing.username)}</div><div class="price">${escapeHtml(formatVnd(listing.price))}</div><div class="viewport"><img class="spin" src="${skin}"></div><div class="shine"></div></div></div></body></html>`;
}

module.exports = { escapeHtml, premiumCardTemplate, spinFrameTemplate, formatVnd };
