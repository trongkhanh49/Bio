const { EventEmitter } = require('events');
const path = require('path');
const { TTLCache } = require('./core/cache');
const { TokenBucketLimiter } = require('./core/rateLimiter');
const { StructuredLogger } = require('./core/logger');

function toNumber(value) {
  if (typeof value === 'number') return Number.isFinite(value) ? value : 0;
  const raw = String(value ?? '').trim().replace(/\s+/g, '');
  if (!raw) return 0;
  const cleaned = raw.replace(/[^0-9.,-]/g, '');
  if (!cleaned || cleaned === '-') return 0;
  if (/^-?\d{1,3}(\.\d{3})+(,\d+)?$/.test(cleaned)) return Number(cleaned.replace(/\./g, '').replace(',', '.')) || 0;
  if (/^-?\d{1,3}(,\d{3})+(\.\d+)?$/.test(cleaned)) return Number(cleaned.replace(/,/g, '')) || 0;
  return Number(cleaned.replace(/,/g, '')) || 0;
}

function pickDescription(tx) {
  return [
    tx?.description,
    tx?.content,
    tx?.transactionContent,
    tx?.transferContent,
    tx?.remark,
    tx?.memo,
    tx?.addInfo,
    tx?.narrative,
    tx?.reference
  ].filter(Boolean).map(String).join(' ').trim();
}

function pickTransactions(payload) {
  const candidates = [
    payload?.transactions,
    payload?.data?.transactions,
    payload?.data?.records,
    payload?.data,
    payload?.results,
    payload?.records
  ];
  for (const value of candidates) if (Array.isArray(value)) return value;
  return [];
}

function getTransactionId(raw) {
  return String(
    raw?.transactionID ?? raw?.transactionId ?? raw?.transaction_id ?? raw?.referencenumber ?? raw?.referenceNumber ?? raw?.id ?? ''
  ).trim();
}

function transactionFingerprint(raw) {
  const amount = getAmount(raw);
  const description = pickDescription(raw);
  const date = raw?.transactionDate ?? raw?.date ?? raw?.createdAt ?? raw?.time ?? '';
  return `fp:${amount}|${String(description).trim().toUpperCase()}|${String(date).trim()}`;
}

function getAmount(raw) {
  return toNumber(
    raw?.amount ??
    raw?.transferAmount ??
    raw?.creditAmount ??
    raw?.receivedAmount ??
    raw?.amountIn ??
    raw?.transactionAmount ??
    raw?.credit ??
    raw?.money
  );
}

function isIncoming(raw) {
  const type = String(raw?.type ?? raw?.transactionType ?? raw?.direction ?? raw?.transType ?? raw?.transferType ?? '').trim().toUpperCase();
  if (['IN', 'CREDIT', 'CR', 'DEPOSIT', 'RECEIVE', 'RECEIVED', 'CREDITED', 'TIENVAO', 'C'].includes(type)) return true;
  if (['OUT', 'DEBIT', 'DR', 'WITHDRAW', 'SEND', 'SENT', 'DEBITED', 'TIENRA', 'D'].includes(type)) return false;

  const credit = toNumber(raw?.creditAmount ?? raw?.credit ?? raw?.amountIn ?? raw?.receivedAmount);
  const debit = toNumber(raw?.debitAmount ?? raw?.debit ?? raw?.amountOut ?? raw?.spentAmount);
  if (credit > 0 && debit <= 0) return true;
  if (debit > 0 && credit <= 0) return false;
  // Khi API không chỉ rõ chiều giao dịch thì phải fail-closed: không tự coi
  // giao dịch không rõ chiều là tiền vào, tránh phát hàng/Pay nhầm.
  return false;
}

class AutoBank extends EventEmitter {
  constructor() {
    super();
    this.token = String(process.env.THUEAPIBANK_TOKEN || '').trim();
    this.interval = Math.max(1000, Number(process.env.BANK_CHECK_INTERVAL_MS) || 3000);
    this.timeoutMs = Math.max(3000, Number(process.env.BANK_API_TIMEOUT_MS) || 10000);
    this.endpoint = String(process.env.BANK_HISTORY_URL || '').trim() ||
      `https://thueapibank.vn/historyapimbbankv2/${encodeURIComponent(this.token)}`;
    this.rows = Math.min(100, Math.max(20, Number(process.env.BANK_HISTORY_ROWS) || 100));
    this.configError = null;
    try { new URL(this.endpoint); } catch (error) { this.configError = new Error(`BANK_HISTORY_URL không hợp lệ: ${String(error?.message || error)}`); }

    this.acknowledged = new Set();
    this.emittedAt = new Map();
    this.timer = null;
    this.scanning = false;
    this.payloadCache = new TTLCache({ name: 'autobank-payload', max: 2, ttlMs: Math.max(750, this.interval || 2500), staleMs: Math.max(500, (this.interval || 2500) * 2) });
    this.emitLimiter = new TokenBucketLimiter({ capacity: Math.max(5, Number(process.env.AUTOBANK_EMIT_BURST) || 30), refillPerSecond: Math.max(0.1, Number(process.env.AUTOBANK_EMIT_RATE) || 10), maxKeys: 20000 });
    this.logger = new StructuredLogger({ name: 'autobank', dir: path.join(process.cwd(), 'data', 'logs') });
  }

  start() {
    if (this.timer || this.configError) return;
    void this.scan();
    this.timer = setInterval(() => void this.scan(), this.interval);
  }

  stop() {
    if (this.timer) clearInterval(this.timer);
    this.timer = null;
  }

  ackTransaction(id) {
    const key = String(id || '').trim();
    if (!key) return;
    this.acknowledged.add(key);
    this.emittedAt.delete(key);
    if (this.acknowledged.size > 10000) {
      this.acknowledged = new Set([...this.acknowledged].slice(-5000));
    }
  }

  async fetchPayload() {
    const controller = new AbortController();
    const timer = setTimeout(() => controller.abort(), this.timeoutMs);
    try {
      const requestUrl = new URL(this.endpoint);
      requestUrl.searchParams.set('rows', String(this.rows));
      const response = await fetch(requestUrl, {
        headers: { accept: 'application/json', 'cache-control': 'no-cache' },
        signal: controller.signal
      });
      const text = await response.text();
      let payload = {};
      try { payload = JSON.parse(text); } catch {
        throw new Error(`AutoBank trả về dữ liệu không phải JSON (HTTP ${response.status}).`);
      }
      if (!response.ok) {
        throw new Error(String(payload?.msg || payload?.message || payload?.error || `HTTP ${response.status}`));
      }
      const status = payload?.status;
      const normalizedStatus = String(status ?? '').trim().toLowerCase();
      if (status !== undefined && !['success', 'true', '1', 'ok'].includes(normalizedStatus) && status !== true && status !== 1) {
        throw new Error(String(payload?.msg || payload?.message || 'AutoBank API trả về trạng thái không thành công.'));
      }
      return payload;
    } finally {
      clearTimeout(timer);
    }
  }

  normalizeTransaction(raw) {
    const id = getTransactionId(raw);
    const amount = getAmount(raw);
    const description = pickDescription(raw);
    const senderName = [
      raw?.senderName, raw?.fromName, raw?.payerName, raw?.customerName,
      raw?.accountName, raw?.sender, raw?.from
    ].map(v => String(v ?? '').trim()).find(Boolean) || null;
    const senderAccount = [
      raw?.senderAccount, raw?.senderAccountNumber, raw?.fromAccount,
      raw?.fromAccountNumber, raw?.payerAccount, raw?.reciprocalAccount
    ].map(v => String(v ?? '').trim()).find(Boolean) || null;
    return { ...raw, id, amount, description, senderName, senderAccount, raw };
  }

  async scan() {
    if (!this.token || this.scanning) return;
    this.scanning = true;
    try {
      const payload = await this.payloadCache.getOrSet('latest', () => this.fetchPayload(), { ttlMs: Math.max(750, this.interval || 2500), staleMs: Math.max(500, (this.interval || 2500) * 2) });
      const transactions = pickTransactions(payload);
      const now = Date.now();
      const retryAfter = Math.max(1000, this.interval);

      for (const raw of transactions) {
        const tx = this.normalizeTransaction(raw);
        if (!tx.id) tx.id = transactionFingerprint(raw);
        if (!tx.id || !Number.isSafeInteger(tx.amount) || tx.amount <= 0) continue;
        if (!isIncoming(raw)) continue;
        if (this.acknowledged.has(tx.id)) continue;

        const lastEmit = Number(this.emittedAt.get(tx.id) || 0);
        const gate = this.emitLimiter.consume(tx.id, 1);
        if (!gate.allowed) continue;
        if (now - lastEmit < retryAfter) continue;
        this.emittedAt.set(tx.id, now);

        if (process.env.DEBUG_PAYMENT === '1') {
          console.log(`[AutoBank] IN ${tx.id} +${tx.amount} | ${tx.description || 'NO_CONTENT'}${tx.senderName ? ` | ${tx.senderName}` : ''}`);
        }
        this.emit('transaction', tx);
        void this.logger.info('Incoming bank transaction', { id: tx.id, amount: tx.amount, senderName: tx.senderName, description: tx.description });
      }

      if (this.emittedAt.size > 10000) {
        const entries = [...this.emittedAt.entries()].sort((a, b) => a[1] - b[1]).slice(-5000);
        this.emittedAt = new Map(entries);
      }
    } catch (error) {
      void this.logger.error('AutoBank scan error', { error: error?.message || String(error) });
      this.emit('error', error);
    } finally {
      this.scanning = false;
    }
  }
}

module.exports = AutoBank;
