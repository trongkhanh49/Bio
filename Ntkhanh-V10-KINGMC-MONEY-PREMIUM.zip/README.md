# Ntkhanh Bot — V10 Super Edition

Discord + Minecraft Worker + Money Trade + AutoBank platform.

## V10 scope

This build keeps the existing Money payment workflow and adds a modular control plane rather than replacing the business logic.

### Discord command groups

- `/bot`: info, status, uptime, ping, latency, health, stats, permissions, commands
- `/server`: info, stats, channels, roles, emojis, audit, logs
- `/mc`: status, info, version, players, ping, uptime, stats, performance, resources
- `/mcworker`: list, start, stop, restart, status, reconnect, logs, console
- `/mcadmin`: command, plugins, world, backup, restore, config
- `/auto`: schedule, queue, task, recurring, history, cancel
- `/security`: anti-spam, anti-flood, anti-raid, anti-nuke, anti-webhook, anti-link, anti-invite, anti-mention, anti-command, rate-limit, protection-status
- `/backup`: create, restore, list, delete, schedule, status
- `/logs`: discord, minecraft, bot, errors, warnings, security, worker, export
- `/system`: health, resources, cache, database, modules, dependencies, reload, maintenance
- `/user`: sold, bought, orders, stats

The `/user` group is intentionally restricted to the user's own Money trade history: Money sold to the bot and Money bought from the bot. It does not expose other users' orders.

Legacy Money commands remain available: `/pay`, `/thumon`, `/banmon`, `/upstock`, `/status`, `/checkbot`, `/thongke`, `/bdsd`, `/lichsu`.

## Ten large systems

1. Bot Health & Monitoring System — CPU, RAM, gateway latency, uptime, worker and Minecraft connection.
2. Minecraft Worker Manager — local/remote worker registry, start/stop/restart/reconnect and log access.
3. Auto Reconnect System — persistent reconnect logic with manual-stop protection and existing Mineflayer recovery.
4. Queue & Job System — priority queue, concurrency, dedupe, overload protection and task state.
5. Advanced Logging System — JSONL logs with subsystem logger, session ID, host, PID, redaction and rotation.
6. Config Management System — persistent V10 config, module toggles and reload without source edits.
7. Scheduler / Automation System — recurring jobs with persisted schedules and history.
8. Web/API Bridge System — authenticated worker control, Minecraft command bridge, health and log APIs.
9. Backup & Recovery System — tar.gz backups with per-file SHA-256 manifest, listing, restore and deletion.
10. Global Error Recovery System — guarded interaction flow, module errors, retry-aware job processing and persistent audit trails.

## Twenty security modules

Anti-Spam, Anti-Flood, Anti-Raid, Anti-Nuke, Anti-Mass Ban, Anti-Mass Kick, Anti-Mass Role Delete, Anti-Mass Channel Delete, Anti-Mass Channel Create, Anti-Mass Role Create, Anti-Bot Add, Anti-Webhook Abuse, Anti-Mention Spam, Anti-Link Spam, Anti-Invite Spam, Anti-Token/Secret Leak, Anti-Command Spam, Anti-MC Connection Spam, Anti-Worker Abuse, Rate Limit + Cooldown Protection.

Security modules are persisted in `data/v10-config.json`. Event detections are persisted in `data/security-events.json`. High-risk message candidates can be deleted when `SECURITY_AUTO_DELETE=1`; destructive anti-nuke auto-remediation is not performed automatically.

## Money user ledger

Every Money order already stores the Discord user ID. V10 exposes a read-only personal ledger through `/user`:

- `sold`: Money the current user sold to the bot.
- `bought`: Money the current user bought from the bot.
- `orders`: all Money orders owned by the current user.
- `stats`: aggregate completed/active Money totals.

No cross-user order lookup is exposed through `/user`.

## Logging

Default V10 logging is intentionally verbose. `LOG_LEVEL=debug` and `LOG_MAX_BYTES=20971520` keep detailed JSONL logs without redacting secrets into plain text. Audit logs still use Discord embeds when `AUDIT_LOG_ENABLED=1`.

Subsystem log names include `runtime`, `system`, `config`, `jobs`, `scheduler`, `backup`, `security`, `worker-manager`, `user-trades`, `audit`, `minecraft`, `payment`, and `pay-journal`.

## Worker configuration

For multiple remote workers, set `MC_WORKERS_JSON` to a JSON array such as:

```json
[{"id":"sg-worker","label":"Singapore Worker","url":"https://worker.example.com"},{"id":"vn-worker","label":"VN Worker","url":"https://worker-vn.example.com"}]
```

The shared `WORKER_SECRET` is required for worker-control and API routes.

## Deployment

Render can keep using `node index.js`. The worker and master roles remain separated with `BOT_ROLE=master` or `BOT_ROLE=worker`.

Use a persistent disk/storage for `data/` when order history, pay journals, security events, logs and backups must survive redeploys.

## Verification in packaging environment

The package can be syntax checked without live Discord/Minecraft/AutoBank credentials. Live Gateway, live Minecraft and live bank verification still depend on deployment credentials and network access.


## KingMC Money V10

Build này tập trung vào `/thumon`, `/banmon` và `/pay` cho KingMC.vn.
- `/thumon`: tạo panel mua Money từ user; xác nhận đơn -> copy `/pay ntkhanh <amount>` trên KingMC -> bot nhận Money -> nhận QR DM -> Admin xác nhận chuyển khoản.
- `/banmon`: tạo panel bán Money cho user; xác nhận đơn -> VietQR theo mã đơn -> AutoBank đối soát đúng số tiền + nội dung -> bot tự `/pay <IGN> <amount>`.
- `/pay`: Admin-only, có Pay journal chống gửi trùng, queue 1 worker và trạng thái unknown/manual-review khi kết quả Minecraft chưa xác định.
- Stock được trừ ngay khi user tạo đơn giao dịch; nếu đơn bị hủy ở giai đoạn chưa thực hiện thì stock được hoàn trả có log.

Bản phân phối không kèm Chromium/Puppeteer/Premium Account renderer vì các thành phần này không thuộc luồng Discord + Minecraft Money của Bot Ntkhanh.
