# NTKHANH BOT — V3 PLUS UPGRADE

## Nguyên tắc
- Giữ nguyên 10 slash command hiện có.
- Không thêm slash command mới.
- Không đổi tên command, option command hoặc entrypoint chính.
- Nâng cấp nằm ở lớp xử lý, bảo mật, queue, cache, state, logging, rendering và khả năng chịu tải.

## 10 command được giữ nguyên
`/pay` · `/thumon` · `/banmon` · `/upstock` · `/status` · `/checkbot` · `/thongke` · `/bdsd` · `/lichsu`

## Core runtime
- TTL/LRU cache + stale-while-revalidate + single-flight để giảm request trùng.
- Token Bucket rate limit theo user/request/IP và các tác vụ nhạy cảm.
- Priority Task Queue với concurrency, overload protection, dedupe key và metadata.
- Resource Pool giới hạn số resource thực sự được tạo đồng thời, có waiter timeout và shutdown.
- Structured JSONL logs theo ngày, rotate theo dung lượng và redaction secret.
- Metrics counter/gauge/timing cho interaction, queue, HTTP, chat filter và payment.
- Graceful shutdown: dừng timer, worker poll, AutoBank, queue pending và renderer.

## Payment / Pay / Mua-Bán / Thu-Mua
- Pay vẫn idempotent theo request/operation ID.
- Durable journal + backup để hạn chế trả/chuyển trùng sau restart.
- Payment proof fail-closed: không lấy player chat làm bằng chứng thanh toán.
- Match đơn có buyer/amount rõ; trường hợp ambiguous không tự hoàn tất.
- Stock reservation vẫn có lock + reconcile + reservation TTL.
- Các thao tác DM được đưa qua queue để hỗ trợ nhiều user đồng thời mà không burst Discord API.
- AutoBank cache payload, chống duplicate emit, lọc hướng giao dịch không rõ và log đầy đủ.

## Checkbot + Stats
`/checkbot` vẫn là command cũ nhưng response được mở rộng với:
- Balance / balance cache.
- Minecraft online/ready, action hiện tại, action age.
- Pay queue và trạng thái xử lý.
- Worker latency.
- Chat buffer.
- AFK và last error / kick / disconnect.
- Stats từ Minecraft worker, có cache để hạn chế spam `/stats`.

## Anti / Message Guard
- Normalize Unicode NFKC/NFD, bỏ zero-width/control characters.
- Fingerprint message để dedupe.
- Phát hiện mass mention, Discord invite, Telegram link, credential bait, phishing protocol và lặp ký tự bất thường.
- Không dùng global RegExp state cho các check boolean.
- `sensitive_words.json` được load thành lớp nhận diện riêng, không tự động biến mọi từ nhạy cảm thành payment proof.


## Kiểm thử đã chạy
- `node --check` toàn bộ JavaScript: PASS.
- Parse toàn bộ JSON: PASS.
- Smoke test cache / rate-limit / queue / resource pool / anti-risk / GIF / amount parser / pay journal: PASS.
- So sánh command manifest với bản ZIP đầu vào: 10/10 command unchanged.
- Kiểm tra GIF bằng ImageMagick: PASS.

## Giới hạn
Không giả lập kết nối Gateway Discord, server Minecraft, AutoBank API hoặc account Minecraft thật khi không có credential/server thật. Vì vậy live end-to-end vẫn phụ thuộc môi trường host triển khai.
