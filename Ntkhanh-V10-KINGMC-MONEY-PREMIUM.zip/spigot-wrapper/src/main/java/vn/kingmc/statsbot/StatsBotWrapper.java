package vn.kingmc.statsbot;

import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.plugin.java.JavaPlugin;

import java.io.File;
import java.util.HashMap;
import java.util.Map;

/**
 * Lớp chính của plugin Spigot Wrapper quản lý Discord Bot ký sinh.
 */
public class StatsBotWrapper extends JavaPlugin {

    private ProcessMonitor processMonitor;
    private File botFolder;

    @Override
    public void onEnable() {
        getLogger().info("=================================================");
        getLogger().info("   BotCheckStatsWrapper đang khởi động...       ");
        getLogger().info("=================================================");

        // 1. Tạo và nạp config.yml
        saveDefaultConfig();
        FileConfiguration config = getConfig();

        // 2. Thiết lập thư mục chứa mã nguồn Node.js
        String discordToken = config.getString("discord.token", "").trim();
        String clientId = config.getString("discord.client-id", "").trim();
        if (discordToken.isEmpty() || discordToken.equalsIgnoreCase("your_discord_bot_token_here")) {
            getLogger().severe("[Init] discord.token chưa được cấu hình token Discord thật. Plugin sẽ không khởi động bot.");
            getServer().getPluginManager().disablePlugin(this);
            return;
        }
        if (clientId.isEmpty() || clientId.equalsIgnoreCase("your_discord_client_id_here")) {
            getLogger().severe("[Init] discord.client-id chưa được cấu hình Client ID thật. Plugin sẽ không khởi động bot.");
            getServer().getPluginManager().disablePlugin(this);
            return;
        }

        String botFolderName = config.getString("bot-folder", "bot");
        botFolder = new File(getDataFolder(), botFolderName);
        if (!botFolder.exists()) {
            boolean created = botFolder.mkdirs();
            if (created) {
                getLogger().info("[Init] Đã tạo thư mục bot: " + botFolder.getAbsolutePath());
            }
        }

        // Kiểm tra xem file index.js có tồn tại trong thư mục bot không
        File indexJs = new File(botFolder, "index.js");
        File packageJson = new File(botFolder, "package.json");
        if (!indexJs.exists() || !packageJson.exists()) {
            getLogger().warning("=================================================");
            getLogger().warning(" ⚠️ PHÁT HIỆN THIẾU MÃ NGUỒN NODE.JS BOT ⚠️");
            getLogger().warning(" Vui lòng sao chép các file của Discord Bot bao gồm:");
            getLogger().warning(" - index.js, mc-bot.js, package.json");
            getLogger().warning(" - và thư mục node_modules");
            getLogger().warning(" Vào thư mục sau trên Server Minecraft:");
            getLogger().warning(" " + botFolder.getAbsolutePath());
            getLogger().warning(" Sau đó, hãy khởi động lại server hoặc reload plugin.");
            getLogger().warning("=================================================");
            getServer().getPluginManager().disablePlugin(this);
            return;
        }

        File nodeModules = new File(botFolder, "node_modules");
        File discordJs = new File(nodeModules, "discord.js");
        File mineflayer = new File(nodeModules, "mineflayer");
        File dotenv = new File(nodeModules, "dotenv");
        if (!nodeModules.isDirectory() || !discordJs.exists() || !mineflayer.exists() || !dotenv.exists()) {
            getLogger().severe("=================================================");
            getLogger().severe(" ❌ THIẾU NODE_MODULES CẦN THIẾT ❌");
            getLogger().severe(" Cần có: discord.js, mineflayer, dotenv trong:");
            getLogger().severe(" " + nodeModules.getAbsolutePath());
            getLogger().severe(" Chạy 'npm install' bằng đúng phiên bản Node.js rồi chép node_modules vào thư mục bot.");
            getLogger().severe(" Wrapper sẽ không khởi chạy Node để tránh vòng restart liên tục.");
            getLogger().severe("=================================================");
            getServer().getPluginManager().disablePlugin(this);
            return;
        }

        // 3. Lấy cấu hình kiểm tra mạng
        String hostsStr = config.getString("minecraft-bot.hosts", "sgp.kingmc.vn,kingmc.vn");
        int mcPort = config.getInt("minecraft-bot.port", 25565);
        if (mcPort < 1 || mcPort > 65535) {
            getLogger().severe("[Init] Minecraft port không hợp lệ: " + mcPort);
            getServer().getPluginManager().disablePlugin(this);
            return;
        }
        String firstHost = hostsStr.split(",")[0].trim();
        if (firstHost.isEmpty()) {
            getLogger().severe("[Init] minecraft-bot.hosts không có host hợp lệ.");
            getServer().getPluginManager().disablePlugin(this);
            return;
        }

        // Kiểm tra mạng ở background để không block main server thread.
        getServer().getScheduler().runTaskAsynchronously(this, () -> {
            boolean networkOk = NetworkUtils.checkOutboundNetwork(getLogger(), firstHost, mcPort);
            if (!networkOk) {
                getLogger().warning("[NetworkCheck] Phát hiện sự cố kết nối mạng đi ngoài. Bot có thể hoạt động không ổn định.");
            }
        });

        // 4. Thu thập các biến cấu hình để truyền làm biến môi trường (Environment Variables)
        Map<String, String> envVars = new HashMap<>();
        
        // Discord Configs
        envVars.put("DISCORD_TOKEN", config.getString("discord.token", ""));
        envVars.put("CLIENT_ID", config.getString("discord.client-id", ""));
        envVars.put("GUILD_ID", config.getString("discord.guild-id", ""));
        envVars.put("ADMIN_ID", config.getString("discord.admin-id", ""));
        envVars.put("PAY_ADMIN_IDS", config.getString("discord.pay-admin-ids", ""));
        envVars.put("WORKER_SECRET", config.getString("worker.secret", ""));
        envVars.put("MASTER_URL", config.getString("worker.master-url", ""));

        // Payment Configs
        envVars.put("PAYMENT_WORKER_URL", config.getString("payment.worker-url", ""));
        envVars.put("MC_WORKER_URL", config.getString("payment.mc-worker-url", ""));
        envVars.put("THUEAPIBANK_TOKEN", config.getString("payment.thueapibank-token", ""));
        envVars.put("BANK_HISTORY_URL", config.getString("payment.bank-history-url", ""));
        envVars.put("BANK_CODE", config.getString("payment.bank-code", "MBBank"));
        envVars.put("ACCOUNT_NO", config.getString("payment.account-no", ""));
        envVars.put("ACCOUNT_NAME", config.getString("payment.account-name", ""));
        envVars.put("BANK_CHECK_INTERVAL_MS", String.valueOf(config.getInt("payment.bank-check-interval-ms", 3000)));
        envVars.put("BANK_API_TIMEOUT_MS", String.valueOf(config.getInt("payment.bank-api-timeout-ms", 10000)));
        envVars.put("BANK_HISTORY_ROWS", String.valueOf(config.getInt("payment.bank-history-rows", 100)));
        envVars.put("BANK_PAY_RETRY_MS", String.valueOf(config.getInt("payment.bank-pay-retry-ms", 5000)));
        envVars.put("PAY_TIMEOUT_MS", String.valueOf(config.getInt("payment.pay-timeout-ms", 12000)));
        envVars.put("PAY_REQUEST_TIMEOUT_MS", String.valueOf(config.getInt("payment.pay-request-timeout-ms", 15000)));
        envVars.put("WORKER_REQUEST_TIMEOUT_MS", String.valueOf(config.getInt("payment.worker-request-timeout-ms", 12000)));
        envVars.put("CHECKBOT_TIMEOUT_MS", String.valueOf(config.getInt("payment.checkbot-timeout-ms", 12000)));
        envVars.put("PAYMENT_CHAT_POLL_MS", String.valueOf(config.getInt("payment.chat-poll-ms", 1500)));
        envVars.put("PAYMENT_CHAT_REQUEST_TIMEOUT_MS", String.valueOf(config.getInt("payment.chat-request-timeout-ms", 8000)));
        envVars.put("DISCORD_OPERATION_TIMEOUT_MS", String.valueOf(config.getInt("payment.discord-operation-timeout-ms", 10000)));
        envVars.put("RESERVATION_TTL_MS", String.valueOf(config.getInt("payment.reservation-ttl-ms", 1800000)));
        envVars.put("BOT_ROLE", "standalone");

        // Minecraft Bot Configs
        envVars.put("MC_USERNAME", config.getString("minecraft-bot.username", "CheckStatsBot"));
        envVars.put("MC_AUTH_TYPE", config.getString("minecraft-bot.auth-type", "offline"));
        envVars.put("MC_PASSWORD", config.getString("minecraft-bot.password", ""));
        envVars.put("MC_SERVER_HOSTS", hostsStr);
        envVars.put("MC_SERVER_PORT", String.valueOf(mcPort));
        envVars.put("MC_VERSION", config.getString("minecraft-bot.version", "1.20.1"));

        // Wrapper không cần public HTTP port cố định; port 0 để hệ điều hành cấp cổng tạm nếu cần.
        int httpPort = config.getInt("http-port", 0);
        if (httpPort < 0 || httpPort > 65535) httpPort = 0;
        envVars.put("PORT", String.valueOf(httpPort));
        envVars.put("HTTP_REQUEST_TIMEOUT_MS", String.valueOf(config.getInt("http-request-timeout-ms", 45000)));

        // 5. Khởi tạo ProcessMonitor giám sát subprocess Node.js
        String nodePath = config.getString("node-path", "");
        String absoluteNodePath = "";
        
        if (nodePath != null && !nodePath.trim().isEmpty()) {
            File nodeFile = new File(nodePath.trim());
            if (!nodeFile.isAbsolute()) {
                // Java tự động phân giải tương đối so với thư mục chạy (user.dir)
                nodeFile = nodeFile.getAbsoluteFile();
            }
            
            if (!nodeFile.exists()) {
                getLogger().severe("=================================================");
                getLogger().severe(" ❌ KHÔNG TÌM THẤY FILE THỰC THI NODE.JS ❌");
                getLogger().severe(" Đường dẫn cấu hình: " + nodePath);
                getLogger().severe(" Đường dẫn tuyệt đối tìm kiếm: " + nodeFile.getAbsolutePath());
                getLogger().severe(" Vui lòng kiểm tra lại xem file node đã được giải nén đúng chưa!");
                getLogger().severe("=================================================");
                getServer().getPluginManager().disablePlugin(this);
                return;
            }
            
            // Cấp quyền thực thi cho file node (cực kỳ quan trọng khi chạy trên host Linux free)
            if (!nodeFile.canExecute()) {
                getLogger().info("[Init] Phát hiện file node chưa có quyền thực thi. Đang cố gắng cấp quyền...");
                boolean success = nodeFile.setExecutable(true);
                if (success) {
                    getLogger().info("[Init] ✓ Cấp quyền thực thi thành công.");
                } else {
                    getLogger().warning("[Init] ✗ Không thể cấp quyền thực thi. Bạn có thể cần tự chạy lệnh chmod +x cho file node này.");
                }
            }
            absoluteNodePath = nodeFile.getAbsolutePath();
        } else {
            absoluteNodePath = "node"; // Sử dụng node có sẵn trong hệ thống
        }

        int maxHeapMb = config.getInt("node-max-old-space-size-mb", 256);
        processMonitor = new ProcessMonitor(getLogger(), absoluteNodePath, botFolder, envVars, maxHeapMb);
        processMonitor.start();

        getLogger().info("Plugin Wrapper đã được kích hoạt và khởi chạy tiến trình giám sát bot.");
    }

    @Override
    public void onDisable() {
        getLogger().info("Đang tắt plugin Wrapper...");
        if (processMonitor != null) {
            processMonitor.stop();
            processMonitor = null;
        }
        getLogger().info("Đã tắt plugin Wrapper và giải phóng tài nguyên subprocess.");
    }
}
