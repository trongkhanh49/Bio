package vn.kingmc.statsbot;

import java.io.BufferedReader;
import java.io.File;
import java.io.IOException;
import java.io.InputStreamReader;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 * Quản lý vòng đời tiến trình con chạy Node.js bot.
 * Tự động đọc log và restart nếu tiến trình con gặp sự cố.
 */
public class ProcessMonitor implements Runnable {

    private final Logger logger;
    private final String nodePath;
    private final File botDir;
    private final Map<String, String> envVariables;
    private final int maxOldSpaceSizeMb;

    private volatile Process process;
    private volatile boolean shouldRun = true;
    private Thread monitorThread;
    private Thread stdoutThread;
    private Thread stderrThread;
    
    private int consecutiveCrashes = 0;
    private static final int MAX_CONSECUTIVE_CRASHES = 5;
    private static final long RESTART_DELAY_MS = 10000; // 10 giây
    private static final long HEALTHY_RUN_RESET_MS = 60000; // Reset crash counter nếu chạy ổn định ít nhất 60 giây

    public ProcessMonitor(Logger logger, String nodePath, File botDir, Map<String, String> envVariables) {
        this(logger, nodePath, botDir, envVariables, 256);
    }

    public ProcessMonitor(Logger logger, String nodePath, File botDir, Map<String, String> envVariables, int maxOldSpaceSizeMb) {
        this.logger = logger;
        this.nodePath = nodePath == null || nodePath.trim().isEmpty() ? "node" : nodePath.trim();
        this.botDir = botDir;
        this.envVariables = envVariables;
        this.maxOldSpaceSizeMb = Math.max(128, Math.min(maxOldSpaceSizeMb, 4096));
    }

    /**
     * Bắt đầu thread giám sát tiến trình.
     */
    public synchronized void start() {
        if (monitorThread != null && monitorThread.isAlive()) {
            return;
        }
        shouldRun = true;
        monitorThread = new Thread(this, "BotCheckStats-Monitor");
        monitorThread.start();
    }

    /**
     * Dừng tiến trình con và thread giám sát một cách cưỡng bức.
     */
    public synchronized void stop() {
        shouldRun = false;
        logger.info("[Supervisor] Đang yêu cầu dừng bot Node.js...");

        final Process child = process;
        process = null;
        if (child != null && child.isAlive()) {
            child.destroy();
            Thread killer = new Thread(() -> {
                try {
                    if (child.waitFor(3, java.util.concurrent.TimeUnit.SECONDS)) return;
                    logger.warning("[Supervisor] Tiến trình Node.js không dừng sau 3 giây. Cưỡng bức tắt...");
                    child.destroyForcibly();
                } catch (InterruptedException e) {
                    Thread.currentThread().interrupt();
                }
            }, "BotCheckStats-ProcessStopper");
            killer.setDaemon(true);
            killer.start();
        }

        if (stdoutThread != null) stdoutThread.interrupt();
        if (stderrThread != null) stderrThread.interrupt();
        if (monitorThread != null) monitorThread.interrupt();

        logger.info("[Supervisor] Đã yêu cầu dừng toàn bộ thread giám sát và subprocess con.");
    }

    @Override
    public void run() {
        while (shouldRun) {
            if (consecutiveCrashes >= MAX_CONSECUTIVE_CRASHES) {
                logger.severe("[Supervisor] Phát hiện bot bị crash liên tục " + MAX_CONSECUTIVE_CRASHES + " lần. " +
                        "Dừng tự động khởi động lại để tránh nghẽn CPU. Vui lòng kiểm tra cấu hình hoặc token Discord!");
                break;
            }

            try {
                logger.info("[Supervisor] Đang khởi chạy Discord Bot Subprocess...");
                
                // Khởi tạo lệnh chạy
                List<String> command = new ArrayList<>();
                command.add(nodePath);
                // Có thể cấu hình heap qua wrapper; 128MB thường quá thấp cho discord.js + mineflayer.
                command.add("--max-old-space-size=" + maxOldSpaceSizeMb);
                command.add("index.js");

                ProcessBuilder pb = new ProcessBuilder(command);
                pb.directory(botDir);

                // Nạp các biến môi trường cấu hình
                Map<String, String> pbEnv = pb.environment();
                pbEnv.putAll(envVariables);
                // Đánh dấu biến để Node.js biết nó đang chạy ký sinh trong Spigot Wrapper
                pbEnv.put("SPIGOT_WRAPPER", "true");

                // Start tiến trình
                process = pb.start();
                final long processStartedAt = System.currentTimeMillis();
                logger.info("[Supervisor] Subprocess Node.js đã khởi động thành công (PID: " + getPid(process) + ").");

                // Tạo các thread đọc luồng log (stdout & stderr) song song.
                // Truyền process cụ thể để tránh race với lần restart kế tiếp.
                startLogReaders(process);

                // Đợi tiến trình con kết thúc
                int exitCode = process.waitFor();
                
                if (shouldRun) { // Nếu tự động thoát không phải do onDisable() gọi tắt
                    logger.warning("[Supervisor] Tiến trình Node.js đột ngột dừng với Exit Code: " + exitCode);
                    long runtimeMs = System.currentTimeMillis() - processStartedAt;
                    if (runtimeMs >= HEALTHY_RUN_RESET_MS) {
                        consecutiveCrashes = 0;
                    }
                    consecutiveCrashes++;
                    
                    if (consecutiveCrashes < MAX_CONSECUTIVE_CRASHES) {
                        logger.info("[Supervisor] Sẽ tự động khởi động lại bot sau " + (RESTART_DELAY_MS / 1000) + " giây...");
                        Thread.sleep(RESTART_DELAY_MS);
                    }
                }

            } catch (IOException e) {
                logger.log(Level.SEVERE, "[Supervisor] Không thể khởi chạy tiến trình Node.js. " +
                        "Hãy chắc chắn đường dẫn Node.js ('node-path') chính xác và file có quyền thực thi. Lỗi: " + e.getMessage(), e);
                consecutiveCrashes++;
                try {
                    Thread.sleep(RESTART_DELAY_MS);
                } catch (InterruptedException ie) {
                    Thread.currentThread().interrupt();
                    break;
                }
            } catch (InterruptedException e) {
                Thread.currentThread().interrupt();
                break;
            }
        }
    }

    private void startLogReaders(Process child) {
        // Đọc stdout
        stdoutThread = new Thread(() -> {
            try (BufferedReader reader = new BufferedReader(
                    new InputStreamReader(child.getInputStream(), StandardCharsets.UTF_8))) {
                String line;
                while ((line = reader.readLine()) != null) {
                    // Direct log Node.js ra console Spigot
                    logger.info("[Node-Stdout] " + line);
                }
            } catch (IOException e) {
                // Bỏ qua lỗi stream đóng khi process bị kill
            }
        }, "BotCheckStats-Stdout");
        stdoutThread.start();

        // Đọc stderr
        stderrThread = new Thread(() -> {
            try (BufferedReader reader = new BufferedReader(
                    new InputStreamReader(child.getErrorStream(), StandardCharsets.UTF_8))) {
                String line;
                while ((line = reader.readLine()) != null) {
                    logger.warning("[Node-Stderr] " + line);
                }
            } catch (IOException e) {
                // Bỏ qua lỗi stream đóng khi process bị kill
            }
        }, "BotCheckStats-Stderr");
        stderrThread.start();
    }

    /**
     * Lấy ID tiến trình (PID) cho các phiên bản Java.
     */
    private long getPid(Process p) {
        try {
            return p.toHandle().pid();
        } catch (UnsupportedOperationException e) {
            return -1;
        }
    }
}
