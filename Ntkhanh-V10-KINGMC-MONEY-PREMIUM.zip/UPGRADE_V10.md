# Ntkhanh V10 Upgrade Record

## Command plane

V10 registers eleven new groups plus the existing Money commands. New groups are intentionally visible as slash commands, while server/admin groups enforce `PAY_ADMIN_IDS`/`ADMIN_ID` at runtime so non-admin users do not gain access without hiding the command manifest.

## User Money scope

`/user` only reads orders owned by the current Discord user and only for Money trade types:

- `thu` → sold Money to bot
- `ban` → bought Money from bot

No subcommand returns another user's orders.

## Runtime systems

The new V10 layer adds persisted system toggles, worker registry, scheduler, jobs, security event storage, backup manifests, resource metrics and recovery-focused logging around the existing payment flow.

## Security

Security detection is fail-closed for secrets and invites. Destructive anti-nuke remediation is logged for administrator review instead of making an irreversible server-wide change automatically.

## Worker API

Authenticated worker endpoints:

- `GET /health`
- `GET /api/v10/status`
- `GET /api/checkbot`
- `GET /api/chat?since=...`
- `GET /api/logs?scope=...`
- `POST /api/pay`
- `POST /api/worker/control`
- `POST /api/mc/command`
- `POST /api/notify`

## Backups

Backup creation writes a `tar.gz` archive with a per-file SHA-256 manifest. Restore validates paths and archive entries before copying files back to the project root.

## Logs

V10 keeps verbose JSONL records with timestamp, level, logger name, PID, session ID, host, message and redacted metadata. The default rotation size is 20 MiB per active logger file.

## Verification

Packaging checks executed:

- `node --check` for every JavaScript source file: PASS.
- JSON parse for every JSON file: PASS.
- Existing core smoke test: PASS.
- V10 command manifest smoke test: PASS.
- User trade isolation smoke test: PASS.

Live Discord Gateway, live Minecraft protocol and live bank/API end-to-end behavior require the deployment credentials and the real services.


## V10 Money / KingMC focus update

- Removed the unrelated Premium Account / Chromium renderer from the distribution.
- Removed Puppeteer and Sharp dependencies because the Money + Discord + Minecraft Worker path does not require them.
- `/thumon` and `/banmon` deduct panel stock immediately when a trade order is created, under the stock lock.
- Cancelled/expired pre-processing trade orders return stock with an audit log.
- `/thumon` shows the exact KingMC.vn command format `/pay ntkhanh <amount>` using the resolved worker IGN.
- `/banmon` keeps unique order content and exact bank amount matching before Auto Pay.
- `/pay` remains Admin-only, uses the Minecraft Pay journal and a single-concurrency Pay queue to avoid duplicate delivery.
- Fixed AutoBank scan state so cache/limiter/logger objects are not recreated after every scan.
- Default chat polling for payment verification is 500ms in `.env.example`.
