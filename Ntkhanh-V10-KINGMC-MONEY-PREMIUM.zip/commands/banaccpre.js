const { SlashCommandBuilder } = require('discord.js');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('banaccpre')
    .setDescription('💎 Đăng bán Minecraft Premium Account')
    .addStringOption(option => option
      .setName('gia')
      .setDescription('💵 Giá acc bằng VNĐ, ví dụ 150000')
      .setRequired(true))
    .addStringOption(option => option
      .setName('tenacc')
      .setDescription('👤 Tên tài khoản Minecraft Premium')
      .setRequired(true))
    .addStringOption(option => option
      .setName('cape')
      .setDescription('🪽 Tên cape nếu có')
      .setRequired(false))
    .addStringOption(option => option
      .setName('ghichu')
      .setDescription('📝 Ghi chú / tình trạng acc')
      .setRequired(false)),
  async execute(interaction) {
    const startedAt = Date.now();
    const service = interaction.client?.paymentService;
    if (!service) throw new Error('PAYMENT_SERVICE chưa được khởi tạo.');
    try { return await service.handleInteraction(interaction); }
    finally { service.metrics?.observe?.('legacy_command_wrapper_ms', Date.now() - startedAt, { name: interaction.commandName }); }
  }
};
