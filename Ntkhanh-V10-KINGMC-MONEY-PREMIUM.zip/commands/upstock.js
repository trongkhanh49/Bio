const { SlashCommandBuilder } = require('discord.js');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('upstock')
    .setDescription('📦 Cộng thêm stock cho panel bằng Message ID')
    .addStringOption(option => option
      .setName('message_id')
      .setDescription('🆔 Message ID của panel Mua/Bán')
      .setRequired(true))
    .addStringOption(option => option
      .setName('stock')
      .setDescription('📦 Stock cộng thêm, ví dụ 50m / 1b')
      .setRequired(true))
    .addStringOption(option => option
      .setName('rt_1m')
      .setDescription('💰 RT / 1M mới (bỏ trống để giữ nguyên)')
      .setRequired(false)),
  async execute(interaction) {
    const startedAt = Date.now();
    const service = interaction.client?.paymentService;
    if (!service) throw new Error('PAYMENT_SERVICE chưa được khởi tạo.');
    try { return await service.handleInteraction(interaction); }
    finally { service.metrics?.observe?.('legacy_command_wrapper_ms', Date.now() - startedAt, { name: interaction.commandName }); }
  }
};
