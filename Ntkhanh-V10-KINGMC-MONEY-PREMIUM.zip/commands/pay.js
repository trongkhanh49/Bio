const { SlashCommandBuilder } = require('discord.js');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('pay')
    .setDescription('💸 Chuyển King xu cho người chơi (Admin Bot)'),
  async execute(interaction) {
    const startedAt = Date.now();
    const service = interaction.client?.paymentService;
    if (!service) throw new Error('PAYMENT_SERVICE chưa được khởi tạo.');
    try { return await service.handleInteraction(interaction); }
    finally { service.metrics?.observe?.('legacy_command_wrapper_ms', Date.now() - startedAt, { name: interaction.commandName }); }
  }
};
