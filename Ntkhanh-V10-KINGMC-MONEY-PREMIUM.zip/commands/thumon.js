const { SlashCommandBuilder } = require('discord.js');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('thumon')
    .setDescription('📤 Tạo panel Bán Money (Admin Bot)')
    .addStringOption(option => option.setName('stock').setDescription('📦 Stock Money, ví dụ 100m').setRequired(true))
    .addStringOption(option => option.setName('rt_1m').setDescription('💰 RT / 1M, ví dụ 50').setRequired(true)),
  async execute(interaction) {
    const startedAt = Date.now();
    const service = interaction.client?.paymentService;
    if (!service) throw new Error('PAYMENT_SERVICE chưa được khởi tạo.');
    try { return await service.handleInteraction(interaction); }
    finally { service.metrics?.observe?.('legacy_command_wrapper_ms', Date.now() - startedAt, { name: interaction.commandName }); }
  }
};
