'use strict';
const os = require('os');
const fs = require('fs');
const path = require('path');
const crypto = require('crypto');
const {
  EmbedBuilder,
  AttachmentBuilder,
  SlashCommandBuilder
} = require('discord.js');
const store = require('../../payment/store');
const { formatAmount } = require('../../payment/amount-parser');
const { SYSTEMS } = require('../../core/system-manager');
const { StructuredLogger } = require('../../core/logger');
const { UserTradeService } = require('../../services/user-trade-service');
const { BackupService } = require('./backup-service');
const { WorkerManager } = require('./worker-manager');
const { SecurityManager } = require('../../security/security-manager');
const { ConfigManager } = require('../../core/config-manager');
const { JobSystem } = require('../../core/job-system');
const { SchedulerService } = require('../../core/scheduler');

const ADMIN_COMMANDS = new Set(['bot', 'server', 'mc', 'mcworker', 'mcadmin', 'auto', 'security', 'backup', 'logs', 'system']);
const userCommandNames = new Set(['user']);
const legacyCommands = new Set(['pay', 'thumon', 'banmon', 'upstock', 'status', 'checkbot', 'thongke', 'bdsd', 'lichsu']);

const COLORS = { primary: 0x5865F2, success: 0x57F287, danger: 0xED4245, warning: 0xFEE75C, info: 0x3498DB };
const truncate = (value, max = 1024) => String(value ?? '').slice(0, max);
const safeNumber = value => Number.isFinite(Number(value)) ? Number(value) : 0;
const fmtBytes = bytes => { const n = safeNumber(bytes); if (n >= 1024 ** 3) return `${(n / 1024 ** 3).toFixed(2)} GB`; if (n >= 1024 ** 2) return `${(n / 1024 ** 2).toFixed(2)} MB`; if (n >= 1024) return `${(n / 1024).toFixed(2)} KB`; return `${Math.round(n)} B`; };
const fmtDuration = ms => { let s = Math.max(0, Math.floor(safeNumber(ms) / 1000)); const d = Math.floor(s / 86400); s -= d * 86400; const h = Math.floor(s / 3600); s -= h * 3600; const m = Math.floor(s / 60); s -= m * 60; return `${d ? `${d}d ` : ''}${h ? `${h}h ` : ''}${m ? `${m}m ` : ''}${s}s`; };

function optionString(name, description, required = false) {
  return option => option.setName(name).setDescription(description).setRequired(required);
}
function optionBoolean(name, description) {
  return option => option.setName(name).setDescription(description).setRequired(false);
}
function subcommand(name, description, configure = null) {
  return builder => {
    const sc = builder.addSubcommand(s => {
      s.setName(name).setDescription(description);
      if (configure) configure(s);
      return s;
    });
    return builder;
  };
}

class V10CommandService {
  constructor(options = {}) {
    this.client = options.client;
    this.payment = options.payment;
    this.localMcBot = options.localMcBot;
    this.audit = options.audit;
    this.config = options.config || new ConfigManager();
    this.logger = options.logger || new StructuredLogger({ name: 'v10-commands', dir: path.join(process.cwd(), 'data', 'logs') });
    this.userTrades = new UserTradeService();
    this.backups = new BackupService(process.cwd());
    this.security = new SecurityManager(this.config);
    this.jobs = new JobSystem({ concurrency: 2, maxPending: 1000 });
    this.scheduler = new SchedulerService();
    this.workerManager = new WorkerManager({ payment: this.payment, localMcBot: this.localMcBot });
    this.startedAt = Date.now();
    this.permissionCache = new Map();
    this.registerBuiltins();
  }

  registerBuiltins() {
    this.scheduler.register('health-snapshot', async () => {
      const health = this.client?.systemManager?.health?.() || {};
      await this.logger.info('Scheduled health snapshot', { health });
    });
    this.scheduler.register('log-audit', async () => {
      await this.logger.info('Scheduled log-audit heartbeat', { audit: this.audit?.snapshot?.() || null });
    });
    this.scheduler.register('backup-create', async payload => {
      await this.backups.create(payload?.createdBy || 'scheduler');
    });
    this.scheduler.register('worker-reconnect', async payload => {
      await this.workerManager.control('reconnect', payload?.workerId || 'local');
    });
    this.scheduler.start();
  }

  isAdmin(userId) {
    const id = String(userId || '');
    const ids = String(process.env.PAY_ADMIN_IDS || process.env.ADMIN_ID || '').split(',').map(x => x.trim()).filter(Boolean);
    return ids.includes(id);
  }

  requireAdmin(interaction) {
    if (!this.isAdmin(interaction.user?.id)) throw new Error('⛔ Lệnh V10 này chỉ dành cho Admin Bot.');
  }

  requireUserScope(interaction) {
    if (!interaction?.user?.id) throw new Error('Không xác định được tài khoản Discord.');
  }

  static buildCommands() {
    const commands = [];
    const bot = new SlashCommandBuilder().setName('bot').setDescription('🤖 Bot Info & Health').addSubcommand(s => s.setName('info').setDescription('Thông tin bot/runtime')).addSubcommand(s => s.setName('status').setDescription('Trạng thái tổng hợp')).addSubcommand(s => s.setName('uptime').setDescription('Uptime bot')).addSubcommand(s => s.setName('ping').setDescription('Ping Discord')).addSubcommand(s => s.setName('latency').setDescription('Latency chi tiết')).addSubcommand(s => s.setName('health').setDescription('Health check')).addSubcommand(s => s.setName('stats').setDescription('Runtime statistics')).addSubcommand(s => s.setName('permissions').setDescription('Permission matrix')).addSubcommand(s => s.setName('commands').setDescription('Command manifest'));
    const server = new SlashCommandBuilder().setName('server').setDescription('🏠 Discord Server Management').addSubcommand(s => s.setName('info').setDescription('Thông tin server')).addSubcommand(s => s.setName('stats').setDescription('Thống kê server')).addSubcommand(s => s.setName('channels').setDescription('Danh sách channel')).addSubcommand(s => s.setName('roles').setDescription('Danh sách role')).addSubcommand(s => s.setName('emojis').setDescription('Danh sách emoji')).addSubcommand(s => s.setName('audit').setDescription('Discord audit logs')).addSubcommand(s => s.setName('logs').setDescription('Server logging status'));
    const mc = new SlashCommandBuilder().setName('mc').setDescription('⛏️ Minecraft Monitoring').addSubcommand(s => s.setName('status').setDescription('Minecraft status')).addSubcommand(s => s.setName('info').setDescription('Minecraft connection info')).addSubcommand(s => s.setName('version').setDescription('Minecraft version')).addSubcommand(s => s.setName('players').setDescription('Player/session information')).addSubcommand(s => s.setName('ping').setDescription('Worker latency')).addSubcommand(s => s.setName('uptime').setDescription('Minecraft session uptime')).addSubcommand(s => s.setName('stats').setDescription('Bot game stats')).addSubcommand(s => s.setName('performance').setDescription('Minecraft performance')).addSubcommand(s => s.setName('resources').setDescription('Worker resources'));
    const mw = new SlashCommandBuilder().setName('mcworker').setDescription('⚙️ Minecraft Worker Manager').addSubcommand(s => s.setName('list').setDescription('Danh sách worker')).addSubcommand(s => s.setName('start').setDescription('Start worker').addStringOption(optionString('worker', 'Worker ID', false))).addSubcommand(s => s.setName('stop').setDescription('Stop worker').addStringOption(optionString('worker', 'Worker ID', false))).addSubcommand(s => s.setName('restart').setDescription('Restart worker').addStringOption(optionString('worker', 'Worker ID', false))).addSubcommand(s => s.setName('status').setDescription('Worker status')).addSubcommand(s => s.setName('reconnect').setDescription('Reconnect worker').addStringOption(optionString('worker', 'Worker ID', false))).addSubcommand(s => s.setName('logs').setDescription('Worker logs').addStringOption(optionString('worker', 'Worker ID', false))).addSubcommand(s => s.setName('console').setDescription('Worker console/chat').addStringOption(optionString('worker', 'Worker ID', false)));
    const ma = new SlashCommandBuilder().setName('mcadmin').setDescription('🛠️ Minecraft Management').addSubcommand(s => s.setName('command').setDescription('Gửi command Minecraft').addStringOption(optionString('command', 'Ví dụ: list', true))).addSubcommand(s => s.setName('plugins').setDescription('Yêu cầu server trả /plugins')).addSubcommand(s => s.setName('world').setDescription('World/dimension/position')).addSubcommand(s => s.setName('backup').setDescription('Tạo backup Minecraft/data')).addSubcommand(s => s.setName('restore').setDescription('Restore backup').addStringOption(optionString('id', 'Backup ID', true))).addSubcommand(s => s.setName('config').setDescription('Cấu hình V10'));
    const auto = new SlashCommandBuilder().setName('auto').setDescription('⏰ Automation & Jobs').addSubcommand(s => s.setName('schedule').setDescription('Tạo schedule').addStringOption(o => o.setName('name').setDescription('health-snapshot / log-audit / backup-create / worker-reconnect').setRequired(true).addChoices({ name: 'health-snapshot', value: 'health-snapshot' }, { name: 'log-audit', value: 'log-audit' }, { name: 'backup-create', value: 'backup-create' }, { name: 'worker-reconnect', value: 'worker-reconnect' })).addIntegerOption(o => o.setName('interval_seconds').setDescription('Chu kỳ, tối thiểu 5 giây').setRequired(true).setMinValue(5)).addStringOption(optionString('worker', 'Worker ID nếu dùng worker-reconnect', false))).addSubcommand(s => s.setName('queue').setDescription('Queue/job status')).addSubcommand(s => s.setName('task').setDescription('Xem/chạy task').addStringOption(optionString('id', 'Job ID để xem', false)).addStringOption(o => o.setName('name').setDescription('Tên task để chạy ngay').setRequired(false).addChoices({ name: 'health-snapshot', value: 'health-snapshot' }, { name: 'log-audit', value: 'log-audit' }, { name: 'backup-create', value: 'backup-create' }, { name: 'worker-reconnect', value: 'worker-reconnect' })).addStringOption(optionString('worker', 'Worker ID nếu cần', false))).addSubcommand(s => s.setName('recurring').setDescription('Danh sách recurring schedule')).addSubcommand(s => s.setName('history').setDescription('Lịch sử automation')).addSubcommand(s => s.setName('cancel').setDescription('Hủy schedule/job').addStringOption(optionString('id', 'Schedule ID hoặc Job ID', true)));
    const sec = new SlashCommandBuilder().setName('security').setDescription('🛡️ Security & Anti Abuse');
    const secNames = [['anti-spam', 'Anti Spam'], ['anti-flood', 'Anti Flood'], ['anti-raid', 'Anti Raid'], ['anti-nuke', 'Anti Nuke'], ['anti-webhook', 'Anti Webhook Abuse'], ['anti-link', 'Anti Link Spam'], ['anti-invite', 'Anti Invite Spam'], ['anti-mention', 'Anti Mention Spam'], ['anti-command', 'Anti Command Spam'], ['rate-limit', 'Rate Limit Protection']];
    for (const [name, desc] of secNames) sec.addSubcommand(s => s.setName(name).setDescription(desc).addBooleanOption(optionBoolean('enabled', `Bật/tắt ${desc}`)));
    sec.addSubcommand(s => s.setName('protection-status').setDescription('Security dashboard'));
    const backup = new SlashCommandBuilder().setName('backup').setDescription('💾 Backup & Recovery').addSubcommand(s => s.setName('create').setDescription('Tạo backup')).addSubcommand(s => s.setName('restore').setDescription('Khôi phục backup').addStringOption(optionString('id', 'Backup ID', true))).addSubcommand(s => s.setName('list').setDescription('Danh sách backup')).addSubcommand(s => s.setName('delete').setDescription('Xóa backup').addStringOption(optionString('id', 'Backup ID', true))).addSubcommand(s => s.setName('schedule').setDescription('Tạo lịch backup').addIntegerOption(o => o.setName('interval_seconds').setDescription('Chu kỳ backup').setRequired(true).setMinValue(60))).addSubcommand(s => s.setName('status').setDescription('Backup status'));
    const logs = new SlashCommandBuilder().setName('logs').setDescription('📜 Advanced Logs').addSubcommand(s => s.setName('discord').setDescription('Discord logs')).addSubcommand(s => s.setName('minecraft').setDescription('Minecraft logs')).addSubcommand(s => s.setName('bot').setDescription('Bot logs')).addSubcommand(s => s.setName('errors').setDescription('Error logs')).addSubcommand(s => s.setName('warnings').setDescription('Warning logs')).addSubcommand(s => s.setName('security').setDescription('Security logs')).addSubcommand(s => s.setName('worker').setDescription('Worker logs')).addSubcommand(s => s.setName('export').setDescription('Export log JSONL').addStringOption(optionString('scope', 'Tên logger: audit/security/system/...', false)));
    const system = new SlashCommandBuilder().setName('system').setDescription('🧠 V10 System Control').addSubcommand(s => s.setName('health').setDescription('System health')).addSubcommand(s => s.setName('resources').setDescription('CPU/RAM/resources')).addSubcommand(s => s.setName('cache').setDescription('Cache metrics')).addSubcommand(s => s.setName('database').setDescription('Data store health')).addSubcommand(s => s.setName('modules').setDescription('Module status / toggle').addStringOption(o => o.setName('system').setDescription('System key cần toggle').setRequired(false).addChoices(...SYSTEMS.map(([key, name]) => ({ name: `${key} • ${name}`.slice(0, 100), value: key })))) .addBooleanOption(optionBoolean('enabled', 'Bật/tắt module'))).addSubcommand(s => s.setName('dependencies').setDescription('Dependency checker')).addSubcommand(s => s.setName('reload').setDescription('Reload config')).addSubcommand(s => s.setName('maintenance').setDescription('Maintenance mode').addBooleanOption(o => o.setName('enabled').setDescription('Bật/tắt maintenance').setRequired(false)));
    const user = new SlashCommandBuilder().setName('user').setDescription('💰 Giao dịch Money của bạn').addSubcommand(s => s.setName('sold').setDescription('Money bạn đã bán cho bot')).addSubcommand(s => s.setName('bought').setDescription('Money bạn đã mua từ bot')).addSubcommand(s => s.setName('orders').setDescription('Các đơn Money của bạn')).addSubcommand(s => s.setName('stats').setDescription('Thống kê Money của bạn'));
    commands.push(bot, server, mc, mw, ma, auto, sec, backup, logs, system, user);
    return commands;
  }

  start() { this.config.load(); }
  stop() { this.scheduler.stop(); }

  embed(title, description, color = COLORS.primary) { return new EmbedBuilder().setTitle(title).setColor(color).setDescription(truncate(description, 4000)).setTimestamp(); }
  field(embed, name, value, inline = true) { embed.addFields({ name: truncate(name, 256), value: truncate(value || '-', 1024), inline }); return embed; }

  async handle(interaction) {
    const root = interaction.commandName;
    if (legacyCommands.has(root)) return this.payment.handleInteraction(interaction);
    if (root === 'user') return this.handleUser(interaction);
    if (ADMIN_COMMANDS.has(root)) this.requireAdmin(interaction);
    if (ADMIN_COMMANDS.has(root)) await interaction.deferReply({ ephemeral: true });
    const started = Date.now();
    try {
      const result = await this[`handle_${root}`](interaction);
      await this.logger.info('V10 command success', { command: root, subcommand: this.sub(interaction), userId: interaction.user?.id, guildId: interaction.guildId, ms: Date.now() - started });
      void this.audit?.commandResult(interaction, true);
      return result;
    } catch (error) {
      await this.logger.error('V10 command failed', { command: root, subcommand: this.sub(interaction), userId: interaction.user?.id, guildId: interaction.guildId, ms: Date.now() - started, error: error?.stack || error?.message || String(error) });
      void this.audit?.commandResult(interaction, false, error?.message || String(error));
      if (interaction.deferred || interaction.replied) return interaction.editReply({ embeds: [this.embed('❌ V10 ERROR', error?.message || String(error), COLORS.danger)] });
      return interaction.reply({ ephemeral: true, content: `❌ ${error?.message || String(error)}` });
    }
  }

  sub(i) { try { return i.options.getSubcommand(); } catch { return null; } }
  optS(i, name) { try { return i.options.getString(name); } catch { return null; } }
  optB(i, name) { try { return i.options.getBoolean(name); } catch { return null; } }
  optI(i, name) { try { return i.options.getInteger(name); } catch { return null; } }

  async handle_bot(i) {
    const sub = this.sub(i);
    const manager = this.client?.systemManager;
    const health = manager?.health?.() || {};
    const tag = this.client?.user?.tag || 'N/A';
    if (sub === 'uptime') return i.editReply({ embeds: [this.embed('⏱️ BOT • UPTIME', fmtDuration(process.uptime() * 1000), COLORS.success)] });
    if (sub === 'ping') return i.editReply({ embeds: [this.embed('🏓 BOT • PING', `Gateway: **${this.client?.ws?.ping ?? -1}ms**\nProcess: **${Date.now() - this.startedAt}ms**`, COLORS.info)] });
    if (sub === 'latency') return i.editReply({ embeds: [this.embed('📡 BOT • LATENCY', `Gateway: **${this.client?.ws?.ping ?? -1}ms**\nAPI sample: **${Date.now() - this.startedAt}ms**\nWorker: **${health?.minecraft?.online ? 'connected' : 'offline'}**`, COLORS.info)] });
    if (sub === 'health' || sub === 'status') {
      const e = this.embed(`🧠 BOT • ${sub.toUpperCase()}`, `Ready: **${this.client?.isReady?.() ? 'YES' : 'NO'}**\nUptime: **${fmtDuration(process.uptime() * 1000)}**\nGateway Ping: **${this.client?.ws?.ping ?? -1}ms**\nNode: **${process.version}**`);
      this.field(e, 'CPU', `${safeNumber(os.loadavg()[0]).toFixed(2)} load / ${os.cpus().length} cores`);
      this.field(e, 'RAM', fmtBytes(process.memoryUsage().rss));
      this.field(e, 'Minecraft', health?.minecraft?.online ? 'ONLINE' : 'OFFLINE');
      this.field(e, 'Worker Ready', health?.minecraft?.ready ? 'YES' : 'NO');
      return i.editReply({ embeds: [e] });
    }
    if (sub === 'stats') {
      const guilds = this.client?.guilds?.cache?.size || 0;
      const orders = store.all();
      const e = this.embed('📊 BOT • STATS', `Bot: **${tag}**\nGuilds: **${guilds}**\nOrders: **${orders.length}**\nCommand service: **V10**`);
      this.field(e, 'Success Orders', String(orders.filter(o => o.status === 'completed').length));
      this.field(e, 'Pending Orders', String(orders.filter(o => !['completed', 'cancelled', 'pay_failed'].includes(String(o.status))).length));
      this.field(e, 'Audit Queue', String(this.audit?.snapshot?.().queue?.waiting || 0));
      this.field(e, 'V10 Jobs', String(this.jobs.history(1000).length));
      return i.editReply({ embeds: [e] });
    }
    if (sub === 'permissions') return i.editReply({ embeds: [this.embed('🔐 BOT • PERMISSIONS', `Admin IDs: **${String(process.env.PAY_ADMIN_IDS || process.env.ADMIN_ID || '').split(',').filter(Boolean).length}**\nAdmin-only groups: **${[...ADMIN_COMMANDS].join(', ')}**\nPublic user group: **/user**`, COLORS.warning)] });
    if (sub === 'commands') {
      const groups = V10CommandService.buildCommands().map(c => `**/${c.name}**${c.options?.length ? ` → ${c.options.filter(x => x.type === 1).map(x => x.name).join(', ')}` : ''}`);
      return i.editReply({ embeds: [this.embed('📚 BOT • COMMAND MANIFEST', `**V10:**\n${groups.join('\n')}\n\n**Legacy Money:** /pay • /thumon • /banmon • /upstock • /status • /checkbot • /thongke • /bdsd • /lichsu`, COLORS.info)] });
    }
    return i.editReply({ embeds: [this.embed('🤖 BOT • INFO', `Tag: **${tag}**\nID: **${this.client?.user?.id || 'N/A'}**\nNode: **${process.version}**\nPlatform: **${process.platform}/${process.arch}**\nVersion: **V10**`)] });
  }

  async handle_server(i) {
    const guild = i.guild;
    if (!guild) throw new Error('Lệnh này cần chạy trong Discord Server.');
    const sub = this.sub(i);
    if (sub === 'info') return i.editReply({ embeds: [this.embed('🏠 SERVER • INFO', `Tên: **${guild.name}**\nID: **${guild.id}**\nOwner: <@${guild.ownerId}>\nCreated: <t:${Math.floor(guild.createdTimestamp / 1000)}:F>`)] });
    if (sub === 'stats') return i.editReply({ embeds: [this.embed('📊 SERVER • STATS', `Members cache: **${guild.memberCount ?? guild.members.cache.size}**\nChannels: **${guild.channels.cache.size}**\nRoles: **${guild.roles.cache.size}**\nEmojis: **${guild.emojis.cache.size}**`, COLORS.info)] });
    if (sub === 'channels') return i.editReply({ embeds: [this.embed('📁 SERVER • CHANNELS', guild.channels.cache.map(c => `${c.type} • <#${c.id}> • ${c.name}`).slice(0, 120).join('\n') || 'Không có channel.')] });
    if (sub === 'roles') return i.editReply({ embeds: [this.embed('🎭 SERVER • ROLES', guild.roles.cache.sort((a,b) => b.position-a.position).map(r => `${r.position} • <@&${r.id}> • ${r.name}`).slice(0, 120).join('\n') || 'Không có role.')] });
    if (sub === 'emojis') return i.editReply({ embeds: [this.embed('😀 SERVER • EMOJIS', guild.emojis.cache.map(e => `${e.animated ? '<a:' : '<:'}${e.name}:${e.id}> • ${e.name}`).slice(0, 120).join('\n') || 'Không có emoji.')] });
    if (sub === 'audit') {
      try { const logs = await guild.fetchAuditLogs({ limit: 20 }); return i.editReply({ embeds: [this.embed('🧾 SERVER • AUDIT', logs.entries.map(x => `<t:${Math.floor(x.createdTimestamp/1000)}:T> • ${x.action} • <@${x.executor?.id || '0'}> • ${x.target?.id || 'N/A'}`).join('\n').slice(0,3900) || 'Không có audit log.')] }); }
      catch (error) { return i.editReply({ embeds: [this.embed('🧾 SERVER • AUDIT', `Không đọc được audit log: ${error?.message || error}`, COLORS.warning)] }); }
    }
    const logFiles = fs.existsSync(path.join(process.cwd(), 'data', 'logs')) ? fs.readdirSync(path.join(process.cwd(), 'data', 'logs')).slice(-30).join('\n') : 'N/A';
    return i.editReply({ embeds: [this.embed('📜 SERVER • LOGS', `Audit enabled: **${this.audit?.enabled ? 'YES' : 'NO'}**\nLogger files:\n\`${logFiles}\``, COLORS.info)] });
  }

  async getMcData() {
    if (this.localMcBot) return { snapshot: this.localMcBot.getStatusSnapshot?.() || null, local: true };
    try { return await this.payment?.fetchWorkerJson('/api/checkbot', 7000); } catch (error) { return { snapshot: null, error: error?.message || String(error) }; }
  }

  async handle_mc(i) {
    const sub = this.sub(i); const data = await this.getMcData(); const s = data?.snapshot || {};
    if (sub === 'status') return i.editReply({ embeds: [this.embed('⛏️ MC • STATUS', `IGN: **${s.username || process.env.MC_USERNAME || 'N/A'}**\nServer: **${s.server || 'N/A'}**\nState: **${s.online ? (s.ready ? 'ONLINE • READY' : 'ONLINE • STARTING') : 'OFFLINE'}**\nAction: **${s.currentAction || 'IDLE'}**`, s.online ? COLORS.success : COLORS.danger)] });
    if (sub === 'version') return i.editReply({ embeds: [this.embed('🧩 MC • VERSION', `Configured: **${process.env.MC_VERSION || '1.20.1'}**\nWorker reported: **${s.version || 'N/A'}**`)] });
    if (sub === 'players') return i.editReply({ embeds: [this.embed('👥 MC • PLAYERS', `Bot: **${s.username || 'N/A'}**\nOnline state: **${s.online ? 'ONLINE' : 'OFFLINE'}**\nTarget player: **${s.targetPlayer || 'None'}**\nChat buffer: **${s.chatBufferLength || 0}**`)] });
    if (sub === 'ping') return i.editReply({ embeds: [this.embed('🏓 MC • PING', `Worker HTTP latency: **${safeNumber(data?._latencyMs)}ms**\nMC bot state: **${s.online ? 'ONLINE' : 'OFFLINE'}**`, COLORS.info)] });
    if (sub === 'uptime') return i.editReply({ embeds: [this.embed('⏱️ MC • UPTIME', fmtDuration(s.sessionPlayTimeMs || 0), COLORS.success)] });
    if (sub === 'stats') return i.editReply({ embeds: [this.embed('📊 MC • STATS', this.payment?.formatBotStats?.(data?.stats || null) || JSON.stringify(data?.stats || {}, null, 2), COLORS.info)] });
    if (sub === 'performance' || sub === 'resources') return i.editReply({ embeds: [this.embed(`📈 MC • ${sub.toUpperCase()}`, `Session: **${fmtDuration(s.sessionPlayTimeMs || 0)}**\nAction age: **${fmtDuration(s.actionAgeMs || 0)}**\nPay Queue: **${s.payQueueLength || 0}**\nReady: **${s.ready ? 'YES' : 'NO'}**\nReconnect: **${s.lastDisconnectAt || 'N/A'}**`, COLORS.info)] });
    return i.editReply({ embeds: [this.embed('⛏️ MC • INFO', `IGN: **${s.username || process.env.MC_USERNAME || 'N/A'}**\nHost: **${s.server || 'N/A'}**\nConfigured Version: **${process.env.MC_VERSION || '1.20.1'}**\nRole: **${process.env.BOT_ROLE || 'standalone'}**`)] });
  }

  async handle_mcworker(i) {
    const sub = this.sub(i); const workerId = this.optS(i, 'worker') || 'local';
    if (sub === 'list' || sub === 'status') {
      const rows = await this.workerManager.snapshot();
      const text = rows.map(w => `**${w.id}** • ${w.label || ''}\n${w.error ? `❌ ${w.error}` : `✅ ${w.status?.snapshot?.online ? 'ONLINE' : 'OFFLINE'} • ${w.status?.snapshot?.username || 'N/A'}`}`).join('\n\n') || 'Không có worker.';
      return i.editReply({ embeds: [this.embed(`⚙️ MCWORKER • ${sub.toUpperCase()}`, text, COLORS.info)] });
    }
    if (['start','stop','restart','reconnect'].includes(sub)) { const r = await this.workerManager.control(sub, workerId); return i.editReply({ embeds: [this.embed(`⚙️ MCWORKER • ${sub.toUpperCase()}`, `Worker: **${workerId}**\nKết quả: **${JSON.stringify(r)}**`, sub === 'stop' ? COLORS.warning : COLORS.success)] }); }
    if (sub === 'logs' || sub === 'console') { const r = await this.workerManager.logs(workerId); return i.editReply({ embeds: [this.embed(`📝 MCWORKER • ${sub.toUpperCase()}`, truncate(r?.text || r?.messages?.map?.(x => x.text).join('\n') || JSON.stringify(r), 3900), COLORS.info)] }); }
  }

  async executeMcCommand(command) {
    const clean = String(command || '').replace(/^\//, '').trim();
    if (!clean) throw new Error('Command Minecraft rỗng.');
    if (clean.length > 200) throw new Error('Command Minecraft quá dài.');
    if (this.localMcBot?.bot && this.localMcBot.isBotOnline) { this.localMcBot.bot.chat(`/${clean}`); void this.logger.info('MC command sent', { command: clean, local: true }); return { success: true, local: true, command: clean }; }
    if (this.payment?.requestWorker) return this.payment.requestWorker('/api/mc/command', { method: 'POST', body: JSON.stringify({ command: clean }) });
    throw new Error('Không có MC worker khả dụng.');
  }

  async handle_mcadmin(i) {
    const sub = this.sub(i);
    if (sub === 'command') { const r = await this.executeMcCommand(this.optS(i, 'command')); return i.editReply({ embeds: [this.embed('🛠️ MCADMIN • COMMAND', `Đã gửi: **/${r.command}**\nWorker: **${r.local ? 'LOCAL' : 'REMOTE'}**`, COLORS.success)] }); }
    if (sub === 'plugins') { const r = await this.executeMcCommand('plugins'); return i.editReply({ embeds: [this.embed('🧩 MCADMIN • PLUGINS', `Đã gửi **/plugins** cho Minecraft server.\nKết quả command: ${JSON.stringify(r)}`, COLORS.info)] }); }
    if (sub === 'world') {
      const bot = this.localMcBot?.bot; const e = this.embed('🌍 MCADMIN • WORLD', `Dimension: **${bot?.game?.dimension || 'N/A'}**\nGamemode: **${bot?.game?.gameMode || 'N/A'}**\nDifficulty: **${bot?.game?.difficulty || 'N/A'}**`);
      if (bot?.entity?.position) this.field(e, 'Position', `${bot.entity.position.x.toFixed(2)} / ${bot.entity.position.y.toFixed(2)} / ${bot.entity.position.z.toFixed(2)}`, false);
      return i.editReply({ embeds: [e] });
    }
    if (sub === 'backup') { const entry = await this.backups.create(i.user.id); return i.editReply({ embeds: [this.embed('💾 MCADMIN • BACKUP', `Backup: **${entry.id}**\nSize: **${fmtBytes(entry.bytes)}**\nFiles: **${entry.fileCount}**`, COLORS.success)] }); }
    if (sub === 'restore') { const entry = await this.backups.restore(this.optS(i, 'id'), i.user.id); return i.editReply({ embeds: [this.embed('♻️ MCADMIN • RESTORE', `Đã restore backup **${entry.id}**. Restart service/worker nếu dữ liệu runtime yêu cầu.`, COLORS.success)] }); }
    return i.editReply({ embeds: [this.embed('⚙️ MCADMIN • CONFIG', JSON.stringify(this.config.snapshot(), null, 2), COLORS.info)] });
  }

  async handle_auto(i) {
    const sub = this.sub(i);
    if (sub === 'schedule') {
      const name = this.optS(i, 'name'); const seconds = this.optI(i, 'interval_seconds');
      const entry = this.scheduler.create({ name, intervalMs: seconds * 1000, createdBy: i.user.id, payload: { workerId: this.optS(i, 'worker') || 'local' } });
      return i.editReply({ embeds: [this.embed('⏰ AUTO • SCHEDULE', `ID: **${entry.id}**\nTask: **${name}**\nEvery: **${seconds}s**\nNext: <t:${Math.floor(entry.nextRunAt/1000)}:F>`, COLORS.success)] });
    }
    if (sub === 'queue') return i.editReply({ embeds: [this.embed('📦 AUTO • QUEUE', JSON.stringify(this.jobs.snapshot(), null, 2), COLORS.info)] });
    if (sub === 'task') {
      const id = this.optS(i, 'id');
      if (id) { const task = this.jobs.get(id); if (!task) throw new Error('Không tìm thấy Job ID.'); return i.editReply({ embeds: [this.embed('🧰 AUTO • TASK', JSON.stringify(task, null, 2), COLORS.info)] }); }
      const name = this.optS(i, 'name');
      if (!name) throw new Error('Hãy nhập `id` để xem task hoặc `name` để chạy task ngay.');
      const job = this.jobs.submit(name, async () => { const handler = this.scheduler.handlers.get(name); if (!handler) throw new Error(`Không có handler: ${name}`); return handler({ workerId: this.optS(i, 'worker') || 'local' }); }, { actor: i.user.id }, { priority: 10 });
      return i.editReply({ embeds: [this.embed('🧰 AUTO • TASK QUEUED', `Job: **${job.id}**
Task: **${name}**
Queue: **${this.jobs.queue.size} chờ**`, COLORS.success)] });
    }
    if (sub === 'recurring') return i.editReply({ embeds: [this.embed('🔁 AUTO • RECURRING', this.scheduler.list().map(x => `${x.id} • ${x.name} • every ${Math.round(x.intervalMs/1000)}s • runs=${x.runs}`).join('\n') || 'Chưa có schedule.')] });
    if (sub === 'history') { const h = [...this.scheduler.history(), ...this.jobs.history(25)].slice(-40).reverse(); return i.editReply({ embeds: [this.embed('📜 AUTO • HISTORY', h.map(x => JSON.stringify(x)).join('\n').slice(0,3900) || 'Chưa có history.')] }); }
    const id = this.optS(i, 'id'); const cancelled = this.scheduler.cancel(id); if (cancelled) return i.editReply({ embeds: [this.embed('🛑 AUTO • CANCEL', `Đã hủy schedule **${id}**.`, COLORS.success)] });
    const job = this.jobs.get(id); if (job) { job.status = 'cancel_requested'; return i.editReply({ embeds: [this.embed('🛑 AUTO • CANCEL', `Job **${id}** đã được đánh dấu cancel_requested.`, COLORS.warning)] }); }
    throw new Error('Không tìm thấy schedule/job.');
  }

  async handle_security(i) {
    const sub = this.sub(i);
    if (sub === 'protection-status') return i.editReply({ embeds: [this.embed('🛡️ SECURITY • PROTECTION STATUS', JSON.stringify(this.security.protectionStatus(), null, 2), COLORS.info)] });
    const enabled = this.optB(i, 'enabled');
    if (enabled !== null) {
      const state = this.security.set(sub, enabled); return i.editReply({ embeds: [this.embed('🛡️ SECURITY • MODULE UPDATED', `Module: **${sub}**\nEnabled: **${enabled ? 'YES' : 'NO'}**\nConfig version: **${state.version}**`, enabled ? COLORS.success : COLORS.warning)] });
    }
    const key = this.security.moduleKey(sub); const value = this.security.enabled(key); return i.editReply({ embeds: [this.embed(`🛡️ SECURITY • ${sub.toUpperCase()}`, `Current state: **${value ? 'ENABLED' : 'DISABLED'}**\nGửi lại với option **enabled=true/false** để thay đổi.`, value ? COLORS.success : COLORS.warning)] });
  }

  async handle_backup(i) {
    const sub = this.sub(i);
    if (sub === 'create') { const e = await this.backups.create(i.user.id); return i.editReply({ embeds: [this.embed('💾 BACKUP • CREATE', `ID: **${e.id}**\nSize: **${fmtBytes(e.bytes)}**\nFiles: **${e.fileCount}**\nSHA tracked: **${e.manifest.length}** file(s)`, COLORS.success)] }); }
    if (sub === 'list') return i.editReply({ embeds: [this.embed('💾 BACKUP • LIST', this.backups.list().slice(0, 25).map(x => `**${x.id}** • ${fmtBytes(x.bytes)} • ${x.fileCount} files • <t:${Math.floor(new Date(x.createdAt).getTime()/1000)}:R>`).join('\n') || 'Chưa có backup.')] });
    if (sub === 'restore') { const e = await this.backups.restore(this.optS(i,'id'), i.user.id); return i.editReply({ embeds: [this.embed('♻️ BACKUP • RESTORE', `Đã khôi phục **${e.id}**.`, COLORS.success)] }); }
    if (sub === 'delete') { const e = await this.backups.delete(this.optS(i,'id'), i.user.id); if (!e) throw new Error('Không tìm thấy backup.'); return i.editReply({ embeds: [this.embed('🗑️ BACKUP • DELETE', `Đã xóa **${e.id}**.`, COLORS.warning)] }); }
    if (sub === 'schedule') { const sec = this.optI(i,'interval_seconds'); const e = this.scheduler.create({ name: 'backup-create', intervalMs: sec*1000, createdBy: i.user.id, payload: { createdBy: 'backup-scheduler' } }); return i.editReply({ embeds: [this.embed('🔁 BACKUP • SCHEDULE', `Schedule: **${e.id}**\nEvery: **${sec}s**`, COLORS.success)] }); }
    return i.editReply({ embeds: [this.embed('📊 BACKUP • STATUS', JSON.stringify(this.backups.status(), null, 2), COLORS.info)] });
  }

  tailLogs(scope) {
    const dir = path.join(process.cwd(), 'data', 'logs');
    if (!fs.existsSync(dir)) return 'Log directory chưa có.';
    const files = fs.readdirSync(dir).filter(f => scope ? f.toLowerCase().includes(String(scope).toLowerCase()) : true).sort().slice(-8);
    const sections = files.map(f => `===== ${f} =====\n${fs.readFileSync(path.join(dir,f),'utf8').split(/\r?\n/).filter(Boolean).slice(-20).join('\n')}`);
    return sections.join('\n').slice(-3900) || 'Chưa có log phù hợp.';
  }

  async handle_logs(i) {
    const sub = this.sub(i); const scope = sub === 'export' ? (this.optS(i,'scope') || 'audit') : sub;
    if (sub === 'export') {
      const dir = path.join(process.cwd(), 'data', 'logs'); const files = fs.existsSync(dir) ? fs.readdirSync(dir).filter(f => f.includes(scope)).sort().slice(-10) : [];
      const body = files.map(f => fs.readFileSync(path.join(dir,f),'utf8')).join('').slice(-7_000_000);
      const attachment = new AttachmentBuilder(Buffer.from(body, 'utf8'), { name: `v10-${scope}-${Date.now()}.jsonl` });
      return i.editReply({ content: `📦 Export **${scope}** • ${files.length} file(s)`, files: [attachment] });
    }
    return i.editReply({ embeds: [this.embed(`📜 LOGS • ${sub.toUpperCase()}`, this.tailLogs(scope), COLORS.info)] });
  }

  async handle_system(i) {
    const sub = this.sub(i); const manager = this.client?.systemManager;
    if (sub === 'health') return i.editReply({ embeds: [this.embed('🧠 SYSTEM • HEALTH', JSON.stringify(manager?.health?.() || {}, null, 2), COLORS.info)] });
    if (sub === 'resources') return i.editReply({ embeds: [this.embed('🖥️ SYSTEM • RESOURCES', JSON.stringify(manager?.resources?.() || { cpu: os.loadavg(), memory: process.memoryUsage() }, null, 2), COLORS.info)] });
    if (sub === 'cache') return i.editReply({ embeds: [this.embed('🧊 SYSTEM • CACHE', JSON.stringify({ state: store.snapshot(), audit: this.audit?.snapshot?.(), payment: this.payment?.metrics?.snapshot?.() || null }, null, 2), COLORS.info)] });
    if (sub === 'database') return i.editReply({ embeds: [this.embed('🗄️ SYSTEM • DATABASE', JSON.stringify(store.snapshot(), null, 2), COLORS.info)] });
    if (sub === 'modules') {
      const key = this.optS(i,'system'); const enabled = this.optB(i,'enabled');
      if (key && enabled !== null) { const state = manager.toggle(key, enabled); return i.editReply({ embeds: [this.embed('🧩 SYSTEM • MODULE UPDATED', `**${key}** → **${enabled ? 'ON' : 'OFF'}**\nVersion: **${state.version}**`, enabled ? COLORS.success : COLORS.warning)] }); }
      return i.editReply({ embeds: [this.embed('🧩 SYSTEM • MODULES', manager?.list?.().map(x => `${x.enabled ? '🟢' : '🔴'} **${x.key}** • ${x.name}`).join('\n') || 'N/A')] });
    }
    if (sub === 'dependencies') {
      const pkg = JSON.parse(fs.readFileSync(path.join(process.cwd(),'package.json'),'utf8')); const result = {};
      for (const name of Object.keys(pkg.dependencies || {})) { try { result[name] = require.resolve(name); } catch (e) { result[name] = `MISSING: ${e.message}`; } }
      return i.editReply({ embeds: [this.embed('📦 SYSTEM • DEPENDENCIES', JSON.stringify(result, null, 2), COLORS.info)] });
    }
    if (sub === 'reload') { const state = this.config.reload(); return i.editReply({ embeds: [this.embed('🔄 SYSTEM • RELOAD', `Config version: **${state.version}**\nModules: **${Object.values(state.systems).filter(Boolean).length}/${Object.keys(state.systems).length} ON**`, COLORS.success)] }); }
    const enabled = this.optB(i,'enabled'); if (enabled !== null) { this.config.config.maintenance = enabled; this.config.save(); return i.editReply({ embeds: [this.embed('🛠️ SYSTEM • MAINTENANCE', `Maintenance: **${enabled ? 'ON' : 'OFF'}**`, enabled ? COLORS.warning : COLORS.success)] }); }
    return i.editReply({ embeds: [this.embed('🛠️ SYSTEM • MAINTENANCE', `Current: **${this.config.config?.maintenance ? 'ON' : 'OFF'}**`)] });
  }

  async handleUser(i) {
    this.requireUserScope(i);
    await i.deferReply({ ephemeral: true });
    const userId = String(i.user.id); const sub = this.sub(i); const summary = this.userTrades.summary(userId);
    await this.userTrades.audit(userId, sub, { guildId: i.guildId, channelId: i.channelId });
    if (sub === 'sold') {
      const rows = this.userTrades.sold(userId).reverse(); const e = this.embed('📤 USER • MONEY ĐÃ BÁN CHO BOT', `Tổng đơn: **${rows.length}**\nHoàn tất: **${summary.soldCompleted}**\nMoney hoàn tất: **${formatAmount(summary.soldMoney)}**\nVNĐ nhận: **${summary.soldVnd.toLocaleString('vi-VN')}đ**`); this.field(e,'Chi tiết gần nhất',this.userTrades.formatRows(rows),false); return i.editReply({ embeds:[e] });
    }
    if (sub === 'bought') {
      const rows = this.userTrades.bought(userId).reverse(); const e = this.embed('📥 USER • MONEY ĐÃ MUA TỪ BOT', `Tổng đơn: **${rows.length}**\nHoàn tất: **${summary.boughtCompleted}**\nMoney hoàn tất: **${formatAmount(summary.boughtMoney)}**\nVNĐ đã chuyển: **${summary.boughtVnd.toLocaleString('vi-VN')}đ**`); this.field(e,'Chi tiết gần nhất',this.userTrades.formatRows(rows),false); return i.editReply({ embeds:[e] });
    }
    if (sub === 'orders') { const rows = [...this.userTrades.sold(userId), ...this.userTrades.bought(userId)].sort((a,b) => String(b.createdAt).localeCompare(String(a.createdAt))); const e = this.embed('🧾 USER • MONEY ORDERS', `Đang xử lý: **${summary.active.length}**\nTổng đơn Money: **${rows.length}**`); this.field(e,'Đơn',this.userTrades.formatRows(rows, 15),false); return i.editReply({ embeds:[e] }); }
    const e = this.embed('💰 USER • MONEY STATS', `👤 Discord: <@${userId}>\n📤 Bán cho bot: **${summary.soldCount}** đơn / **${formatAmount(summary.soldMoney)}** Money\n📥 Mua từ bot: **${summary.boughtCount}** đơn / **${formatAmount(summary.boughtMoney)}** Money\n⏳ Đang xử lý: **${summary.active.length}**`); return i.editReply({ embeds:[e] });
  }
}

module.exports = { V10CommandService, ADMIN_COMMANDS, userCommandNames };
