'use strict';
const fs = require('fs');
const path = require('path');
const crypto = require('crypto');
const { execFile } = require('child_process');
const { promisify } = require('util');
const execFileAsync = promisify(execFile);
const { StructuredLogger } = require('../../core/logger');
const { PersistentJson } = require('../../core/persistent-json');

function safeRelative(value) { const text = String(value || '').replace(/\\/g, '/'); return Boolean(text) && !text.startsWith('/') && !text.split('/').includes('..') && /^[A-Za-z0-9._\/-]+$/.test(text); }

function walk(dir) {
  const out = [];
  if (path.basename(dir) === 'backups') return out;
  if (!fs.existsSync(dir)) return out;
  for (const entry of fs.readdirSync(dir, { withFileTypes: true })) {
    const full = path.join(dir, entry.name);
    if (entry.isDirectory()) out.push(...walk(full));
    else if (entry.isFile()) out.push(full);
  }
  return out;
}

function sha256(file) {
  const hash = crypto.createHash('sha256');
  hash.update(fs.readFileSync(file));
  return hash.digest('hex');
}

class BackupService {
  constructor(root = process.cwd()) {
    this.root = path.resolve(root);
    this.dataDir = path.join(this.root, 'data');
    this.backupDir = path.join(this.dataDir, 'backups');
    this.index = new PersistentJson(path.join(this.backupDir, 'index.json'), { backups: [] }, { maxHistory: 1000 });
    this.logger = new StructuredLogger({ name: 'backup', dir: path.join(this.dataDir, 'logs') });
    fs.mkdirSync(this.backupDir, { recursive: true });
  }

  getBackupFiles() {
    const files = [];
    for (const relative of ['config.json', '.env.example', 'package.json', 'render.yaml', 'data']) {
      const full = path.join(this.root, relative);
      if (fs.existsSync(full)) files.push(full);
    }
    return files.flatMap(full => fs.statSync(full).isDirectory() ? walk(full) : [full]);
  }

  async create(createdBy = 'system') {
    const id = `V10-${new Date().toISOString().replace(/[-:.TZ]/g, '').slice(0, 14)}-${crypto.randomBytes(4).toString('hex').toUpperCase()}`;
    const archive = path.join(this.backupDir, `${id}.tar.gz`);
    const files = this.getBackupFiles();
    const manifest = files.map(file => ({ path: path.relative(this.root, file).replace(/\\/g, '/'), bytes: fs.statSync(file).size, sha256: sha256(file) }));
    await execFileAsync('tar', ['-czf', archive, ...files.map(file => path.relative(this.root, file))], { cwd: this.root, maxBuffer: 4 * 1024 * 1024 });
    const state = this.index.read();
    const entry = { id, archive, createdAt: new Date().toISOString(), createdBy: String(createdBy), bytes: fs.statSync(archive).size, fileCount: manifest.length, manifest };
    state.backups.push(entry);
    state.backups = state.backups.slice(-100);
    this.index.write(state);
    await this.logger.info('Backup created', { id, bytes: entry.bytes, fileCount: entry.fileCount, createdBy });
    return entry;
  }

  list() { return this.index.read().backups.slice().reverse(); }
  get(id) { return this.index.read().backups.find(x => String(x.id) === String(id)) || null; }

  async restore(id, actor = 'system') {
    const entry = this.get(id);
    if (!entry) throw new Error('Không tìm thấy backup.');
    if (!fs.existsSync(entry.archive)) throw new Error('File backup không tồn tại trên disk.');
    const stage = path.join(this.backupDir, `.restore-${id}-${Date.now()}`);
    fs.mkdirSync(stage, { recursive: true });
    try {
      for (const file of entry.manifest) if (!safeRelative(file.path)) throw new Error(`Backup manifest path không hợp lệ: ${file.path}`);
      const listing = await execFileAsync('tar', ['-tzf', entry.archive], { maxBuffer: 8 * 1024 * 1024 });
      for (const raw of String(listing.stdout || '').split(/\r?\n/).filter(Boolean)) { const normalized = raw.replace(/\/$/, ''); if (normalized && !safeRelative(normalized)) throw new Error(`Backup archive chứa path không an toàn: ${normalized}`); }
      await execFileAsync('tar', ['-xzf', entry.archive, '-C', stage, '--no-same-owner'], { maxBuffer: 4 * 1024 * 1024 });
      for (const file of entry.manifest) {
        const source = path.join(stage, file.path);
        const destination = path.join(this.root, file.path);
        if (!fs.existsSync(source)) throw new Error(`Backup thiếu file ${file.path}`);
        fs.mkdirSync(path.dirname(destination), { recursive: true });
        fs.copyFileSync(source, destination);
      }
      await this.logger.info('Backup restored', { id, actor, fileCount: entry.fileCount });
      return { ...entry, restoredAt: new Date().toISOString(), restoredBy: String(actor) };
    } finally {
      fs.rmSync(stage, { recursive: true, force: true });
    }
  }

  async delete(id, actor = 'system') {
    const state = this.index.read();
    const idx = state.backups.findIndex(x => String(x.id) === String(id));
    if (idx < 0) return null;
    const [entry] = state.backups.splice(idx, 1);
    try { fs.unlinkSync(entry.archive); } catch {}
    this.index.write(state);
    await this.logger.warn('Backup deleted', { id, actor });
    return entry;
  }

  status() {
    const backups = this.list();
    const totalBytes = backups.reduce((sum, item) => sum + Number(item.bytes || 0), 0);
    return { count: backups.length, totalBytes, latest: backups[0] || null, backupDir: this.backupDir };
  }
}

module.exports = { BackupService };
