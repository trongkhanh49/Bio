'use strict';
const path = require('path');
const { StructuredLogger } = require('../../core/logger');

class WorkerManager {
  constructor(options = {}) {
    this.payment = options.payment;
    this.local = options.localMcBot || null;
    this.logger = new StructuredLogger({ name: 'worker-manager', dir: path.join(process.cwd(), 'data', 'logs') });
    this.configured = this.parseConfiguredWorkers();
  }

  parseConfiguredWorkers() {
    const raw = String(process.env.MC_WORKERS_JSON || '').trim();
    if (!raw) return [];
    try {
      const data = JSON.parse(raw);
      if (!Array.isArray(data)) return [];
      return data.map((x, i) => ({ id: String(x.id || `worker-${i + 1}`), url: String(x.url || '').replace(/\/+$/, ''), label: String(x.label || x.id || `Worker ${i + 1}`) })).filter(x => x.url);
    } catch (error) {
      void this.logger.error('MC_WORKERS_JSON invalid', { error: error?.message });
      return [];
    }
  }

  async localStatus() { return this.local?.getStatusSnapshot?.() || null; }

  async remoteStatus(worker) {
    if (!this.payment) throw new Error('Payment service chưa sẵn sàng.');
    return this.payment.requestWorkerFromUrl(worker.url, '/api/checkbot', { method: 'GET' });
  }

  list() {
    const primary = this.local
      ? [{ id: 'local', label: 'Local Worker', url: null, local: true }]
      : (String(process.env.PAYMENT_WORKER_URL || process.env.MC_WORKER_URL || process.env.WORKER_URL || '').trim()
        ? [{ id: 'primary', label: 'Primary Remote Worker', url: String(process.env.PAYMENT_WORKER_URL || process.env.MC_WORKER_URL || process.env.WORKER_URL).replace(/\/+$/, ''), local: false }]
        : []);
    const seen = new Set(primary.map(x => x.id));
    return [...primary, ...this.configured.filter(x => !seen.has(x.id))];
  }

  async snapshot() {
    const results = [];
    for (const worker of this.list()) {
      if (worker.local) results.push({ ...worker, status: await this.localStatus() });
      else {
        try { results.push({ ...worker, status: await this.remoteStatus(worker) }); }
        catch (error) { results.push({ ...worker, status: null, error: error?.message || String(error) }); }
      }
    }
    return results;
  }

  async control(action, workerId = 'local') {
    const worker = this.list().find(x => String(x.id) === String(workerId));
    if (!worker) throw new Error(`Không tìm thấy worker ${workerId}.`);
    if (worker.local) {
      if (!this.local) throw new Error('Local worker không tồn tại.');
      if (action === 'start' || action === 'reconnect') this.local.connect();
      else if (action === 'stop') this.local.stop?.(`V10 ${action}`);
      else if (action === 'restart') { if (typeof this.local.restart === 'function') await this.local.restart('V10 restart'); else { this.local.stop?.('V10 restart'); setTimeout(() => this.local.connect(), 2500).unref?.(); } }
      else throw new Error(`Worker action không hỗ trợ: ${action}`);
      void this.logger.info('Local worker control', { action, workerId });
      return { success: true, action, workerId, local: true };
    }
    if (!this.payment) throw new Error('Payment service chưa sẵn sàng.');
    const response = await this.payment.requestWorkerFromUrl?.(worker.url, '/api/worker/control', { method: 'POST', body: JSON.stringify({ action }) });
    void this.logger.info('Remote worker control', { action, workerId, workerUrl: worker.url });
    return response || { success: true, action, workerId };
  }

  async logs(workerId = 'local') {
    const worker = this.list().find(x => String(x.id) === String(workerId));
    if (!worker) throw new Error(`Không tìm thấy worker ${workerId}.`);
    if (worker.local) return { source: 'local', text: this.tailLocalLogs() };
    return this.payment.requestWorkerFromUrl(worker.url, '/api/logs?scope=minecraft', { method: 'GET' });
  }

  tailLocalLogs() {
    const file = path.join(process.cwd(), 'data', 'logs', `minecraft-${new Date().toISOString().slice(0, 10)}.jsonl`);
    if (!require('fs').existsSync(file)) return 'Chưa có log Minecraft hôm nay.';
    return require('fs').readFileSync(file, 'utf8').split(/\r?\n/).filter(Boolean).slice(-60).join('\n').slice(-7500);
  }
}

module.exports = { WorkerManager };
