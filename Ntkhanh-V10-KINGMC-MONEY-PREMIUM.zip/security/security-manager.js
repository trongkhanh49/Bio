'use strict';
const path = require('path');
const { StructuredLogger } = require('../core/logger');
const { PersistentJson } = require('../core/persistent-json');
const { TokenBucketLimiter } = require('../core/rateLimiter');

const MODULES = {
  'anti-spam': 'antiSpam', 'anti-flood': 'antiFlood', 'anti-raid': 'antiRaid', 'anti-nuke': 'antiNuke',
  'anti-webhook': 'antiWebhookAbuse', 'anti-link': 'antiLinkSpam', 'anti-invite': 'antiInviteSpam',
  'anti-mention': 'antiMentionSpam', 'anti-command': 'antiCommandSpam', 'protection-status': 'rateLimit'
};

class SecurityManager {
  constructor(config) {
    this.config = config;
    this.logger = new StructuredLogger({ name: 'security', dir: path.join(process.cwd(), 'data', 'logs') });
    this.events = new PersistentJson(path.join(process.cwd(), 'data', 'security-events.json'), { events: [], counters: {} });
    this.limiters = new Map();
    this.actionWindows = new Map();
    this.guildSnapshots = new Map();
  }

  limiter(name, options = {}) {
    if (!this.limiters.has(name)) this.limiters.set(name, new TokenBucketLimiter({ capacity: options.capacity || 10, refillPerSecond: options.refillPerSecond || 2, maxKeys: options.maxKeys || 10000 }));
    return this.limiters.get(name);
  }

  enabled(key) { return this.config?.config?.security?.[key] !== false; }

  record(event, meta = {}) {
    const state = this.events.read();
    state.events.push({ id: `${Date.now()}-${Math.random().toString(36).slice(2, 10)}`, at: new Date().toISOString(), event, ...meta });
    state.events = state.events.slice(-10000);
    state.counters[event] = Number(state.counters[event] || 0) + 1;
    this.events.write(state);
    void this.logger.warn(`Security event: ${event}`, meta);
  }

  inspectMessage(message) {
    if (!message || !message.guild || message.author?.bot) return { allowed: true, reasons: [] };
    const reasons = [];
    const now = Date.now();
    const floodKey = `flood:${message.guild.id}:${message.author.id}`;
    const recent = (this.actionWindows.get(floodKey) || []).filter(t => now - t < 10000);
    recent.push(now);
    this.actionWindows.set(floodKey, recent);
    if (this.enabled('antiFlood') && recent.length >= 12) reasons.push('anti-flood');

    if (this.enabled('antiRaid')) {
      const joinKey = `raid:${message.guild.id}`;
      const joins = (this.actionWindows.get(joinKey) || []).filter(t => now - t < 30000);
      this.actionWindows.set(joinKey, joins);
      if (joins.length >= 20) reasons.push('anti-raid');
    }
    const userId = String(message.author.id);
    const guildId = String(message.guild.id);
    if (this.enabled('antiSpam')) {
      const gate = this.limiter(`spam:${guildId}`, { capacity: 8, refillPerSecond: 2 }).consume(userId, 1);
      if (!gate.allowed) reasons.push('anti-spam');
    }
    if (this.enabled('antiMentionSpam')) {
      const mentions = Number(message.mentions?.users?.size || 0) + Number(message.mentions?.roles?.size || 0) * 2;
      if (mentions >= 8) reasons.push('anti-mention');
    }
    if (this.enabled('antiLinkSpam') && /(https?:\/\/|www\.)/i.test(message.content || '')) {
      const gate = this.limiter(`links:${guildId}`, { capacity: 4, refillPerSecond: 0.5 }).consume(userId, 1);
      if (!gate.allowed) reasons.push('anti-link');
    }
    if (this.enabled('antiInviteSpam') && /(discord\.gg\/|discord(?:app)?\.com\/invite\/)/i.test(message.content || '')) reasons.push('anti-invite');
    if (this.enabled('antiTokenSecretLeak') && /(mfa\.[A-Za-z0-9_-]{20,}|[MN][A-Za-z\d]{20,}\.[\w-]{5,}\.[\w-]{20,})/i.test(message.content || '')) reasons.push('anti-secret');
    if (reasons.length) this.record('message_block_candidate', { guildId, userId, channelId: message.channelId, reasons, messageId: message.id });
    return { allowed: reasons.length === 0, reasons };
  }

  recordMemberJoin(member) {
    if (!member?.guild?.id) return;
    const key = `raid:${member.guild.id}`;
    const now = Date.now();
    const joins = (this.actionWindows.get(key) || []).filter(t => now - t < 30000);
    joins.push(now);
    this.actionWindows.set(key, joins);
    if (this.enabled('antiRaid') && joins.length >= 20) this.record('anti_raid_threshold', { guildId: member.guild.id, joinsLast30s: joins.length });
    if (member.user?.bot && this.enabled('antiBotAdd')) this.record('anti_bot_add_candidate', { guildId: member.guild.id, botId: member.user.id, tag: member.user.tag });
  }

  recordWorkerEvent(type, meta = {}) {
    if (type === 'connection' && !this.enabled('antiMcConnectionSpam')) return;
    if (type === 'abuse' && !this.enabled('antiWorkerAbuse')) return;
    this.record(`anti_${type}`, meta);
  }

  protectionStatus() {
    const state = this.events.read();
    return {
      modules: Object.fromEntries(Object.entries(this.config?.config?.security || {}).map(([k, v]) => [k, Boolean(v)])),
      limiterCount: this.limiters.size,
      eventCount: state.events.length,
      counters: state.counters,
      recent: state.events.slice(-15).reverse()
    };
  }

  moduleKey(subcommand) { return MODULES[subcommand] || null; }
  set(subcommand, enabled) {
    const key = this.moduleKey(subcommand);
    if (!key) throw new Error('Security subcommand này không hỗ trợ bật/tắt trực tiếp.');
    return this.config.setSecurity(key, enabled);
  }
}

module.exports = { SecurityManager };
