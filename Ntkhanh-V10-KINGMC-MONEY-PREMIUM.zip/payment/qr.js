'use strict';

function safePart(value, max = 120) {
  const text = String(value ?? '').trim();
  if (!text || text.length > max || /[\u0000-\u001f\u007f]/.test(text)) throw new Error('Dữ liệu QR không hợp lệ.');
  return text;
}

function qrUrl({ bankCode, accountNo, accountName, amount, content }) {
  const bank = safePart(bankCode, 40);
  const account = safePart(accountNo, 40);
  const name = safePart(accountName, 120);
  const info = safePart(content, 200);
  const numericAmount = Number(amount);
  if (!/^\d{4,32}$/.test(account) || !Number.isSafeInteger(numericAmount) || numericAmount <= 0 || numericAmount > 1e12) {
    throw new Error('Số tiền QR không hợp lệ.');
  }
  return `https://img.vietqr.io/image/${encodeURIComponent(bank)}-${encodeURIComponent(account)}-compact2.jpg?amount=${encodeURIComponent(numericAmount)}&addInfo=${encodeURIComponent(info)}&accountName=${encodeURIComponent(name)}`;
}

module.exports = { qrUrl };
