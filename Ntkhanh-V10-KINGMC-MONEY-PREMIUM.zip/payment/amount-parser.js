function parseAmount(input) {
  let raw = String(input ?? '').trim().toLowerCase()
    .replace(/₫|đ/g, 'd').replace(/\u00a0/g, ' ')
    .replace(/_/g, '').replace(/\s+/g, '').replace(/,/g, '');
  if (!raw) throw new Error('Thiếu số tiền.');
  if (raw === 'all') return 'all';

  // Hỗ trợ rộng hơn nhưng vẫn fail-closed: 1k, 1.5m, 1b, 1t, 1q, 1tr, 1tri.
  // Dấu chấm thập phân chỉ hợp lệ khi đứng trước đơn vị; số nguyên có phân cách
  // kiểu 1.000.000 vẫn được chấp nhận nhờ normalizeNumber.
  const suffix = raw.match(/^([0-9]+(?:\.[0-9]+)?)(k|m|b|t|q|tr|tri)?$/i);
  const compactInteger = raw.match(/^([0-9]{1,3}(?:\.[0-9]{3})+)$/);
  if (compactInteger) raw = compactInteger[1].replace(/\./g, '');

  const m = raw.match(/^([0-9]+(?:\.[0-9]+)?)(k|m|b|t|q|tr|tri)?$/i);
  if (!m) throw new Error('Số tiền không hợp lệ. Ví dụ: 1k, 1.5m, 1b, 1t, 1q, all.');
  const mult = { k:1e3, m:1e6, b:1e9, t:1e12, q:1e15, tr:1e6, tri:1e12, '':1 }[m[2] || ''];
  const value = Math.floor(Number(m[1]) * mult);
  if (!Number.isSafeInteger(value) || value <= 0) throw new Error('Số tiền không hợp lệ hoặc vượt giới hạn an toàn.');
  return value;
}
function formatAmount(n) {
  if (n === 'all') return 'all';
  return Number(n).toLocaleString('en-US');
}
function formatCompactAmount(n) {
  if (n === 'all') return 'all';
  const value = Number(n);
  if (!Number.isFinite(value)) return '0';
  for (const [u,d] of [['q',1e15],['t',1e12],['b',1e9],['m',1e6],['k',1e3]]) {
    if (Math.abs(value) >= d) {
      const x = value/d;
      return `${Number(x.toFixed(2))}${u}`;
    }
  }
  return String(Math.round(value));
}
module.exports = { parseAmount, formatAmount, formatCompactAmount };
