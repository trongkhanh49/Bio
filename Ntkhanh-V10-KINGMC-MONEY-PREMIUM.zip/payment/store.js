const fs = require('fs');
const path = require('path');
const { TTLCache } = require('../core/cache');
const { StructuredLogger } = require('../core/logger');

const dataDir = path.join(process.cwd(), 'data');
const ordersFile = path.join(dataDir, 'orders.json');
const panelsFile = path.join(dataDir, 'panels.json');
const historyFile = path.join(dataDir, 'history.json');
const backupSuffix = '.bak';
const cache = new TTLCache({ name: 'state', max: 20, ttlMs: 5000, staleMs: 30_000 });
const logger = new StructuredLogger({ name: 'state', dir: path.join(dataDir, 'logs') });

function ensure() {
  fs.mkdirSync(dataDir, { recursive: true });
  for (const file of [ordersFile, panelsFile, historyFile]) if (!fs.existsSync(file)) fs.writeFileSync(file, '[]', 'utf8');
}
function cacheKey(file) { return path.basename(file); }
function invalidate(file) { cache.delete(cacheKey(file)); }

function readJson(file, fallback) {
  ensure();
  const key = cacheKey(file);
  const cached = cache.get(key);
  if (cached !== undefined) return cached;
  try {
    const parsed = JSON.parse(fs.readFileSync(file, 'utf8'));
    if (Array.isArray(fallback) && !Array.isArray(parsed)) throw new Error('Expected array state');
    if (fallback && !Array.isArray(fallback) && (parsed === null || typeof parsed !== typeof fallback)) throw new Error('Unexpected state shape');
    cache.set(key, parsed, 5000, 30000);
    return parsed;
  } catch (error) {
    const backup = `${file}${backupSuffix}`;
    try {
      const parsedBackup = JSON.parse(fs.readFileSync(backup, 'utf8'));
      if (Array.isArray(fallback) && !Array.isArray(parsedBackup)) throw new Error('Backup state shape invalid');
      if (fallback && !Array.isArray(fallback) && (parsedBackup === null || typeof parsedBackup !== typeof fallback)) throw new Error('Backup state shape invalid');
      writeJson(file, parsedBackup, { createBackup: false });
      logger.warn('State restored from backup', { file: path.basename(file), error: error?.message });
      return parsedBackup;
    } catch (backupError) {
      const e = new Error(`State file bị hỏng hoặc không đọc được: ${path.basename(file)}`);
      e.code = 'STATE_CORRUPT'; e.cause = error; e.backupCause = backupError; throw e;
    }
  }
}

function writeJson(file, value, options = {}) {
  ensure();
  const tmp = `${file}.${process.pid}.${Date.now()}.tmp`;
  const serialized = JSON.stringify(value, null, 2);
  fs.writeFileSync(tmp, serialized, 'utf8');
  if (options.createBackup !== false && fs.existsSync(file)) {
    const backup = `${file}${backupSuffix}`;
    const backupTmp = `${backup}.${process.pid}.${Date.now()}.tmp`;
    try { fs.copyFileSync(file, backupTmp); fs.renameSync(backupTmp, backup); }
    finally { try { if (fs.existsSync(backupTmp)) fs.unlinkSync(backupTmp); } catch {} }
  }
  fs.renameSync(tmp, file);
  cache.set(cacheKey(file), value, 5000, 30000);
}
function all() { const v=readJson(ordersFile, []); return Array.isArray(v)?v:[]; }
function save(orders) {
  let list=Array.isArray(orders)?orders.slice():[];
  if(list.length>5000){
    const terminal=new Set(['completed','cancelled','pay_failed']);
    const removable=list.filter(o=>terminal.has(String(o?.status||'')));
    if(removable.length){
      const removeCount=Math.min(removable.length,list.length-5000);
      const removeSet=new Set(removable.slice(0,removeCount).map(o=>String(o.id)));
      list=list.filter(o=>!removeSet.has(String(o.id)));
    }
  }
  writeJson(ordersFile,list);
}
function panels(){const v=readJson(panelsFile,[]);return Array.isArray(v)?v:[];}
function savePanels(value){writeJson(panelsFile,Array.isArray(value)?value.slice():[]);}
function history(limit=200){
  try{const v=readJson(historyFile,[]);return Array.isArray(v)?v.slice(-Math.max(1,Math.min(Number(limit)||200,20000))):[];}
  catch(error){
    try{if(fs.existsSync(historyFile)){const corrupt=`${historyFile}.corrupt-${Date.now()}`;fs.renameSync(historyFile,corrupt);logger.error('History corrupted; isolated', { file: corrupt, error:error?.message });}fs.writeFileSync(historyFile,'[]','utf8');invalidate(historyFile);}catch{}
    return [];
  }
}
function appendHistory(event){const list=history(20000);list.push({historyId:`${Date.now()}-${Math.random().toString(36).slice(2,9)}`,at:new Date().toISOString(),...event});writeJson(historyFile,list.slice(-20000));}
function recordHistory(event){try{appendHistory(event);void logger.info('State event',event);}catch(error){console.error('[State History]',error?.stack||error);void logger.error('State history failure',{error:error?.message,event});}}
function add(order){if(!order?.id)throw new Error('Không thể lưu đơn không có ID.');const list=all();if(list.some(x=>String(x.id)===String(order.id)))throw new Error(`Đơn ${order.id} đã tồn tại.`);const now=new Date().toISOString();const value={...order,createdAt:order.createdAt||now,updatedAt:now};list.push(value);save(list);recordHistory({action:'created',orderId:value.id,type:value.type,status:value.status,discordId:value.discordId||null});return value;}
function update(id,patch){const list=all();const index=list.findIndex(x=>String(x.id)===String(id));if(index<0)return null;const before=list[index];const next={...before,...patch,updatedAt:new Date().toISOString()};list[index]=next;save(list);recordHistory({action:'updated',orderId:next.id,type:next.type,previousStatus:before.status||null,status:next.status||before.status||null,discordId:next.discordId||null,patch});return next;}
function get(id){return all().find(x=>String(x.id)===String(id))||null;}
function remove(id){const list=all();const index=list.findIndex(x=>String(x.id)===String(id));if(index<0)return null;const[removed]=list.splice(index,1);save(list);recordHistory({action:'removed',orderId:removed.id,type:removed.type,status:removed.status,discordId:removed.discordId||null});return removed;}
function addPanel(panel){if(!panel?.id)throw new Error('Panel thiếu ID.');const list=panels();if(list.some(x=>String(x.id)===String(panel.id)))throw new Error(`Panel ${panel.id} đã tồn tại.`);const now=new Date().toISOString();const value={...panel,createdAt:panel.createdAt||now,updatedAt:now};list.push(value);savePanels(list);recordHistory({action:'panel_created',panelId:value.id,type:value.type,stock:value.stock,rate:value.rate,discordId:value.createdBy||null});return value;}
function updatePanel(id,patch){const list=panels();const index=list.findIndex(x=>String(x.id)===String(id));if(index<0)return null;const before=list[index];const next={...before,...patch,updatedAt:new Date().toISOString()};list[index]=next;savePanels(list);recordHistory({action:'panel_updated',panelId:next.id,type:next.type,previousStock:before.stock,stock:next.stock,patch});return next;}
function getPanel(id){return panels().find(x=>String(x.id)===String(id))||null;}
function removePanel(id){const list=panels();const index=list.findIndex(x=>String(x.id)===String(id));if(index<0)return null;const[removed]=list.splice(index,1);savePanels(list);recordHistory({action:'panel_removed',panelId:removed.id,type:removed.type,stock:removed.stock});return removed;}
function allPanels(){return panels();}
function snapshot(){return {orders:all().length,panels:panels().length,history:history(1).length,cache:cache.stats()};}
module.exports={all,get,save,add,update,remove,panels:allPanels,addPanel,getPanel,updatePanel,removePanel,history,snapshot};
