'use strict';
const fs=require('fs');
const path=require('path');
const crypto=require('crypto');
const {EmbedBuilder,ActionRowBuilder,ButtonBuilder,ButtonStyle,AttachmentBuilder}=require('discord.js');
const {TTLCache}=require('../core/cache');
const {ResourcePool}=require('../core/resourcePool');
const {TokenBucketLimiter}=require('../core/rateLimiter');
const {StructuredLogger}=require('../core/logger');
const {premiumCardTemplate,spinFrameTemplate,escapeHtml,formatVnd}=require('../templates/cardTemplate');
const {buildSpinGifFromPngFrames}=require('../media/skinGif');

const VALID_IGN=/^[A-Za-z0-9_]{3,16}$/;
const MAX_NOTE=900;
const DEFAULT_BUY_CHANNEL='1521000179430592572';

function safeFilename(value){return String(value||'account').replace(/[^A-Za-z0-9_-]+/g,'-').replace(/^-+|-+$/g,'').slice(0,50)||'account';}

class MinecraftPremiumService{
  constructor(client,audit=null){
    this.client=client;this.audit=audit;
    this.baseDir=path.join(process.cwd(),'data','premium_accounts');fs.mkdirSync(this.baseDir,{recursive:true});
    this.cache=new Map();
    this.profileCache=new TTLCache({name:'minecraft-profile',max:500,ttlMs:10*60_000,staleMs:30*60_000});
    this.renderLimiter=new TokenBucketLimiter({capacity:3,refillPerSecond:0.2,maxKeys:500});
    this.logger=new StructuredLogger({name:'premium',dir:path.join(process.cwd(),'data','logs')});
    this.browserPool=new ResourcePool(async()=>{const puppeteer=await this.getPuppeteer();return puppeteer.launch({headless:true,args:['--no-sandbox','--disable-setuid-sandbox','--disable-dev-shm-usage','--disable-gpu','--no-zygote'],defaultViewport:{width:1600,height:1000,deviceScaleFactor:1}});},{size:1});
    this.buyChannelId=String(process.env.PREMIUM_ACCOUNT_BUY_CHANNEL_ID||DEFAULT_BUY_CHANNEL).trim();
  }
  icon(key,fallback=''){try{return this.client?.emojiManager?.get?.(key,fallback)||fallback;}catch{return fallback;}}
  async fetchJson(url,timeoutMs=8000){const controller=new AbortController();const timer=setTimeout(()=>controller.abort(),Math.max(1000,timeoutMs));try{const response=await fetch(url,{headers:{accept:'application/json','user-agent':'Ntkhanh-KingMC-Bot/3.0'},signal:controller.signal});const text=await response.text();let data;try{data=JSON.parse(text||'{}');}catch{throw new Error(`API trả về JSON không hợp lệ (HTTP ${response.status}).`);}if(!response.ok)throw new Error(String(data?.errorMessage||data?.error||data?.message||`HTTP ${response.status}`));return data;}finally{clearTimeout(timer);}}
  async fetchMinecraftProfile(name){
    const username=String(name||'').trim();if(!VALID_IGN.test(username))throw new Error('Tên acc Minecraft Premium không hợp lệ.');
    const key=username.toLowerCase();
    return this.profileCache.getOrSet(key,async()=>{
      let profile=null,lastError=null;
      try{profile=await this.fetchJson(`https://api.minecraftservices.com/minecraft/profile/lookup/name/${encodeURIComponent(username)}`,9000);}catch(error){lastError=error;try{profile=await this.fetchJson(`https://api.mojang.com/users/profiles/minecraft/${encodeURIComponent(username)}`,9000);}catch(fallback){throw new Error(`Không tìm thấy Minecraft profile Premium cho **${username}**. API: ${String(fallback?.message||lastError?.message||'không phản hồi')}`);}}
      if(!profile?.id||!profile?.name)throw new Error(`Không tìm thấy Minecraft profile Premium cho **${username}**.`);
      const uuid=String(profile.id).replace(/[^0-9a-f]/gi,'');if(uuid.length!==32)throw new Error(`Minecraft profile trả UUID không hợp lệ cho **${username}**.`);
      const session=await this.fetchJson(`https://sessionserver.mojang.com/session/minecraft/profile/${encodeURIComponent(uuid)}?unsigned=false`,9000);
      let textures=null;const property=Array.isArray(session?.properties)?session.properties.find(x=>String(x?.name||'').toLowerCase()==='textures'):null;
      if(property?.value){try{textures=JSON.parse(Buffer.from(String(property.value),'base64').toString('utf8'));}catch(error){void this.logger.warn('Texture decode failed',{username,error:error?.message});}}
      const finalName=String(session?.name||profile.name);const skinUrl=String(textures?.textures?.SKIN?.url||'').trim()||null;const capeUrl=String(textures?.textures?.CAPE?.url||textures?.textures?.ELYTRA?.url||'').trim()||null;const model=String(textures?.textures?.SKIN?.metadata?.model||'').trim()||'classic';
      return {username:finalName,uuid,uuidFormatted:this.formatUuid(uuid),skinUrl,capeUrl,skinModel:model,premiumResolved:true,profileUrl:`https://namemc.com/profile/${encodeURIComponent(finalName)}`};
    },{ttlMs:10*60_000,staleMs:30*60_000,revalidate:true});
  }
  formatUuid(uuid){const x=String(uuid||'').replace(/[^0-9a-f]/gi,'');if(x.length!==32)return uuid||'N/A';return`${x.slice(0,8)}-${x.slice(8,12)}-${x.slice(12,16)}-${x.slice(16,20)}-${x.slice(20)}`;}
  async getPuppeteer(){try{return require('puppeteer');}catch(error){throw new Error('Thiếu dependency `puppeteer`. Hãy chạy `npm install`.');}}
  buildHtml(listing){return premiumCardTemplate(listing,{theme:'NTKHANH • KINGMC'});}

  async screenshotHtml(html,outputPath){
    return this.browserPool.use(async browser=>{
      const page=await browser.newPage();try{await page.setViewport({width:1600,height:1000,deviceScaleFactor:1});await page.setContent(html,{waitUntil:'domcontentloaded',timeout:20_000});await page.evaluate(async () => { await Promise.all(Array.from(document.images).map(img => img.complete ? Promise.resolve() : new Promise(resolve => { img.addEventListener('load', resolve, { once: true }); img.addEventListener('error', resolve, { once: true }); }))); });await page.screenshot({path:outputPath,type:'png',fullPage:true});return outputPath;}finally{await page.close().catch(()=>{});}
    });
  }

  async createSpinGif(listing,outputPath){
    this.renderLimiter.assert('global',1,'Renderer đang bận, thử lại sau');
    const angles=Array.from({length:18},(_,i)=>i*20);const buffers=[];
    await this.browserPool.use(async browser=>{
      const page=await browser.newPage();try{await page.setViewport({width:760,height:760,deviceScaleFactor:1});
        for(const angle of angles){const html=spinFrameTemplate(listing,angle);await page.setContent(html,{waitUntil:'domcontentloaded',timeout:20_000});await page.evaluate(async () => { await Promise.all(Array.from(document.images).map(img => img.complete ? Promise.resolve() : new Promise(resolve => { img.addEventListener('load', resolve, { once: true }); img.addEventListener('error', resolve, { once: true }); }))); });buffers.push(await page.screenshot({type:'png'}));}
      }finally{await page.close().catch(()=>{});}
    });
    return buildSpinGifFromPngFrames(buffers,outputPath,{width:520,height:520,delayCs:8});
  }

  async createListing(interaction){
    const requester=String(interaction.user?.id||'unknown');this.renderLimiter.assert(requester,1,'Bạn tạo listing quá nhanh, vui lòng thử lại sau.');
    const rawPrice=String(interaction.options.getString('gia',true)||'').trim().replace(/[^\d.,]/g,'');const price=Number(rawPrice.replace(/\./g,'').replace(/,/g,''));
    if(!Number.isSafeInteger(price)||price<=0)throw new Error('Giá acc không hợp lệ. Hãy nhập số VNĐ, ví dụ `150000`.');
    const username=String(interaction.options.getString('tenacc',true)||'').trim();if(!VALID_IGN.test(username))throw new Error('Tên acc Minecraft không hợp lệ.');
    const capeName=String(interaction.options.getString('cape',false)||'').trim().slice(0,120);const note=String(interaction.options.getString('ghichu',false)||'').trim().slice(0,MAX_NOTE);
    await interaction.deferReply();
    const profile=await this.fetchMinecraftProfile(username);
    const id=`ACC-${crypto.randomBytes(5).toString('hex').toUpperCase()}`;
    const skinPreviewUrl=`https://mc-heads.net/body/${encodeURIComponent(profile.username)}/500.png`;
    const avatarUrl=`https://mc-heads.net/avatar/${encodeURIComponent(profile.username)}/256.png`;
    const listing={id,username:profile.username,uuid:profile.uuid,uuidFormatted:profile.uuidFormatted,skinUrl:profile.skinUrl,skinPreviewUrl,avatarUrl,capeUrl:profile.capeUrl,capeName:capeName||(profile.capeUrl?'Phát hiện từ profile':'Không có'),skinModel:profile.skinModel,premiumResolved:profile.premiumResolved,price,note,createdBy:interaction.user.id,guildId:interaction.guildId||String(process.env.GUILD_ID||'').trim()||null,sourceChannelId:interaction.channelId||null,createdAt:new Date().toISOString()};
    const html=this.buildHtml(listing);const safe=safeFilename(`${listing.username}-${listing.id}`);const htmlPath=path.join(this.baseDir,`${safe}.html`);const pngPath=path.join(this.baseDir,`${safe}.png`);const gifPath=path.join(this.baseDir,`${safe}.gif`);fs.writeFileSync(htmlPath,html,'utf8');
    let pngReady=false,gifReady=false;
    try{await this.screenshotHtml(html,pngPath);pngReady=fs.existsSync(pngPath);}catch(error){void this.logger.error('Premium PNG render failed',{listingId:id,error:error?.message});}
    if(pngReady){try{await this.createSpinGif(listing,gifPath);gifReady=fs.existsSync(gifPath);}catch(error){void this.logger.warn('Premium GIF render failed',{listingId:id,error:error?.message});}}
    if(!pngReady){const fallback=new EmbedBuilder().setTitle(`${this.icon('premium','💎')} MINECRAFT PREMIUM ACCOUNT`).setDescription('Profile đã xác minh; renderer ảnh đang tạm thời không khả dụng.').addFields({name:'Tên acc',value:`**${listing.username}**`,inline:true},{name:'Cape',value:`**${listing.capeName}**`,inline:true},{name:'Giá',value:`**${formatVnd(price)}**`,inline:true},{name:'UUID',value:`\`${listing.uuidFormatted}\``,inline:false},{name:'Ghi chú',value:listing.note||'Không có ghi chú.',inline:false}).setImage(listing.skinPreviewUrl).setTimestamp();const row=new ActionRowBuilder().addComponents(new ButtonBuilder().setLabel('Mua acc').setStyle(ButtonStyle.Link).setURL(this.buildBuyUrl(listing.guildId)));await interaction.editReply({content:`⚠️ **Đăng bán ${listing.id}**`,embeds:[fallback],components:[row]});}
    else {
      const buyUrl=this.buildBuyUrl(listing.guildId);const files=[new AttachmentBuilder(pngPath,{name:`${safe}.png`})];if(gifReady)files.push(new AttachmentBuilder(gifPath,{name:`${safe}.gif`}));
      const embed=new EmbedBuilder().setTitle(`${this.icon('premium','💎')} ${listing.username} • PREMIUM ACCOUNT`).setDescription(`${gifReady?'🌀 GIF skin xoay 3D đã được tạo. ':' ' }Thông tin profile được xác minh từ Minecraft services.`).addFields({name:'👤 Tên acc',value:`**${listing.username}**`,inline:true},{name:'💵 Giá',value:`**${formatVnd(listing.price)}**`,inline:true},{name:'🪽 Cape',value:`**${listing.capeName}**`,inline:true},{name:'🧬 UUID',value:`\`${listing.uuidFormatted}\``,inline:false},{name:'📝 Ghi chú',value:listing.note||'Không có ghi chú.',inline:false}).setImage(`attachment://${gifReady?`${safe}.gif`:`${safe}.png`}`).setFooter({text:`ID listing: ${listing.id} • ${gifReady?'PNG + GIF':'PNG only'}`}).setTimestamp();
      const row=new ActionRowBuilder().addComponents(new ButtonBuilder().setLabel('🛒 Mua acc').setStyle(ButtonStyle.Link).setURL(buyUrl));
      await interaction.editReply({content:`${this.icon('success','✅')} **ĐÃ TẠO LISTING ACC PREMIUM • ${listing.id}**`,embeds:[embed],components:[row],files});
    }
    this.cache.set(id,listing);fs.writeFileSync(path.join(this.baseDir,`${safe}.json`),JSON.stringify({...listing,htmlPath,pngPath,gifPath:gifReady?gifPath:null},null,2),'utf8');
    void this.logger.info('Premium listing created',{listingId:id,username:listing.username,price:listing.price,gifReady,pngReady,createdBy:interaction.user.id});
    if(this.audit)void this.audit.event('💎 AUDIT • PREMIUM ACCOUNT','Tạo listing Minecraft Premium thành công.',[{name:'Listing',value:id,inline:true},{name:'Người tạo',value:`<@${interaction.user.id}>`,inline:true},{name:'Tên acc',value:listing.username,inline:true},{name:'Giá',value:formatVnd(price),inline:true},{name:'Cape',value:listing.capeName,inline:true},{name:'Media',value:`PNG: ${pngReady?'YES':'NO'} • GIF: ${gifReady?'YES':'NO'}`,inline:false},{name:'Mua tại',value:`<#${this.buyChannelId}>`,inline:true}],{color:0x8b5cf6});
    return listing;
  }
  async shutdown(){
    try { await this.browserPool?.close(async browser => browser?.close?.()); } catch(error){ void this.logger.warn('Premium renderer shutdown failed',{error:error?.message||String(error)}); }
    void this.logger.info('Premium renderer shutdown complete');
  }
  buildBuyUrl(guildId){const gid=String(guildId||process.env.GUILD_ID||'').trim();if(!/^\d{15,22}$/.test(gid))throw new Error('Thiếu GUILD_ID nên không tạo được nút chuyển tới kênh mua acc.');if(!/^\d{15,22}$/.test(this.buyChannelId))throw new Error('PREMIUM_ACCOUNT_BUY_CHANNEL_ID không hợp lệ.');return`https://discord.com/channels/${gid}/${this.buyChannelId}`;}
}
module.exports=MinecraftPremiumService;
