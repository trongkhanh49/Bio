const crypto = require('crypto');
const path = require('path');
const { TTLCache } = require('../core/cache');
const { TokenBucketLimiter } = require('../core/rateLimiter');
const { TaskQueue } = require('../core/taskQueue');
const { MetricsRegistry } = require('../core/metrics');
const { StructuredLogger } = require('../core/logger');
const { inspectMinecraftMessage } = require('../core/messageGuard');
const AutoBank = require('../autobank');
const store = require('./store');
const { parseAmount, formatAmount } = require('./amount-parser');
const { qrUrl } = require('./qr');
const {
  EmbedBuilder,
  ActionRowBuilder,
  ButtonBuilder,
  ButtonStyle,
  ModalBuilder,
  TextInputBuilder,
  TextInputStyle,
  ChannelType,
  PermissionFlagsBits,
  AttachmentBuilder,
  MessageFlags,
  SlashCommandBuilder
} = require('discord.js');

const VALID_IGN = /^[A-Za-z0-9_]{3,16}$/;
const ADMIN_COMMANDS = new Set(['pay', 'thumon', 'banmon', 'upstock', 'status', 'checkbot', 'thongke', 'bdsd', 'lichsu']);
const LEGIT_USER_ID = String(process.env.LEGIT_USER_ID || '989724139243843675').trim();
const SUPPORT_SERVER_URL = 'https://discord.gg/6dwbnHMYTW';
const RESERVATION_TTL_MS = Math.max(5 * 60 * 1000, Number(process.env.RESERVATION_TTL_MS) || 30 * 60 * 1000);

const RESERVABLE_STATUSES = new Set([
  'pending_confirm',
  'await_ingame',
  'await_qr',
  'admin_review',
  'await_bank',
  'processing_bank',
  'manual_review',
  'await_game_pay'
]);

function cleanName(name) {
  const value = String(name || '').trim();
  if (!VALID_IGN.test(value)) {
    throw new Error('Tên Minecraft không hợp lệ. Chỉ dùng A-Z, a-z, 0-9 và _.');
  }
  return value;
}

function moneyRate(value) {
  const raw = String(value ?? '').trim().replace(/,/g, '').replace(/\s+/g, '');
  const n = Number(raw);
  if (!Number.isSafeInteger(n) || n <= 0 || n > 1e9) throw new Error('RT / 1M không hợp lệ.');
  return n;
}

function calcVnd(amount, rate) {
  const value = Math.round((Number(amount) / 1_000_000) * Number(rate));
  if (!Number.isSafeInteger(value) || value <= 0) throw new Error('Số tiền VNĐ không hợp lệ.');
  return value;
}

function makeId(prefix = 'KX') {
  return `${prefix}-${crypto.randomBytes(5).toString('hex').toUpperCase()}`;
}

function normalize(text) {
  return String(text || '')
    .normalize('NFD')
    .replace(/[\u0300-\u036f]/g, '')
    .replace(/Đ/g, 'D')
    .replace(/đ/g, 'd')
    .toLowerCase();
}

function digits(text) {
  return String(text || '').replace(/\D/g, '');
}

function moneyVariants(amount) {
  const n = Number(amount);
  const out = new Set([String(n), n.toLocaleString('en-US'), n.toLocaleString('vi-VN')]);
  const units = [['k', 1e3], ['m', 1e6], ['b', 1e9], ['t', 1e12], ['q', 1e15]];
  for (const [unit, divisor] of units) {
    const value = n / divisor;
    if (Number.isFinite(value) && value > 0) {
      const text = Number.isInteger(value)
        ? String(value)
        : value.toFixed(6).replace(/0+$/, '').replace(/\.$/, '');
      out.add(`${text}${unit}`);
      out.add(`${text} ${unit}`);
      out.add(`${text}${unit.toUpperCase()}`);
      out.add(`${text} ${unit.toUpperCase()}`);
    }
  }
  return [...out].filter(Boolean);
}

function formatCompactMoney(amount) {
  const n = Number(amount);
  if (!Number.isFinite(n)) return '0';
  for (const [unit, divisor] of [['q',1e15],['t',1e12],['b',1e9],['m',1e6],['k',1e3]]) {
    if (Math.abs(n) >= divisor) {
      const value = n / divisor;
      const text = Number.isInteger(value) ? String(value) : value.toFixed(2).replace(/0+$/, '').replace(/\.$/, '');
      return `${text}${unit}`;
    }
  }
  return String(Math.round(n));
}

function parseMoneyOrVnd(text) {
  const raw = String(text ?? '').trim().replace(/\s+/g, '');
  if (!raw) throw new Error('Hãy nhập số tiền.');
  const lower = raw.toLowerCase().replace(/₫/g, 'đ');
  const isVnd = /(?:đ|vnd|vnđ)$/.test(lower);
  if (isVnd) {
    const numeric = lower.replace(/(?:vnd|vnđ|đ)$/i, '').replace(/,/g, '');
    const n = Number(numeric);
    if (!Number.isSafeInteger(n) || n <= 0) throw new Error('Số VNĐ không hợp lệ. Ví dụ: 2500đ');
    return { kind: 'vnd', value: n };
  }
  const suffix = lower.match(/^([0-9]+(?:\.[0-9]+)?)(k|m|b|t|q)$/i);
  if (suffix) {
    const base = Number(suffix[1]);
    const mult = { k:1e3, m:1e6, b:1e9, t:1e12, q:1e15 }[suffix[2].toLowerCase()];
    const n = base * mult;
    if (!Number.isSafeInteger(n) || n <= 0) throw new Error('Số Money không hợp lệ.');
    return { kind:'money', value:n };
  }
  const n = Number(lower.replace(/,/g, ''));
  if (!Number.isSafeInteger(n) || n <= 0) throw new Error('Số tiền không hợp lệ. Dùng 50m hoặc 2500đ.');
  return { kind:'money', value:n };
}

function normalizePaymentText(value) {
  return String(value || '')
    .normalize('NFD')
    .replace(/[\u0300-\u036f]/g, '')
    .replace(/Đ/g, 'D')
    .replace(/đ/g, 'd')
    .replace(/ᴀ/g,'a').replace(/ʙ/g,'b').replace(/ᴄ/g,'c').replace(/ᴅ/g,'d')
    .replace(/ᴇ/g,'e').replace(/ғ/g,'f').replace(/ɢ/g,'g').replace(/ʜ/g,'h')
    .replace(/ɪ/g,'i').replace(/ᴊ/g,'j').replace(/ᴋ/g,'k').replace(/ʟ/g,'l')
    .replace(/ᴍ/g,'m').replace(/ɴ/g,'n').replace(/ᴏ/g,'o').replace(/ᴘ/g,'p')
    .replace(/ǫ/g,'q').replace(/ʀ/g,'r').replace(/ꜱ/g,'s').replace(/ᴛ/g,'t')
    .replace(/ᴜ/g,'u').replace(/ᴠ/g,'v').replace(/ᴡ/g,'w').replace(/ʏ/g,'y').replace(/ᴢ/g,'z')
    .toLowerCase();
}

function containsMinecraftName(text, name) {
  const target = normalizePaymentText(name).trim();
  const source = normalizePaymentText(text);
  if (!target || !source) return false;
  const escaped = target.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
  return new RegExp(`(?<![a-z0-9_])${escaped}(?![a-z0-9_])`, 'i').test(source);
}

function containsMoneyAmount(text, amount) {
  const source = normalizePaymentText(text);
  const raw = String(text || '');
  if (!source && !raw) return false;
  for (const variant of moneyVariants(amount)) {
    const normalizedVariant = normalizePaymentText(variant);
    if (!normalizedVariant) continue;
    const escaped = normalizedVariant.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
    if (new RegExp(`(?<![a-z0-9])${escaped}(?![a-z0-9])`, 'i').test(source)) return true;
  }
  return false;
}

function chatPaymentProof(text, player, botName, amount) {
  const raw = String(text || '').trim();
  if (!raw) return { success: false, amountMatched: false, botMentioned: false, buyerMentioned: false, proof: false };

  // Fail-closed cho các format chat của member nếu vì lý do nào đó worker
  // chưa gắn metadata isPlayerChat. Không cho chat giả dạng server xác nhận tiền.
  const looksLikePlayerChat =
    /^<[^>]{1,32}>\s+/.test(raw) ||
    /^[A-Za-z0-9_]{3,16}\s*[:»>]-?\s+/i.test(raw) ||
    /(?:^|\s)[A-Za-z0-9_]{3,16}\s*[»>]\s+/i.test(raw);
  if (looksLikePlayerChat) {
    return { success: false, amountMatched: false, botMentioned: false, buyerMentioned: false, proof: false, ignoredPlayerChat: true };
  }

  const low = normalizePaymentText(raw);
  const p = normalizePaymentText(player).trim();
  const bot = normalizePaymentText(botName).trim();
  if (!p || !bot) return { success: false, amountMatched: false, botMentioned: false, buyerMentioned: false, proof: false };

  // KingMC thường trả về nhiều kiểu xác nhận, ví dụ:
  // "Bạn đã chuyển cho ntkhanh $50M"
  // "Đã chuyển $50,000,000 cho ntkhanh"
  // "Paid ntkhanh $50m"
  // "You sent 50M to ntkhanh"
  // Không được phụ thuộc vào đúng một format chat.
  const compactLow = low.replace(/[^a-z0-9]/g, '');
  const rawDigits = digits(raw);
  const exactAmount = moneyVariants(amount).some(variant => {
    const normalizedVariant = normalizePaymentText(variant).trim();
    if (!normalizedVariant) return false;

    const compactVariant = normalizedVariant.replace(/[^a-z0-9]/g, '');
    const variantDigits = digits(variant);

    if (low.includes(normalizedVariant)) return true;
    if (compactVariant && compactLow.includes(compactVariant)) return true;

    // $50M / 50 M / 50m và số đầy đủ có dấu phân cách.
    if (variantDigits.length >= 4 && rawDigits.includes(variantDigits)) return true;
    return false;
  });

  if (!exactAmount) {
    return { success: false, amountMatched: false, botMentioned: false, buyerMentioned: false, proof: false };
  }

  const botMentioned = containsMinecraftName(raw, botName) || low.includes(bot);
  const buyerMentioned = !!p && (containsMinecraftName(raw, player) || low.includes(p));
  const commandEcho = low.includes(`/pay ${bot}`) || low.includes(`/pay${bot}`);

  if (!botMentioned && !commandEcho) {
    return { success: false, amountMatched: true, botMentioned: false, buyerMentioned, proof: false };
  }

  const successWords = [
    'da chuyen',
    'da gui',
    'chuyen thanh cong',
    'gui thanh cong',
    'thanh cong',
    'paid',
    'sent',
    'transfer successful',
    'payment successful',
    'you paid',
    'you sent',
    'ban da chuyen',
    'da chuyen cho',
    'chuyen cho',
    'chuyen toi',
    'gui cho'
  ];

  const success = successWords.some(word => low.includes(word));

  return {
    success,
    amountMatched: true,
    botMentioned,
    buyerMentioned,
    proof: !!success && !!botMentioned
  };
}

class PaymentService {
  constructor(client, localMcBot) {
    this.client = client;
    this.localMcBot = localMcBot;
    this.secret = String(process.env.WORKER_SECRET || '').trim();
    this.workerUrl = String(
      process.env.PAYMENT_WORKER_URL ||
      process.env.MC_WORKER_URL ||
      process.env.WORKER_URL ||
      (process.env.WORKER_URLS || '').split(',')[0] || ''
    ).replace(/\/+$/, '');

    this.bank = new AutoBank();
    this.adminIds = new Set(
      String(process.env.PAY_ADMIN_IDS || process.env.ADMIN_ID || '')
        .split(',').map(x => x.trim()).filter(Boolean)
    );
    this.botName = null;
    this.started = false;
    this.autoBankEnabled = false;
    this.chatCursor = 0;
    this.processing = new Set();
    this.liveOrderReplies = new Map();
    this.stockLock = Promise.resolve();
    this.stockLockDepth = 0;
    this.reservationTimer = null;
    this.refreshTimer = null;
    this.bankRetryTimer = null;
    this.bankRetryRunning = false;
    this.chatRetry = new Map();
    this.chatPollTimer = null;
    this.chatPollStopped = false;
    this.ticketProcessing = new Set();
    this.supportButtonUrl = SUPPORT_SERVER_URL;
    this.audit = client?.auditLogger || null;
    this.emojiManager = client?.emojiManager || null;
    this.lastBotBalance = null;
    this.lastBotBalanceAt = null;
    this.lastBankTransactions = [];
    this.lastGamePayments = [];
    this.workerRequestTimeoutMs = Math.max(3000, Number(process.env.WORKER_REQUEST_TIMEOUT_MS) || 12000);
    this.discordOperationTimeoutMs = Math.max(3000, Number(process.env.DISCORD_OPERATION_TIMEOUT_MS) || 10000);
    this.metrics = new MetricsRegistry();
    this.logger = new StructuredLogger({ name: 'payment', dir: path.join(process.cwd(), 'data', 'logs') });
    this.interactionLimiter = new TokenBucketLimiter({ capacity: 35, refillPerSecond: 7, maxKeys: 20000 });
    this.checkbotCache = new TTLCache({ name: 'checkbot', max: 2, ttlMs: 2500, staleMs: 7500 });
    this.statusCache = new TTLCache({ name: 'status', max: 2, ttlMs: 1500, staleMs: 5000 });
    this.discordFetchCache = new TTLCache({ name: 'discord', max: 200, ttlMs: 10000, staleMs: 30000 });
    this.operationQueue = new TaskQueue({ name: 'payment-operations', concurrency: 4, maxPending: 300 });
    this.dmQueue = new TaskQueue({ name: 'discord-dm', concurrency: 4, maxPending: 1000 });
    this.lastBotStats = null;

    // Nhận QR user gửi trong DM. Chỉ bật sau khi client đã có MessageContent + DM partial.
    this.client.on('messageCreate', message => {
      this.handleDiscordMessage(message).catch(error => {
        console.error('[QR Receiver]', error?.stack || error?.message || error);
      });
    });
  }

  icon(key, fallback = '') {
    try {
      return this.emojiManager?.get?.(key, fallback) || fallback;
    } catch {
      return fallback;
    }
  }

  buttonEmoji(key, fallback = '') {
    try {
      return this.emojiManager?.getObject?.(key, fallback) || null;
    } catch {
      return fallback ? { name: fallback } : null;
    }
  }

  isAdmin(userId) {
    return this.adminIds.has(String(userId || ''));
  }

  validatePanelValues(stock, rate) {
    if (!Number.isSafeInteger(Number(stock)) || Number(stock) <= 0) throw new Error('Stock phải là số nguyên dương và nằm trong phạm vi an toàn.');
    if (!Number.isSafeInteger(Number(rate)) || Number(rate) <= 0 || Number(rate) > 1e9) throw new Error('RT / 1M không hợp lệ.');
  }

  isReservationExpired(order) {
    // Đơn trade mới trừ stock ngay khi tạo. TTL chỉ áp dụng khi đơn vẫn đang
    // chờ user xác nhận; không tự hủy sau khi đã chuyển sang các bước giao tiền.
    const status = String(order?.status || '');
    if (status !== 'pending_confirm') return false;
    const started = Number(order?.createdAtMs || new Date(order?.createdAt || 0).getTime() || 0);
    return started > 0 && Date.now() - started > RESERVATION_TTL_MS;
  }

  async expireStaleReservations() {
    const stale = store.all().filter(order =>
      order.stockReserved === true &&
      this.isReservationExpired(order)
    );
    if (!stale.length) return 0;
    for (const order of stale) {
      const fresh = store.get(order.id);
      if (!fresh || !fresh.stockReserved || !this.isReservationExpired(fresh)) continue;
      try {
        await this.restorePanelStockForOrder(fresh, 'reservation expired');
      } catch (error) {
        store.update(order.id, {
          status: 'manual_review',
          lastError: `Không thể hoàn stock khi đơn hết hạn: ${String(error?.message || error)}`,
          stockReviewAt: new Date().toISOString()
        });
        await this.notifyAdmins(`⚠️ **STOCK REVIEW • ĐƠN HẾT HẠN**\nĐơn: ${order.id}\nLỗi: ${String(error?.message || error)}`);
        continue;
      }
      store.update(order.id, {
        status: 'cancelled',
        stockReserved: false,
        cancelledAt: new Date().toISOString(),
        cancelReason: 'reservation expired'
      });
      await this.editLiveOrderReply(order.id, { content: `⏱️ **Đơn ${order.id} đã hết thời gian xác nhận và được hủy tự động. Stock đã hoàn lại.**`, embeds: [], components: [] }).catch(() => {});
      this.forgetLiveOrderReply(order.id);
      await this.safeDM(order.discordId, `⏱️ **Đơn ${order.id} đã hết thời gian xác nhận và được hủy tự động.** Stock đã được hoàn lại. Vui lòng tạo đơn mới.`);
    }
    return stale.length;
  }

  assertAdmin(interaction) {
    if (!this.adminIds.size) throw new Error('Chưa cấu hình ADMIN_ID/PAY_ADMIN_IDS.');
    if (!this.isAdmin(interaction.user?.id)) throw new Error('⛔ Chỉ Admin Bot mới được dùng lệnh này.');
  }

  assertOwner(order, interaction) {
    if (!order) throw new Error('Không tìm thấy đơn.');
    if (String(order.discordId) !== String(interaction.user?.id)) throw new Error('⛔ Bạn không sở hữu đơn này.');
  }

  fallbackBotName() {
    const local = String(this.localMcBot?.credentials?.username || '').trim();
    if (VALID_IGN.test(local)) return local;
    const explicit = String(process.env.MC_BOT_NAME || 'ntkhanh').trim();
    if (VALID_IGN.test(explicit)) return explicit;
    // Tách Discord/Minecraft Worker: tuyệt đối không lấy MC_USERNAME của Discord
    // làm nguồn chính vì nó có thể là IGN cũ. Chờ /api/checkbot của Worker.
    if (this.workerUrl) return 'Đang đồng bộ...';
    const env = String(process.env.MC_USERNAME || '').trim();
    return VALID_IGN.test(env) ? env : 'Đang đồng bộ...';
  }

  getBotName() {
    if (VALID_IGN.test(String(this.botName || '').trim())) return this.botName.trim();
    return this.fallbackBotName();
  }

  getKingMcServer() {
    const raw = String(process.env.MC_SERVER_HOSTS || 'sgp.kingmc.vn,kingmc.vn');
    const host = raw.split(',').map(value => value.trim()).find(Boolean) || 'sgp.kingmc.vn';
    const port = Number(process.env.MC_SERVER_PORT || 25565);
    return `${host}:${Number.isInteger(port) && port > 0 ? port : 25565}`;
  }

  async refreshBotName(timeoutMs = 1500) {
    const local = String(this.localMcBot?.credentials?.username || '').trim();
    if (VALID_IGN.test(local)) {
      this.botName = local;
      return local;
    }

    if (this.workerUrl) {
      try {
        const data = await this.fetchWorkerJson('/api/checkbot', timeoutMs);
        const remoteName = String(data?.snapshot?.username || '').trim();
        if (VALID_IGN.test(remoteName)) {
          this.botName = remoteName;
          return remoteName;
        }
      } catch (error) {
        console.warn('[MC-Bot] Sync IGN:', error?.message || error);
      }
    }
    return this.getBotName();
  }

  async requestWorker(pathname, options = {}) {
    if (this.localMcBot) {
      if (pathname === '/api/pay') {
        const body = JSON.parse(options.body || '{}');
        return this.localMcBot.pay(body.player, Number(body.amount), Number(body.timeoutMs) || 12000, body.requestId || null);
      }
      if (pathname.startsWith('/api/chat')) {
        const since = Number(new URL(`http://local${pathname}`).searchParams.get('since') || 0);
        return {
          success: true,
          messages: this.localMcBot.getChatSince(since),
          nextSince: this.localMcBot.chatSequence
        };
      }
      if (pathname === '/api/checkbot') {
        return this.getLocalCheckBotData();
      }
      if (pathname === '/health') {
        return { success: true, online: !!this.localMcBot.isBotOnline, ready: !!this.localMcBot.isReady, mc: this.getLocalSnapshot() };
      }
    }

    if (!this.workerUrl) throw new Error('Chưa cấu hình Worker URL.');

    const controller = new AbortController();
    const pathnameLower = String(pathname || '').toLowerCase();
    const timeoutMs = Math.max(3000, Number(
      options.timeoutMs ||
      (pathnameLower.startsWith('/api/chat') ? process.env.PAYMENT_CHAT_REQUEST_TIMEOUT_MS :
       pathnameLower === '/api/pay' ? process.env.PAY_REQUEST_TIMEOUT_MS :
       process.env.WORKER_REQUEST_TIMEOUT_MS) ||
      this.workerRequestTimeoutMs
    ));
    const timer = setTimeout(() => controller.abort(), timeoutMs);
    const cacheable = options.method == null || String(options.method).toUpperCase() === 'GET';
    if (cacheable && !pathnameLower.startsWith('/api/chat')) {
      const cached = this.discordFetchCache.get(`worker:${pathname}`, { meta: true });
      if (cached.hit && !cached.stale) return cached.value;
    }

    try {
      const fetchOptions = { ...options };
      delete fetchOptions.timeoutMs;
      fetchOptions.signal = controller.signal;
      const response = await fetch(this.workerUrl + pathname, {
        ...fetchOptions,
        headers: {
          accept: 'application/json',
          'content-type': 'application/json',
          ...(this.secret ? { 'x-worker-secret': this.secret } : {}),
          ...(options.headers || {})
        }
      });
      const text = await response.text();
      let data;
      try { data = JSON.parse(text || '{}'); }
      catch { throw new Error(`Worker trả về JSON không hợp lệ (HTTP ${response.status}).`); }
      if (!response.ok || data?.success === false) throw new Error(data?.error || `Worker HTTP ${response.status}`);
      if (cacheable && !pathnameLower.startsWith('/api/chat')) this.discordFetchCache.set(`worker:${pathname}`, data, pathnameLower === '/health' ? 1500 : 2500, 7500);
      return data;
    } catch (error) {
      if (error?.name === 'AbortError') {
        const timeoutError = new Error(`Worker timeout sau ${Math.ceil(timeoutMs / 1000)} giây.`);
        if (pathnameLower === '/api/pay') timeoutError.payOutcomeUnknown = true;
        throw timeoutError;
      }
      throw error;
    } finally {
      clearTimeout(timer);
    }
  }

  async requestWorkerFromUrl(baseUrl, pathname, options = {}) {
    const base = String(baseUrl || '').replace(/\/+$/, '');
    if (!base) throw new Error('Worker URL rỗng.');
    const controller = new AbortController();
    const timeoutMs = Math.max(3000, Number(options.timeoutMs) || 10000);
    const timer = setTimeout(() => controller.abort(), timeoutMs);
    try {
      const response = await fetch(base + pathname, {
        ...options,
        signal: controller.signal,
        headers: { accept: 'application/json', 'content-type': 'application/json', ...(this.secret ? { 'x-worker-secret': this.secret } : {}), ...(options.headers || {}) }
      });
      const text = await response.text();
      let data;
      try { data = JSON.parse(text || '{}'); } catch { throw new Error(`Worker trả về JSON không hợp lệ (HTTP ${response.status}).`); }
      if (!response.ok || data?.success === false) throw new Error(data?.error || `Worker HTTP ${response.status}`);
      return data;
    } catch (error) {
      if (error?.name === 'AbortError') throw new Error(`Worker timeout sau ${Math.ceil(timeoutMs / 1000)} giây.`);
      throw error;
    } finally { clearTimeout(timer); }
  }

  async fetchWorkerJson(pathname, timeoutMs = 7000) {
    if (this.localMcBot) return this.requestWorker(pathname);
    if (!this.workerUrl) throw new Error('Chưa cấu hình Worker URL.');
    const controller = new AbortController();
    const timer = setTimeout(() => controller.abort(), timeoutMs);
    const startedAt = Date.now();
    try {
      const response = await fetch(this.workerUrl + pathname, {
        signal: controller.signal,
        headers: {
          accept: 'application/json',
          ...(this.secret ? { 'x-worker-secret': this.secret } : {})
        }
      });
      const text = await response.text();
      let data;
      try { data = JSON.parse(text || '{}'); }
      catch { throw new Error(`Worker trả về JSON không hợp lệ (HTTP ${response.status}).`); }
      if (!response.ok || data?.success === false) throw new Error(data?.error || `Worker HTTP ${response.status}`);
      return { ...data, _httpStatus: response.status, _latencyMs: Date.now() - startedAt };
    } catch (error) {
      if (error?.name === 'AbortError') throw new Error(`Worker timeout sau ${Math.ceil(Number(timeoutMs) / 1000)} giây.`);
      throw error;
    } finally {
      clearTimeout(timer);
    }
  }

  async pay(player, amount, operationId = null) {
    return this.requestWorker('/api/pay', {
      method: 'POST',
      body: JSON.stringify({
        player,
        amount,
        timeoutMs: Number(process.env.PAY_TIMEOUT_MS) || 12000,
        requestId: operationId || null
      })
    });
  }

  getLocalSnapshot() {
    if (typeof this.localMcBot?.getStatusSnapshot === 'function') return this.localMcBot.getStatusSnapshot();
    return {
      username: this.localMcBot?.credentials?.username || null,
      online: !!this.localMcBot?.isBotOnline,
      ready: !!this.localMcBot?.isReady,
      currentAction: this.localMcBot?.currentAction || null,
      server: `${this.localMcBot?.hosts?.[this.localMcBot?.currentHostIndex] || 'unknown'}:${this.localMcBot?.port || ''}`
    };
  }

  async getLocalCheckBotData() {
    const snapshot = this.getLocalSnapshot();
    let balance = null;
    let balanceError = null;
    let stats = this.lastBotStats || this.localMcBot?.lastStatsResult || null;
    let statsError = null;
    if (!snapshot.online) balanceError = 'Minecraft bot đang offline.';
    else if (this.localMcBot.currentAction || this.localMcBot.targetPlayer) balanceError = `Bot đang bận: ${this.localMcBot.currentAction || 'unknown'}.`;
    else {
      try {
        balance = await this.localMcBot.getBalance(this.localMcBot.credentials.username, Number(process.env.CHECKBOT_TIMEOUT_MS) || 12000);
        this.lastBotBalance = balance;
        this.lastBotBalanceAt = new Date().toISOString();
      } catch (error) { balanceError = error?.message || String(error); }
      try {
        if (!this.localMcBot.currentAction && !this.localMcBot.targetPlayer && this.localMcBot.isBotOnline && this.localMcBot.isReady) {
          stats = await this.localMcBot.getStats(this.localMcBot.credentials.username, Number(process.env.CHECKBOT_STATS_TIMEOUT_MS) || 12000);
          this.lastBotStats = stats;
        }
      } catch (error) { statsError = error?.message || String(error); }
    }
    return { success: true, snapshot: this.localMcBot.getStatusSnapshot?.() || snapshot, balance, balanceError, stats, statsError, lastBotBalance: this.lastBotBalance, lastBotBalanceAt: this.lastBotBalanceAt };
  }

  async ensureUpstockCommand() {
    try {
      if (!this.client.application?.commands) return false;
      const guildId = String(process.env.GUILD_ID || process.env.SYNC_GUILD_ID || '').trim() || undefined;
      const commandData = new SlashCommandBuilder()
        .setName('upstock')
        .setDescription('Admin cộng thêm stock và tùy chọn đổi RT / 1M')
        .addStringOption(opt => opt.setName('message_id').setDescription('Message ID của panel cần UpStock').setRequired(true))
        .addStringOption(opt => opt.setName('stock').setDescription('Stock cộng thêm, ví dụ 50m / 1b').setRequired(true))
        .addStringOption(opt => opt.setName('rt_1m').setDescription('RT / 1M mới, để trống nếu giữ nguyên').setRequired(false));

      const collection = guildId
        ? await this.client.application.commands.fetch({ guildId })
        : await this.client.application.commands.fetch();
      const existing = collection.find(cmd => cmd.name === 'upstock');
      if (existing) await existing.edit(commandData.toJSON());
      else await this.client.application.commands.create(commandData.toJSON(), guildId);
      return true;
    } catch (error) {
      console.warn('[Slash] Không đăng ký được /upstock tự động:', error?.message || error);
      return false;
    }
  }

  async restorePersistentPanels() {
    // Panel Mua/Bán là message persistent: không dùng collector timeout.
    // Sau khi bot restart, đọc lại panel đã lưu và đồng bộ lại buttons để panel cũ
    // tiếp tục hoạt động vô hạn cho đến khi Admin bấm SOLD/đóng panel.
    try {
      const getter = typeof store.allPanels === 'function'
        ? () => store.allPanels()
        : (typeof store.panels === 'function' ? () => store.panels() : () => []);
      const panels = getter();
      if (!Array.isArray(panels) || !panels.length) return 0;

      let restored = 0;
      for (const rawPanel of panels) {
        const panel = rawPanel || {};
        if (!panel.messageId || !panel.channelId) continue;
        if (panel.persistent !== true) {
          const updated = store.updatePanel(panel.id, { persistent: true });
          if (updated) Object.assign(panel, updated);
        }
        try {
          const channel = await this.client.channels.fetch(String(panel.channelId));
          if (!channel?.isTextBased?.()) continue;
          const message = await channel.messages.fetch(String(panel.messageId));
          await message.edit({
            embeds: [this.buildPanelEmbed(panel)],
            components: [this.buildPanelButtons(panel)]
          });
          restored += 1;
        } catch (error) {
          // Panel/message có thể đã bị xóa hoặc bot mất quyền; bỏ qua để startup không fail.
          console.warn(`[Panel Persistent] Không restore được ${panel.id || 'unknown'}:`, error?.message || error);
        }
      }
      if (restored) console.log(`[Panel Persistent] ✅ Đã restore ${restored} panel Mua/Bán.`);
      return restored;
    } catch (error) {
      console.warn('[Panel Persistent] Restore lỗi:', error?.message || error);
      return 0;
    }
  }

  async start() {
    if (this.started) return;
    this.started = true;
    this.chatPollStopped = false;
    await this.ensureUpstockCommand();
    try {
      if (!this.emojiManager?.loaded) await this.emojiManager?.load?.();
    } catch (error) {
      console.warn('[Emoji] PaymentService load:', error?.message || error);
    }
    await this.restorePersistentPanels();

    this.bank.on('error', error => console.error('[AutoBank]', error?.stack || error?.message || error));
    this.bank.on('transaction', tx => {
      this.handleBankTransaction(tx).catch(error => console.error('[AutoBank handler]', error?.stack || error?.message || error));
    });

    if (this.bank.token && !this.bank.configError) {
      this.autoBankEnabled = true;
      this.bank.start();
      console.log('[AutoBank] ✅ Đã bật.');
    } else if (this.bank.configError) {
      console.error('[AutoBank] ❌ Cấu hình không hợp lệ:', this.bank.configError.message);
    } else {
      console.warn('[AutoBank] ⚠️ Thiếu THUEAPIBANK_TOKEN; /banmon sẽ báo lỗi khi thanh toán.');
    }

    // Đồng bộ IGN ngay lúc startup và tiếp tục refresh định kỳ nhưng không chặn Discord.
    this.refreshBotName(2000).catch(() => {});
    this.refreshTimer = setInterval(() => this.refreshBotName(1500).catch(() => {}), 30000);
    await this.expireStaleReservations().catch(error => console.warn('[Reservation Cleanup]', error?.message || error));
    this.reservationTimer = setInterval(() => this.expireStaleReservations().catch(error => console.warn('[Reservation Cleanup]', error?.message || error)), 60000);
    await this.reconcileStockDeductions().catch(error => console.error('[Stock Reconcile]', error?.stack || error?.message || error));
    this.pollChat();
    this.bankRetryTimer = setInterval(() => this.retryPendingBankPays().catch(error => console.error('[Bank Pay Retry]', error?.stack || error?.message || error)), Math.max(3000, Number(process.env.BANK_PAY_RETRY_MS) || 5000));
  }

  async pollChat() {
    if (this.chatPollTimer) return;
    const interval = Math.max(400, Number(process.env.PAYMENT_CHAT_POLL_MS) || 500);
    const loop = async () => {
      if (this.chatPollStopped) {
        this.chatPollTimer = null;
        return;
      }
      try {
        const data = await this.requestWorker('/api/chat?since=' + this.chatCursor, { timeoutMs: Number(process.env.PAYMENT_CHAT_REQUEST_TIMEOUT_MS) || 8000 });
        const messages = Array.isArray(data.messages) ? data.messages : [];
        const retryMessages = [...this.chatRetry.values()];
        this.chatRetry.clear();

        if ((messages.length || retryMessages.length) && process.env.DEBUG_PAYMENT === '1') {
          console.log(`[Chat Poll] since=${this.chatCursor} received=${messages.length} retry=${retryMessages.length} next=${Number(data.nextSince || this.chatCursor)}`);
        }

        const batch = new Map();
        for (const message of [...retryMessages, ...messages]) {
          const key = String(message?.id ?? `${message?.at || ''}:${message?.text || ''}`);
          if (!batch.has(key)) batch.set(key, message);
        }

        for (const message of batch.values()) {
          let timeoutId = null;
          try {
            await Promise.race([
              this.handleIncomingChat(message),
              new Promise((_, reject) => {
                timeoutId = setTimeout(() => reject(new Error('Xử lý chat thanh toán quá thời gian cho phép.')), this.discordOperationTimeoutMs);
              })
            ]);
          } catch (error) {
            const key = String(message?.id ?? `${message?.at || ''}:${message?.text || ''}`);
            if (message) {
              this.chatRetry.set(key, message);
              while (this.chatRetry.size > 200) {
                const oldestKey = this.chatRetry.keys().next().value;
                if (oldestKey == null) break;
                this.chatRetry.delete(oldestKey);
              }
            }
            this.metrics.inc('minecraft_chat_retry', 1, { code: error?.code || 'unknown' });
            void this.logger.warn('Chat handler retry scheduled', { id: message?.id || null, error: error?.message || String(error) });
            console.warn('[Chat Handle]', error?.message || error);
          } finally {
            if (timeoutId) clearTimeout(timeoutId);
          }
          const messageId = Number(message?.id || 0);
          if (messageId > this.chatCursor) this.chatCursor = messageId;
        }

        const nextSince = Number(data.nextSince || 0);
        if (nextSince > this.chatCursor && this.chatRetry.size === 0) this.chatCursor = nextSince;
      } catch (error) {
        this.metrics.inc('minecraft_chat_poll_error', 1);
        void this.logger.warn('Chat poll failed', { error: error?.message || String(error) });
        console.warn('[Chat Poll]', error?.message || error);
      }
      if (!this.chatPollStopped) this.chatPollTimer = setTimeout(loop, interval);
      else this.chatPollTimer = null;
    };
    this.chatPollTimer = setTimeout(loop, 250);
  }

  async shutdown() {
    this.chatPollStopped = true;
    if (this.chatPollTimer) clearTimeout(this.chatPollTimer);
    this.chatPollTimer = null;
    for (const timerName of ['refreshTimer', 'reservationTimer', 'bankRetryTimer']) {
      const timer = this[timerName];
      if (timer) clearInterval(timer);
      this[timerName] = null;
    }
    try { this.bank?.stop?.(); } catch {}
    try { this.dmQueue?.clear?.(Object.assign(new Error('PaymentService shutdown.'), { code: 'SERVICE_SHUTDOWN' })); } catch {}
    this.started = false;
    void this.logger.info('PaymentService shutdown complete');
  }

  getReservedStock(panelId, excludeOrderId = null) {
    return store.all()
      .filter(order =>
        String(order.panelId) === String(panelId) &&
        (!excludeOrderId || String(order.id) !== String(excludeOrderId)) &&
        RESERVABLE_STATUSES.has(order.status) &&
        order.stockReserved === true &&
        !order.stockDeductedAt &&
        !this.isReservationExpired(order)
      )
      .reduce((sum, order) => {
        const amount = Number(order.amount);
        return Number.isSafeInteger(amount) && amount > 0 ? sum + amount : sum;
      }, 0);
  }

  getAvailableStock(panel, excludeOrderId = null) {
    if (!panel) return 0;
    const stock = Number(panel.stock);
    if (!Number.isSafeInteger(stock) || stock < 0) return 0;
    return Math.max(0, stock - this.getReservedStock(panel.id, excludeOrderId));
  }

  async withStockLock(task) {
    this.stockLockDepth += 1;
    const run = this.stockLock.then(task, task);
    const settled = run.finally(() => {
      this.stockLockDepth = Math.max(0, this.stockLockDepth - 1);
    });
    this.stockLock = settled.catch(() => {});
    return settled;
  }

  getStockQueueStatus() {
    return {
      depth: Number(this.stockLockDepth || 0),
      waiting: Math.max(0, Number(this.stockLockDepth || 0) - 1)
    };
  }

  async decrementPanelStockUnlocked(panelId, amount, orderId = null) {
    const panel = store.getPanel(panelId);
    const value = Number(amount);
    if (!panel) throw new Error('Panel giao dịch không còn tồn tại.');
    if (!Number.isSafeInteger(value) || value <= 0) throw new Error('Số Money cần trừ stock không hợp lệ.');

    if (orderId) {
      const order = store.get(orderId);
      if (!order) throw new Error('Đơn không còn tồn tại để trừ stock.');
      if (order.stockDeductedAt) return panel;

      const baseStock = Number(panel.stock || 0);
      const intent = order.stockDeductionIntent;
      if (intent && Number.isSafeInteger(Number(intent.baseStock)) && Number.isSafeInteger(Number(intent.targetStock))) {
        if (baseStock === Number(intent.targetStock)) {
          store.update(orderId, {
            stockDeductionIntent: { ...intent, appliedAt: new Date().toISOString() },
            stockDeductedAt: new Date().toISOString()
          });
          return panel;
        }
        if (baseStock !== Number(intent.baseStock)) {
          throw new Error(`Stock đã thay đổi ngoài giao dịch ${orderId}; cần Admin review trước khi trừ tiếp.`);
        }
      }

      if (!Number.isSafeInteger(baseStock) || baseStock < value) throw new Error(`Stock hiện tại chỉ còn ${formatAmount(baseStock)} Money.`);
      const targetStock = baseStock - value;
      const createdAt = order.stockDeductionIntent?.createdAt || new Date().toISOString();
      store.update(orderId, {
        stockDeductionIntent: { baseStock, amount: value, targetStock, createdAt }
      });

      const next = store.updatePanel(panelId, { stock: targetStock });
      if (!next) throw new Error('Không thể cập nhật stock panel.');
      await this.editPanel(panelId, next);
      store.update(orderId, {
        stockDeductionIntent: { baseStock, amount: value, targetStock, createdAt, appliedAt: new Date().toISOString() },
        stockDeductedAt: new Date().toISOString()
      });
      return next;
    }

    const stock = Number(panel.stock || 0);
    if (!Number.isSafeInteger(stock) || stock < value) throw new Error(`Stock hiện tại chỉ còn ${formatAmount(stock)} Money.`);
    const next = store.updatePanel(panelId, { stock: stock - value });
    if (!next) throw new Error('Không thể cập nhật stock panel.');
    await this.editPanel(panelId, next);
    return next;
  }

  async decrementPanelStock(panelId, amount, orderId = null) {
    return this.withStockLock(() => this.decrementPanelStockUnlocked(panelId, amount, orderId));
  }

  async restorePanelStockForOrder(order, reason = 'order cancelled') {
    return this.withStockLock(async () => {
      const fresh = store.get(order?.id);
      if (!fresh) throw new Error('Đơn không còn tồn tại.');
      if (!['thu', 'ban'].includes(String(fresh.type))) return null;
      if (!fresh.stockDeductedAt || fresh.stockRestoredAt) return store.getPanel(fresh.panelId);

      const panel = store.getPanel(fresh.panelId);
      if (!panel) throw new Error('Panel giao dịch không còn tồn tại để hoàn stock.');
      const currentStock = Number(panel.stock || 0);
      const value = Number(fresh.amount || 0);
      const targetStock = currentStock + value;
      if (!Number.isSafeInteger(currentStock) || currentStock < 0) throw new Error('Stock hiện tại không hợp lệ.');
      if (!Number.isSafeInteger(value) || value <= 0 || !Number.isSafeInteger(targetStock)) throw new Error('Số Money hoàn stock không hợp lệ.');

      const updatedPanel = store.updatePanel(panel.id, { stock: targetStock, sold: false, enabled: true });
      if (!updatedPanel) throw new Error('Không thể hoàn stock panel.');
      await this.editPanel(panel.id, updatedPanel);
      store.update(fresh.id, {
        stockRestoredAt: new Date().toISOString(),
        stockRestoredAmount: value,
        stockRestoreReason: String(reason || 'order cancelled'),
        stockReserved: false
      });
      void this.logger.info('Panel stock restored', {
        orderId: fresh.id,
        panelId: panel.id,
        amount: value,
        reason: String(reason || 'order cancelled'),
        stockAfter: targetStock
      });
      return updatedPanel;
    });
  }

  async reconcileStockDeductions() {
    return this.withStockLock(async () => {
      let fixed = 0;
      for (const order of store.all()) {
        const intent = order.stockDeductionIntent;
        if (!intent || order.stockDeductedAt) continue;
        const panel = store.getPanel(order.panelId);
        if (!panel) {
          store.update(order.id, { status: 'manual_review', lastError: 'Panel mất trong khi đang reconcile stock.' });
          continue;
        }
        const stock = Number(panel.stock);
        const base = Number(intent.baseStock);
        const target = Number(intent.targetStock);
        if (![stock, base, target].every(Number.isSafeInteger)) {
          store.update(order.id, { status: 'manual_review', lastError: 'Stock hoặc intent không hợp lệ.' });
          continue;
        }
        if (stock === target) {
          store.update(order.id, { stockDeductionIntent: { ...intent, appliedAt: new Date().toISOString() }, stockDeductedAt: new Date().toISOString() });
          fixed++;
        } else if (stock === base) {
          const next = store.updatePanel(panel.id, { stock: target });
          if (!next) {
            store.update(order.id, { status: 'manual_review', lastError: 'Không thể áp dụng stock intent trong reconcile.' });
            continue;
          }
          store.update(order.id, { stockDeductionIntent: { ...intent, appliedAt: new Date().toISOString() }, stockDeductedAt: new Date().toISOString() });
          fixed++;
        } else {
          store.update(order.id, { status: 'manual_review', lastError: `Stock hiện tại ${stock} không khớp base ${base} hoặc target ${target}.` });
        }
      }
      return fixed;
    });
  }

  rememberLiveOrderReply(orderId, interaction, message = null) {
    if (!orderId) return;
    const ephemeral = Boolean(message?.flags?.has?.(MessageFlags.Ephemeral));
    const entry = {
      webhook: interaction?.webhook || null,
      channelId: ephemeral ? null : (message?.channelId || interaction?.channelId || null),
      messageId: ephemeral ? null : (message?.id || interaction?.message?.id || null)
    };
    if (entry.webhook || (entry.channelId && entry.messageId)) {
      this.liveOrderReplies.set(String(orderId), entry);
      if (entry.channelId && entry.messageId) {
        store.update(orderId, { channelId: entry.channelId, messageId: entry.messageId });
      }
    }
  }

  forgetLiveOrderReply(orderId) {
    if (orderId) this.liveOrderReplies.delete(String(orderId));
  }

  async editLiveOrderReply(orderId, payload) {
    let entry = this.liveOrderReplies.get(String(orderId));
    if (!entry) {
      const saved = store.get(orderId);
      if (saved?.channelId && saved?.messageId) {
        entry = { webhook: null, channelId: saved.channelId, messageId: saved.messageId };
        this.liveOrderReplies.set(String(orderId), entry);
      }
    }
    if (!entry) return false;

    if (entry.channelId && entry.messageId) {
      try {
        const channel = await this.client.channels.fetch(entry.channelId);
        if (channel?.isTextBased?.()) {
          const message = await channel.messages.fetch(entry.messageId);
          await message.edit(payload);
          return true;
        }
      } catch (error) {
        console.warn('[Order Message] Channel edit:', error?.message || error);
      }
    }

    if (entry.webhook) {
      try {
        await entry.webhook.editMessage('@original', payload);
        return true;
      } catch (error) {
        console.warn('[Order Message] Webhook edit:', error?.message || error);
      }
    }
    return false;
  }

  async resolvePanelFromMessage(interaction, messageId) {
    const channel = interaction?.channel;
    if (!channel?.isTextBased?.()) throw new Error('Lệnh /upstock phải được dùng trong kênh text.');

    const message = await channel.messages.fetch(messageId).catch(() => null);
    if (!message) throw new Error('Không lấy được Message ID. Bot cần quyền View Channel và Read Message History.');

    for (const row of message.components || []) {
      for (const component of row.components || []) {
        const customId = String(component.customId || '');
        for (const prefix of ['paneltrade:', 'panelsold:', 'panelerror:', 'panelcalc:']) {
          if (customId.startsWith(prefix)) {
            const panelId = customId.slice(prefix.length).trim();
            if (panelId) {
              const panel = store.getPanel(panelId);
              if (panel) return panel;
            }
          }
        }
      }
    }

    throw new Error('Message này không phải panel giao dịch của bot hoặc panel đã mất dữ liệu.');
  }

  async editPanel(panelId, providedPanel = null) {
    const panel = providedPanel || store.getPanel(panelId);
    if (!panel?.messageId || !panel.channelId) return false;
    try {
      const channel = await this.client.channels.fetch(panel.channelId);
      if (!channel?.isTextBased?.()) return false;
      const message = await channel.messages.fetch(panel.messageId);
      await message.edit({ embeds: [this.buildPanelEmbed(panel)], components: [this.buildPanelButtons(panel)] });
      return true;
    } catch (error) {
      console.warn('[Panel] Stock update:', error?.message || error);
      return false;
    }
  }

  buildPanelEmbed(panel) {
    const isThu = panel.type === 'thu';
    const isSold = panel.sold === true || panel.enabled === false;
    const sellIcon = this.icon('sell', '📤');
    const buyIcon = this.icon('cart', '🛒');
    const moneyIcon = this.icon('money', '💎');
    const bankIcon = this.icon('bank', '🏦');
    const title = isThu ? `${sellIcon} BÁN MONEY CHO BOT` : `${buyIcon} MUA MONEY TỪ BOT`;
    const available = isSold ? 0 : this.getAvailableStock(panel);
    const description = isSold
      ? '🔴 **PANEL ĐÃ SOLD**\n\nAdmin đã tạm đóng giao dịch trên panel này.'
      : isThu
        ? '💎 **Bán Money cho bot**\n\nBấm **Bán Money** → nhập IGN + số Money → xác nhận → copy lệnh `/pay` → gửi Money cho bot. Khi nhận đủ, bot sẽ xin mã QR để admin thanh toán VNĐ.'
        : '💎 **Mua Money từ bot**\n\nBấm **Mua Money** → nhập IGN + số Money → xác nhận → quét QR chuyển khoản. AutoBank xác nhận tiền → bot tự Pay Money vào IGN.';

    return new EmbedBuilder()
      .setTitle(title)
      .setColor(isSold ? 0xED4245 : (isThu ? 0x57F287 : 0x5865F2))
      .setDescription(description)
      .addFields(
        { name: `${this.icon('order', '📦')} STOCK`, value: `**${formatAmount(panel.stock)} Money**`, inline: true },
        { name: `${moneyIcon} CÓ THỂ ĐẶT`, value: `**${formatAmount(available)} Money**`, inline: true },
        { name: `${bankIcon} RT / 1M`, value: `**${Number(panel.rate).toLocaleString('vi-VN')}đ**`, inline: true },
        { name: `${this.icon('bot', '🤖')} IG BOT`, value: `**${this.getBotName()}**`, inline: true },
        { name: '🌐 KINGMC', value: `**${this.getKingMcServer()}**`, inline: true },
        { name: '🧮 TỶ GIÁ', value: `**${Number(panel.rate).toLocaleString('vi-VN')}đ / 1M**`, inline: true },
        { name: `${this.icon('info', '📌')} TRẠNG THÁI`, value: isSold ? '**SOLD / ĐÓNG**' : '**ĐANG MỞ**', inline: true },
        { name: '⚠️ LƯU Ý', value: isThu
          ? 'Chuyển **đúng số Money** tới đúng IG bot trong lệnh được cung cấp. Không tự thay đổi số tiền.'
          : 'Chuyển **đúng số VNĐ + đúng nội dung QR**. AutoBank chỉ nhận giao dịch khớp đơn.', inline: false }
      )
      .setFooter({ text: 'KINGMC.VN • Money Trading • Mã đơn riêng • AutoBank' })
      .setTimestamp();
  }

  buildPanelButtons(panel) {
    const isSold = panel.sold === true || panel.enabled === false;
    const tradeButton = new ButtonBuilder()
      .setCustomId(`paneltrade:${panel.id}`)
      .setLabel(panel.type === 'thu' ? 'Bán Money' : 'Mua Money')
      .setStyle(panel.type === 'thu' ? ButtonStyle.Primary : ButtonStyle.Success)
      .setDisabled(isSold || this.getAvailableStock(panel) <= 0);
    const tradeEmoji = this.buttonEmoji(panel.type === 'thu' ? 'sell' : 'cart', panel.type === 'thu' ? '📤' : '🛒');
    if (tradeEmoji) tradeButton.setEmoji(tradeEmoji);

    const soldButton = new ButtonBuilder()
      .setCustomId(`panelsold:${panel.id}`)
      .setLabel(isSold ? 'SOLD' : 'Đánh dấu SOLD')
      .setStyle(ButtonStyle.Secondary)
      .setDisabled(isSold);
    const soldEmoji = this.buttonEmoji('warning', '⚠️');
    if (soldEmoji) soldButton.setEmoji(soldEmoji);

    const errorButton = new ButtonBuilder()
      .setCustomId(`panelerror:${panel.id}`)
      .setLabel('Báo lỗi')
      .setStyle(ButtonStyle.Danger);
    const errorEmoji = this.buttonEmoji('bug', '🐛');
    if (errorEmoji) errorButton.setEmoji(errorEmoji);

    const calcButton = new ButtonBuilder()
      .setCustomId(`panelcalc:${panel.id}`)
      .setLabel('Tính tiền')
      .setStyle(ButtonStyle.Primary);
    const infoEmoji = this.buttonEmoji('info', '🧮');
    if (infoEmoji) calcButton.setEmoji(infoEmoji);

    const supportButton = new ButtonBuilder()
      .setLabel('Server hỗ trợ')
      .setStyle(ButtonStyle.Link)
      .setURL(this.supportButtonUrl);
    const serverEmoji = this.buttonEmoji('server', '🌐');
    if (serverEmoji) supportButton.setEmoji(serverEmoji);

    return new ActionRowBuilder().addComponents(tradeButton, soldButton, errorButton, calcButton, supportButton);
  }

  buildPanelErrorModal(panelId) {
    return new ModalBuilder()
      .setCustomId(`panelerror:${panelId}`)
      .setTitle('🐛 Báo lỗi Panel')
      .addComponents(new ActionRowBuilder().addComponents(
        new TextInputBuilder()
          .setCustomId('error_detail')
          .setLabel('Lỗi bạn gặp là gì?')
          .setPlaceholder('Ví dụ: Bấm xác nhận nhưng không chuyển bước...')
          .setStyle(TextInputStyle.Paragraph)
          .setMinLength(3)
          .setMaxLength(1000)
          .setRequired(true)
      ));
  }

  buildPanelCalcModal(panelId) {
    return new ModalBuilder()
      .setCustomId(`panelcalc:${panelId}`)
      .setTitle('🧮 Tính tiền giao dịch')
      .addComponents(new ActionRowBuilder().addComponents(
        new TextInputBuilder()
          .setCustomId('calc_value')
          .setLabel('Nhập Money hoặc VNĐ')
          .setPlaceholder('Ví dụ: 50m hoặc 2500đ')
          .setStyle(TextInputStyle.Short)
          .setMaxLength(30)
          .setRequired(true)
      ));
  }

  async sendLegitRequest(order) {
    const userId = String(order?.discordId || '').trim();
    if (!userId || !LEGIT_USER_ID) return null;
    const action = order.type === 'thu' ? 'bán' : 'mua';
    const command = `+1 legit <@${LEGIT_USER_ID}> ${action} ${formatCompactMoney(order.amount)} Money King`;
    return this.safeDM(userId,
      `# Legit cho tớ đii💗\n` +
      `## Bạn vào kênh <#1521016064484446278>\n` +
      `## legit cho tớ dạng tin nhắn:\n` +
      `Copy Trên PC:\n` +
      '```' + command + '```\n' +
      `Copt Trên Điện Thoại:\n` +
      '`' + command.replace(/^\+1\s+/, '1 ') + '`'
    );
  }

  buildListingPanel(commandName, channel, stock, rate) {
    const type = commandName === 'thumon' ? 'thu' : 'ban';
    this.validatePanelValues(stock, rate);
    return {
      id: makeId('PANEL'),
      type,
      stock: Number(stock),
      rate: Number(rate),
      channelId: channel.id,
      guildId: channel.guildId || null,
      messageId: null,
      createdAt: new Date().toISOString(),
      createdBy: null,
      enabled: true,
      sold: false,
      // Persistent forever: panel tồn tại cho đến khi Admin SOLD/đóng hoặc xóa message.
      persistent: true
    };
  }

  buildTradeUserModal(panel) {
    return new ModalBuilder()
      .setCustomId(`tradeform:${panel.id}`)
      .setTitle(panel.type === 'thu' ? '📤 Bán Money cho bot' : '🛒 Mua Money từ bot')
      .addComponents(
        new ActionRowBuilder().addComponents(
          new TextInputBuilder()
            .setCustomId('ingame')
            .setLabel('👤 IGN Minecraft')
            .setPlaceholder('Ví dụ: Ntkhanh')
            .setStyle(TextInputStyle.Short)
            .setMinLength(3)
            .setMaxLength(16)
            .setRequired(true)
        ),
        new ActionRowBuilder().addComponents(
          new TextInputBuilder()
            .setCustomId('amount')
            .setLabel('💎 Số Money muốn giao dịch')
            .setPlaceholder('Ví dụ: 10m')
            .setStyle(TextInputStyle.Short)
            .setMaxLength(24)
            .setRequired(true)
        )
      );
  }

  buildPayModal() {
    return new ModalBuilder()
      .setCustomId('modal:pay')
      .setTitle('💸 Chuyển King xu')
      .addComponents(
        new ActionRowBuilder().addComponents(
          new TextInputBuilder().setCustomId('ingame').setLabel('👤 IGN người nhận').setPlaceholder(`Ví dụ: ${this.getBotName()}`).setStyle(TextInputStyle.Short).setMinLength(3).setMaxLength(16).setRequired(true)
        ),
        new ActionRowBuilder().addComponents(
          new TextInputBuilder().setCustomId('amount').setLabel('💎 Số King xu').setPlaceholder('Ví dụ: 1m').setStyle(TextInputStyle.Short).setMaxLength(24).setRequired(true)
        )
      );
  }

  buildConfirmRow(id, includePay = false) {
    return new ActionRowBuilder().addComponents(
      new ButtonBuilder().setCustomId(`confirm:${id}`).setLabel('✅ Xác nhận TT').setStyle(ButtonStyle.Success),
      ...(includePay ? [new ButtonBuilder().setCustomId(`paynow:${id}`).setLabel('💸 Pay').setStyle(ButtonStyle.Primary)] : []),
      new ButtonBuilder().setCustomId(`cancel:${id}`).setLabel('❌ Hủy').setStyle(ButtonStyle.Danger)
    );
  }

  buildOrderEmbed(order, title = '🔎 XÁC NHẬN GIAO DỊCH') {
    const label = order.type === 'thu' ? '📤 Bán Money cho bot' : order.type === 'ban' ? '🛒 Mua Money từ bot' : '💸 Pay';
    return new EmbedBuilder()
      .setTitle(title)
      .setColor(0x5865F2)
      .addFields(
        { name: '🧾 Mã đơn', value: `**${order.id}**`, inline: true },
        { name: '🔄 Loại', value: `**${label}**`, inline: true },
        { name: '👤 IGN', value: `**${order.player}**`, inline: true },
        { name: '🌐 KINGMC', value: `**${order.server || this.getKingMcServer()}**`, inline: true },
        { name: '💎 Money', value: `**${formatAmount(order.amount)}**`, inline: true },
        ...(order.rt ? [{ name: '💰 RT / 1M', value: `**${Number(order.rt).toLocaleString('vi-VN')}đ**`, inline: true }] : []),
        ...(order.vnd ? [{ name: '💵 VNĐ', value: `**${this.formatVnd(order.vnd)}**`, inline: true }] : []),
        ...(order.stockDeductionMode ? [{ name: '📦 STOCK', value: `**${order.stockRestoredAt ? 'ĐÃ HOÀN' : order.stockDeductedAt ? 'ĐÃ TRỪ NGAY' : 'ĐANG GIỮ'}**`, inline: true }] : [])
      )
      .setFooter({ text: 'KINGMC.VN • Kiểm tra kỹ trước khi xác nhận' })
      .setTimestamp();
  }

  async handleIncomingChat(msg) {
    const text = String(msg?.text || '').trim();
    if (!text) return;
    const inspected = inspectMinecraftMessage(text, { isPlayerChat: msg?.isPlayerChat, source: msg?.source });
    if (inspected.highRisk) {
      this.metrics.inc('minecraft_chat_filtered', 1, { reason: inspected.riskHits.join(',') || 'high_risk' });
      void this.logger.warn('Filtered high-risk Minecraft message', { id: msg?.id || null, risks: inspected.riskHits, repeated: inspected.repeated, text: inspected.text.slice(0, 500) });
      return;
    }

    // Tuyệt đối không dùng chat do member tự gửi để xác nhận tiền.
    // Worker đã phân loại message; nếu không có metadata thì giữ heuristic
    // fail-closed trong chatPaymentProof.
    if (msg?.isPlayerChat === true) {
      if (process.env.DEBUG_PAYMENT === '1') {
        console.log(`[Payment Game] Bỏ chat member: ${text.slice(0, 300)}`);
      }
      return;
    }

    const at = Number(msg?.at || Date.now());

    const waitingOrders = store.all().filter(order =>
      order.type === 'thu' &&
      order.status === 'await_ingame' &&
      (!order.awaitSinceAt || at >= Number(order.awaitSinceAt) - 1000)
    );

    if (!waitingOrders.length) return;

    const analyses = waitingOrders.map(order => ({
      order,
      analysis: chatPaymentProof(text, order.player, order.botName || this.getBotName(), order.amount)
    })).filter(x => x.analysis.proof);

    if (!analyses.length) return;

    // Nếu server không nhắc tên người gửi, chỉ chấp nhận khi duy nhất một đơn
    // có cùng bot + amount. Không được hoàn tất đồng thời nhiều đơn giống tiền.
    const buyerSpecific = analyses.filter(x => x.analysis.buyerMentioned);
    let matched = null;
    if (buyerSpecific.length === 1) matched = buyerSpecific[0];
    else if (buyerSpecific.length > 1) {
      console.warn('[Payment Game] Ambiguous buyer proof; bỏ qua message:', text);
      return;
    } else if (analyses.length === 1) {
      matched = analyses[0];
    } else {
      console.warn(`[Payment Game] Ambiguous proof (${analyses.length} orders); bỏ qua message: ${text}`);
      return;
    }

    const order = matched.order;
    if (process.env.DEBUG_PAYMENT === '1') console.log(`[Payment Game] Match ${order.id}: ${text}`);

    const fresh = store.get(order.id);
    if (!fresh || fresh.status !== 'await_ingame') return;

    store.update(order.id, {
      status: 'await_qr',
      chatMessage: text.slice(0, 1500),
      gameMessageId: String(msg?.id || ''),
      gameMessageSource: String(msg?.source || 'worker'),
      gameServerMessage: true,
      gameReceivedAt: new Date().toISOString(),
      gameReceivedAmount: Number(fresh.amount),
      gameReceivedFrom: fresh.player
    });

    this.lastGamePayments.unshift({
      at: new Date().toISOString(),
      orderId: fresh.id,
      player: fresh.player,
      amount: Number(fresh.amount),
      botName: fresh.botName || this.getBotName(),
      message: text.slice(0, 900)
    });
    this.lastGamePayments = this.lastGamePayments.slice(0, 20);

    void this.audit?.gamePayment?.(
      fresh,
      fresh.amount,
      text,
      { player: fresh.player, botName: fresh.botName || this.getBotName() }
    );

    const receivedEmbed = this.buildOrderEmbed(fresh, '✅ ĐÃ NHẬN MONEY TRONG GAME')
      .setDescription(
        `✅ **Bot đã nhận đủ Money từ khách trong Minecraft.**\n\n` +
        `👤 Người chuyển: **${fresh.player}**\n` +
        `💎 Số Money nhận: **${formatAmount(fresh.amount)}**\n` +
        `💵 Giá trị thanh toán VNĐ: **${this.formatVnd(fresh.vnd)}**\n\n` +
        `📷 Bước tiếp theo: gửi **ảnh mã QR chuyển khoản** của tài khoản nhận tiền vào DM của bot.\n` +
        `🤖 Bot sẽ chuyển nguyên bản QR sang Admin để xác nhận thanh toán.`
      )
      .addFields({ name: '💬 CHAT MINECRAFT', value: `\`${text.slice(0, 900)}\``, inline: false });

    const liveEdited = await this.editLiveOrderReply(order.id, {
      content:
        `✅ **ĐÃ NHẬN ${formatAmount(fresh.amount)} MONEY TỪ ${fresh.player}**\n\n` +
        `🧾 Đơn: **${fresh.id}**\n` +
        `👤 Người chuyển: **${fresh.player}**\n` +
        `💎 Money nhận: **${formatAmount(fresh.amount)}**\n` +
        `💵 VNĐ dự kiến: **${this.formatVnd(fresh.vnd)}**\n\n` +
        `📷 **BOT ĐÃ DM KHÁCH XIN MÃ QR.**\n` +
        `⏳ Chờ khách gửi QR → bot chuyển QR cho Admin xác nhận.`,
      embeds: [receivedEmbed],
      components: []
    });

    const dmSent = await this.safeDM(
      fresh.discordId,
      `✅ **ĐÃ NHẬN ĐỦ MONEY TRONG GAME**\n\n` +
      `🧾 Mã đơn: **${fresh.id}**\n` +
      `👤 Người chuyển: **${fresh.player}**\n` +
      `💎 Money đã nhận: **${formatAmount(fresh.amount)}**\n` +
      `💰 RT / 1M: **${Number(fresh.rt).toLocaleString('vi-VN')}đ**\n` +
      `💵 Giá trị thanh toán: **${this.formatVnd(fresh.vnd)}**\n` +
      `💬 Chat xác nhận: \`${text.slice(0, 1000)}\`\n\n` +
      `📷 **GỬI ẢNH MÃ QR CHUYỂN KHOẢN** của tài khoản nhận tiền trực tiếp vào DM này.\n` +
      `🤖 Bot sẽ nhận QR và chuyển **nguyên bản** sang Admin để xác nhận thanh toán.\n` +
      (!liveEdited ? `\n⚠️ Tin nhắn đơn cũ không thể chỉnh sửa nữa; trạng thái này đã được gửi qua DM.` : '')
    );

    await this.notifyAdmins(
      `📥 **ĐÃ NHẬN MONEY GAME**\n` +
      `🧾 Đơn: **${fresh.id}**\n` +
      `👤 Người chuyển: **${fresh.player}**\n` +
      `💎 Money nhận: **${formatAmount(fresh.amount)}**\n` +
      `💵 VNĐ dự kiến: **${this.formatVnd(fresh.vnd)}**\n` +
      `💬 Chat: \`${text.slice(0, 900)}\`\n` +
      `📷 Đang chờ khách gửi QR.\n` +
      `📨 DM khách: **${dmSent ? 'Đã gửi' : 'Không gửi được'}**`
    );
  }

  async fetchAttachment(url, timeoutMs = 30000) {
    const parsed = new URL(String(url || ''));
    const allowedHosts = new Set(['cdn.discordapp.com', 'media.discordapp.net', 'images-ext-1.discordapp.net']);
    if (!allowedHosts.has(parsed.hostname.toLowerCase())) throw new Error('Attachment QR không nằm trên Discord CDN hợp lệ.');
    const controller = new AbortController();
    const timer = setTimeout(() => controller.abort(), timeoutMs);
    try {
      const response = await fetch(parsed.toString(), { signal: controller.signal, redirect: 'error' });
      if (!response.ok) throw new Error(`QR HTTP ${response.status}`);
      const type = String(response.headers.get('content-type') || '').toLowerCase();
      if (!type.startsWith('image/')) throw new Error(`File QR không phải image (${type || 'unknown'}).`);
      const contentLength = Number(response.headers.get('content-length') || 0);
      if (contentLength > 8 * 1024 * 1024) throw new Error('Ảnh QR quá lớn.');
      const buffer = Buffer.from(await response.arrayBuffer());
      if (!buffer.length || buffer.length > 8 * 1024 * 1024) throw new Error('Ảnh QR không hợp lệ hoặc quá lớn.');
      const extension = type.includes('png') ? 'png' : type.includes('webp') ? 'webp' : type.includes('gif') ? 'gif' : 'jpg';
      return { buffer, extension };
    } finally { clearTimeout(timer); }
  }

  async handleDiscordMessage(message) {
    if (!message || message.author?.bot || message.webhookId || message.guildId) return;
    const userId = String(message.author?.id || 'unknown');
    const gate = this.interactionLimiter.consume(`dm:${userId}`, 1);
    if (!gate.allowed) { this.metrics.inc('dm_filtered', 1, { reason: 'rate_limit' }); return; }
    if (String(message.content || '').length > 1200) { this.metrics.inc('dm_filtered', 1, { reason: 'oversized_text' }); return; }

    const order = store.all()
      .filter(o => o.type === 'thu' && o.status === 'await_qr' && String(o.discordId) === String(message.author?.id))
      .sort((a, b) => new Date(b.createdAt) - new Date(a.createdAt))[0];
    if (!order) return;

    const attachments = [...(message.attachments?.values?.() || [])];
    if (attachments.length > 3) { this.metrics.inc('dm_filtered', 1, { reason: 'too_many_attachments' }); await this.safeDM(message.author.id, `⚠️ Đơn **${order.id}** chỉ nhận tối đa 3 file/lần và cần ít nhất một ảnh QR.`); return; }
    const image = attachments.find(a => {
      const type = String(a.contentType || '').toLowerCase();
      const name = String(a.name || '').toLowerCase();
      const url = String(a.url || '').toLowerCase();
      return type.startsWith('image/') || /\.(png|jpe?g|webp|gif|bmp)(?:\?|$)/i.test(name) || /\.(png|jpe?g|webp|gif|bmp)(?:\?|$)/i.test(url);
    });

    if (!image) {
      await this.safeDM(message.author.id, `📷 Đơn **${order.id}** đang chờ ảnh QR. Hãy gửi **ảnh mã QR chuyển khoản** trực tiếp vào DM này.`);
      return;
    }

    const current = store.get(order.id);
    if (!current || current.status !== 'await_qr') return;

    let file = null;
    try {
      file = await this.fetchAttachment(image.url);
    } catch (error) {
      console.warn('[QR Download]', error?.message || error);
    }

    store.update(order.id, {
      status: 'admin_review',
      qrUrl: String(image.url),
      qrFileName: image.name || `qr-${order.id}.jpg`,
      qrMessageId: message.id,
      qrUploadedAt: new Date().toISOString()
    });
    void this.logger.info('THU Money QR received', {
      orderId: order.id,
      userId: String(order.discordId),
      player: order.player,
      amount: Number(order.amount),
      vnd: Number(order.vnd),
      qrMessageId: String(message.id),
      attachmentName: String(image.name || ''),
      attachmentType: String(image.contentType || ''),
      attachmentSize: Number(image.size || 0)
    });

    await this.safeDM(
      order.discordId,
      `✅ **BOT ĐÃ NHẬN ẢNH QR**\n\n` +
      `🧾 Mã đơn: **${order.id}**\n` +
      `👤 IGN: **${order.player}**\n` +
      `💎 Money: **${formatAmount(order.amount)}**\n` +
      `💰 RT / 1M: **${Number(order.rt).toLocaleString('vi-VN')}đ**\n` +
      `💵 VNĐ cần thanh toán: **${this.formatVnd(order.vnd)}**\n` +
      `✅ QR đã được chuyển nguyên bản cho **Admin** để kiểm tra.\n` +
      `⏳ Vui lòng chờ Admin xác nhận thanh toán.`
    );

    const embed = new EmbedBuilder()
      .setTitle('💳 BÁN MONEY • ADMIN XÁC NHẬN CHUYỂN KHOẢN')
      .setColor(0xFEE75C)
      .setDescription(
        '🔎 **Kiểm tra toàn bộ thông tin trước khi chuyển khoản cho khách.**\n\n' +
        '✅ Chỉ bấm **Xác nhận đã chuyển khoản** sau khi giao dịch ngân hàng thực sự thành công.'
      )
      .addFields(
        { name: '🧾 MÃ ĐƠN', value: `**${order.id}**`, inline: true },
        { name: '👤 KHÁCH / IGN', value: `**${order.player}**`, inline: true },
        { name: '🤖 IG BOT', value: `**${order.botName || this.getBotName()}**`, inline: true },
        { name: '💎 MONEY GAME', value: `**${formatAmount(order.amount)}**`, inline: true },
        { name: '💰 RT / 1M', value: `**${Number(order.rt).toLocaleString('vi-VN')}đ**`, inline: true },
        { name: '💵 PHẢI CHUYỂN', value: `**${this.formatVnd(order.vnd)}**`, inline: true },
        { name: '👤 DISCORD', value: `<@${order.discordId}>`, inline: true },
        { name: '📝 GAME PROOF', value: `\`${String(order.chatMessage || 'N/A').slice(0, 800)}\``, inline: false },
        { name: '📷 QR', value: 'Ảnh QR đã được gửi kèm bên dưới.', inline: false }
      )
      .setFooter({ text: 'KINGMC • Admin Payment Review' })
      .setTimestamp();

    const components = [new ActionRowBuilder().addComponents(
      new ButtonBuilder().setCustomId(`adminpaid:${order.id}`).setLabel('✅ Xác nhận đã chuyển khoản').setStyle(ButtonStyle.Success),
      new ButtonBuilder().setCustomId(`adminreject:${order.id}`).setLabel('❌ Từ chối / cần gửi lại QR').setStyle(ButtonStyle.Danger)
    )];

    for (const adminId of this.adminIds) {
      try {
        const admin = await this.client.users.fetch(adminId);
        if (file) {
          const attachment = new AttachmentBuilder(file.buffer, { name: `qr-${order.id}.${file.extension}` });
          await admin.send({ embeds: [embed.setImage(`attachment://qr-${order.id}.${file.extension}`)], files: [attachment], components });
        } else {
          await admin.send({ embeds: [embed.setImage(String(image.url))], components });
        }
      } catch (error) {
        console.warn('[Admin DM QR]', error?.message || error);
      }
    }
  }

  getBankSender(tx) {
    const pick = values => values.map(v => String(v ?? '').trim()).find(Boolean) || '';
    const name = pick([
      tx?.senderName,
      tx?.fromName,
      tx?.payerName,
      tx?.accountName,
      tx?.sender,
      tx?.from,
      tx?.customerName,
      tx?.raw?.senderName,
      tx?.raw?.fromName,
      tx?.raw?.payerName,
      tx?.raw?.accountName
    ]);
    const account = pick([
      tx?.senderAccount,
      tx?.senderAccountNumber,
      tx?.fromAccount,
      tx?.fromAccountNumber,
      tx?.payerAccount,
      tx?.raw?.senderAccount,
      tx?.raw?.senderAccountNumber,
      tx?.raw?.fromAccount
    ]);
    if (name && account) return `${name} • ${account}`;
    return name || account || 'API không trả về thông tin người chuyển';
  }

  bankAmount(value) {
    if (typeof value === 'number') return Number.isFinite(value) ? value : 0;
    const raw = String(value ?? '').trim().replace(/\s+/g, '');
    if (!raw) return 0;
    if (/^\d{1,3}(\.\d{3})+(,\d+)?$/.test(raw)) return Number(raw.replace(/\./g, '').replace(',', '.'));
    if (/^\d{1,3}(,\d{3})+(\.\d+)?$/.test(raw)) return Number(raw.replace(/,/g, ''));
    return Number(raw.replace(/,/g, '')) || 0;
  }

  bankTextMatches(haystack, needle) {
    const clean = value => String(value || '')
      .normalize('NFD')
      .replace(/[\u0300-\u036f]/g, '')
      .toUpperCase()
      .replace(/[^A-Z0-9]/g, '');

    const a = clean(haystack);
    const b = clean(needle);
    // Nội dung order luôn là một mã giao dịch duy nhất. Chỉ cho phép exact containment
    // của mã đầy đủ; tuyệt đối không dùng chiều ngược lại (needle.includes(haystack)),
    // vì một mô tả ngân hàng quá ngắn có thể vô tình khớp đơn khác.
    if (!a || !b || b.length < 8) return false;
    return a.includes(b);
  }

  bankTransactionText(tx) {
    const values = [
      tx?.description, tx?.content, tx?.transactionContent, tx?.transferContent,
      tx?.remark, tx?.memo, tx?.addInfo, tx?.narrative, tx?.reference,
      tx?.raw?.description, tx?.raw?.content, tx?.raw?.transactionContent,
      tx?.raw?.transferContent, tx?.raw?.remark, tx?.raw?.memo,
      tx?.raw?.addInfo, tx?.raw?.narrative, tx?.raw?.reference
    ];
    return [...new Set(values.map(v => String(v ?? '').trim()).filter(Boolean))].join(' ');
  }

  bankReceivedEmbed(order, tx, stage = '💰 ĐÃ NHẬN TIỀN NGÂN HÀNG') {
    const amount = this.bankAmount(
      tx?.amount ?? tx?.transferAmount ?? tx?.creditAmount ?? tx?.receivedAmount ?? tx?.amountIn ?? tx?.transactionAmount
    );
    const bankText = this.bankTransactionText(tx) || 'Không có nội dung';
    const sender = this.getBankSender(tx);
    return this.buildOrderEmbed(order, stage)
      .setDescription(
        `✅ **AutoBank đã xác nhận giao dịch tiền vào.**\n\n` +
        `👤 Người chuyển: **${sender}**\n` +
        `💵 Số tiền nhận: **${this.formatVnd(amount)}**\n` +
        `📝 Nội dung: **${bankText.slice(0, 600)}**\n` +
        `🏦 Mã giao dịch: **${String(tx?.id || tx?.transactionID || 'N/A')}**`
      )
      .addFields(
        { name: '💎 MONEY KHÁCH NHẬN', value: `**${formatAmount(order.amount)}**`, inline: true },
        { name: '👤 IGN NHẬN MONEY', value: `**${order.player}**`, inline: true },
        { name: '💰 RT / 1M', value: `**${Number(order.rt).toLocaleString('vi-VN')}đ**`, inline: true },
        { name: '💵 VNĐ THEO ĐƠN', value: `**${this.formatVnd(order.vnd)}**`, inline: true }
      );
  }

  isRetryablePayError(error) {
    if (error?.payOutcomeUnknown) return false;
    if (error?.retryable) return true;
    const text = String(error?.message || error || '').toLowerCase();
    return text.includes('chưa sẵn sàng') || text.includes('chua san sang') ||
      text.includes('đang bận') || text.includes('dang ban') ||
      text.includes('offline') || text.includes('not ready') ||
      text.includes('timeout') || text.includes('timed out') ||
      text.includes('fetch failed') || text.includes('worker timeout') ||
      text.includes('econnreset') || text.includes('socket') || text.includes('http 5');
  }

  async completeBankPay(order, tx) {
    const fresh = store.get(order.id);
    if (!fresh) throw new Error('Đơn không còn tồn tại.');

    const amount = this.bankAmount(tx?.amount ?? fresh.bankReceivedAmount ?? fresh.vnd);
    const txId = String(tx?.id || tx?.transactionID || tx?.transactionId || fresh.bankTransactionId || '').trim();
    const bankText = this.bankTransactionText(tx) || String(fresh.bankReceivedDescription || fresh.content || '');
    const sender = this.getBankSender(tx) || fresh.bankSender || 'API không trả về thông tin người chuyển';

    const queueBefore = typeof this.localMcBot?.getPayQueueStatus === 'function'
      ? this.localMcBot.getPayQueueStatus()
      : null;
    if (queueBefore && (queueBefore.length > 0 || queueBefore.running)) {
      void this.notifyAdmins(
        `⏳ **MUA MONEY • PAY VÀO HÀNG ĐỢI**\n` +
        `🧾 Đơn: ${fresh.id}\n` +
        `👤 IGN: ${fresh.player}\n` +
        `💎 Money: ${formatAmount(fresh.amount)}\n` +
        `📌 Số đơn đang chờ trước đó: ${queueBefore.length}`
      );
    }

    let result;
    try {
      result = await this.pay(fresh.player, fresh.amount, 12000, fresh.id);
      if (result?.success === false || result?.result?.success === false) {
        throw new Error(result?.error || result?.result?.message || 'Minecraft từ chối lệnh Pay.');
      }
    } catch (error) {
      if (this.isRetryablePayError(error)) {
        store.update(fresh.id, {
          status: 'await_game_pay',
          lastError: String(error?.message || error),
          bankRetryAt: new Date().toISOString()
        });
        await this.editLiveOrderReply(fresh.id, {
          content:
            `💰 **ĐÃ NHẬN TIỀN • CHỜ MINECRAFT SẴN SÀNG**\n\n` +
            `🧾 Đơn: **${fresh.id}**\n` +
            `👤 Người chuyển: **${sender}**\n` +
            `💵 Đã nhận: **${this.formatVnd(amount)}**\n` +
            `📝 Nội dung: **${bankText.slice(0, 1000)}**\n` +
            `🏦 Mã TX: **${txId}**\n` +
            `💎 Sẽ Pay: **${formatAmount(fresh.amount)} → ${fresh.player}**\n\n` +
            `⏳ Bot sẽ tự thử lại khi Minecraft sẵn sàng.`,
          embeds: [this.bankReceivedEmbed({ ...fresh, status: 'await_game_pay' }, tx, '💰 ĐÃ NHẬN TIỀN • CHỜ PAY GAME')],
          components: []
        });
        await this.safeDM(fresh.discordId,
          `💰 **AUTOBANK ĐÃ NHẬN TIỀN**\n\n` +
          `🧾 Mã đơn: **${fresh.id}**\n` +
          `💵 Đã nhận: **${this.formatVnd(amount)}**\n` +
          `📝 Nội dung: **${bankText}**\n` +
          `🏦 TX: **${txId}**\n` +
          `💎 Chờ Pay: **${formatAmount(fresh.amount)} → ${fresh.player}**\n\n` +
          `⏳ Minecraft đang bận/offline. Bot sẽ tự Pay lại.`
        );
        await this.notifyAdmins(`⏳ **MUA MONEY • ĐÃ NHẬN TIỀN, CHỜ PAY**\n${fresh.id}\n${this.formatVnd(amount)}\n${bankText}\nTX: ${txId}\nLỗi tạm thời: ${String(error?.message || error)}`);
        if (txId) this.bank.ackTransaction(txId);
        return { status: 'await_game_pay', result: null };
      }

      store.update(fresh.id, {
        status: 'manual_review',
        lastError: String(error?.message || error),
        failedAt: new Date().toISOString()
      });
      await this.editLiveOrderReply(fresh.id, {
        content:
          `⚠️ **ĐÃ NHẬN TIỀN NHƯNG PAY GAME THẤT BẠI**\n\n` +
          `🧾 Đơn: **${fresh.id}**\n` +
          `👤 Người chuyển: **${sender}**\n` +
          `💵 Đã nhận: **${this.formatVnd(amount)}**\n` +
          `📝 Nội dung: **${bankText.slice(0, 1000)}**\n` +
          `🏦 Mã TX: **${txId}**\n` +
          `❌ Lỗi: **${String(error?.message || error).slice(0, 900)}**\n\n` +
          `🛠️ Admin cần xử lý đơn này.`,
        embeds: [this.bankReceivedEmbed({ ...fresh, status: 'manual_review' }, tx, '⚠️ ĐÃ NHẬN TIỀN • PAY THẤT BẠI')],
        components: []
      });
      await this.safeDM(fresh.discordId,
        `⚠️ **ĐÃ NHẬN ĐỦ TIỀN NHƯNG CHƯA PAY ĐƯỢC MONEY**\n\n` +
        `🧾 Đơn: **${fresh.id}**\n` +
        `💵 Đã nhận: **${this.formatVnd(amount)}**\n` +
        `📝 Nội dung: **${bankText}**\n` +
        `🏦 TX: **${txId}**\n` +
        `💎 Money cần chuyển: **${formatAmount(fresh.amount)} → ${fresh.player}**\n` +
        `❌ Lỗi: **${String(error?.message || error).slice(0, 900)}**\n\n` +
        `🛠️ Admin đã được thông báo.`
      );
      await this.notifyAdmins(`⚠️ **MUA MONEY • PAY GAME THẤT BẠI**\n${fresh.id}\n${this.formatVnd(amount)}\n${bankText}\nTX: ${txId}\n❌ ${String(error?.message || error)}`);
      this.bank.ackTransaction(txId);
      return { status: 'manual_review', result: null };
    }

    try {
      await this.decrementPanelStock(fresh.panelId, fresh.amount, fresh.id);
    } catch (error) {
      store.update(fresh.id, {
        status: 'manual_review',
        lastError: `Pay thành công nhưng trừ stock lỗi: ${String(error?.message || error)}`,
        mcResult: result,
        stockReviewAt: new Date().toISOString()
      });
      await this.editLiveOrderReply(fresh.id, {
        content:
          `⚠️ **PAY GAME ĐÃ THÀNH CÔNG • STOCK CẦN KIỂM TRA**\n\n` +
          `🧾 Đơn: **${fresh.id}**\n` +
          `💵 Đã nhận: **${this.formatVnd(amount)}**\n` +
          `📝 Nội dung: **${bankText}**\n` +
          `🏦 TX: **${txId}**\n` +
          `💎 Đã Pay: **${formatAmount(fresh.amount)} → ${fresh.player}**\n` +
          `❌ ${String(error?.message || error).slice(0, 900)}`,
        embeds: [this.bankReceivedEmbed({ ...fresh, status: 'manual_review' }, tx, '⚠️ PAY THÀNH CÔNG • STOCK REVIEW')],
        components: []
      });
      await this.notifyAdmins(`⚠️ **MUA MONEY • STOCK REVIEW**\n${fresh.id}\nTX: ${txId}\n✅ Pay ${formatAmount(fresh.amount)} → ${fresh.player}\n❌ ${String(error?.message || error)}`);
      this.bank.ackTransaction(txId);
      return { status: 'manual_review', result };
    }

    store.update(fresh.id, {
      status: 'completed',
      stockReserved: false,
      stockDeductedAt: new Date().toISOString(),
      mcResult: result,
      completedAt: new Date().toISOString()
    });

    const resultMessage = result?.result?.message || result?.message || 'Minecraft đã xác nhận lệnh Pay.';
    await this.editLiveOrderReply(fresh.id, {
      content:
        `✅ **ĐƠN MUA MONEY HOÀN TẤT**\n\n` +
        `🧾 Mã đơn: **${fresh.id}**\n` +
        `👤 Người chuyển ngân hàng: **${sender}**\n` +
        `💵 Số tiền nhận: **${this.formatVnd(amount)}**\n` +
        `📝 Nội dung ngân hàng: **${bankText}**\n` +
        `🏦 Mã TX: **${txId}**\n` +
        `💎 Money đã Pay: **${formatAmount(fresh.amount)}**\n` +
        `👤 IGN nhận Money: **${fresh.player}**\n\n` +
        `🎮 Kết quả Minecraft: **${String(resultMessage).slice(0, 900)}**`,
      embeds: [this.bankReceivedEmbed({ ...fresh, status: 'completed' }, tx, '✅ MUA MONEY • ĐÃ NHẬN TIỀN & ĐÃ PAY')],
      components: []
    });
    await this.safeDM(fresh.discordId,
      `✅ **ĐƠN MUA MONEY ĐÃ HOÀN TẤT**\n\n` +
      `🧾 Mã đơn: **${fresh.id}**\n` +
      `👤 Người chuyển ngân hàng: **${sender}**\n` +
      `💵 Số tiền bot đã nhận: **${this.formatVnd(amount)}**\n` +
      `📝 Nội dung ngân hàng: **${bankText}**\n` +
      `🏦 Mã giao dịch: **${txId}**\n` +
      `💎 Money bot đã Pay: **${formatAmount(fresh.amount)}**\n` +
      `👤 IGN nhận Money: **${fresh.player}**\n` +
      `🎮 Kết quả Minecraft: **${String(resultMessage).slice(0, 900)}**\n\n` +
      `✅ Giao dịch đã hoàn tất.`
    );
    await this.sendLegitRequest(fresh);
    await this.notifyAdmins(
      `✅ **MUA MONEY HOÀN TẤT**\n` +
      `🧾 Đơn: ${fresh.id}\n` +
      `👤 Người chuyển: ${sender}\n` +
      `💵 Đã nhận: ${this.formatVnd(amount)}\n` +
      `📝 Nội dung: ${bankText}\n` +
      `🏦 TX: ${txId}\n` +
      `💎 Đã Pay: ${formatAmount(fresh.amount)} Money → ${fresh.player}\n` +
      `🎮 ${String(resultMessage).slice(0, 700)}`
    );
    this.bank.ackTransaction(txId);
    return { status: 'completed', result };
  }

  async handleBankTransaction(tx) {
    const txId = String(tx?.id || tx?.transactionID || tx?.transactionId || '').trim();
    const amount = this.bankAmount(tx?.amount ?? tx?.transferAmount ?? tx?.creditAmount ?? tx?.receivedAmount ?? tx?.amountIn ?? tx?.transactionAmount);
    const bankText = this.bankTransactionText(tx);
    if (!txId || !Number.isSafeInteger(amount) || amount <= 0 || !bankText) return false;

    if (process.env.DEBUG_PAYMENT === '1') {
      console.log(`[AutoBank→Payment] TX=${txId} amount=${amount} text=${bankText.slice(0, 500)}`);
    }

    // Ghi toàn bộ biến động tiền vào audit channel trước khi ghép đơn;
    // giao dịch chưa khớp vẫn được giữ nguyên trong AutoBank để scan lại.
    this.lastBankTransactions.unshift({
      at: new Date().toISOString(),
      txId,
      amount,
      sender: this.getBankSender(tx),
      description: bankText.slice(0, 900)
    });
    this.lastBankTransactions = this.lastBankTransactions.slice(0, 20);
    void this.audit?.bankTransaction?.(tx);

    for (const order of store.all()) {
      if (order.type !== 'ban' || order.status !== 'await_bank') continue;
      if (order.bankTransactionId || this.processing.has(order.id)) continue;
      if (Number(order.vnd) !== amount) continue;
      if (!this.bankTextMatches(bankText, order.content)) continue;

      const panel = store.getPanel(order.panelId);
      if (!panel) {
        store.update(order.id, { status: 'manual_review', bankTransactionId: txId, lastError: 'Panel không còn tồn tại.' });
        await this.notifyAdmins(`⚠️ **MUA MONEY REVIEW**\n${order.id}\nTX: ${txId}\nKhông tìm thấy panel.`);
        this.bank.ackTransaction(txId);
        return true;
      }

      this.processing.add(order.id);
      try {
        void this.logger.info('BAN Money bank match accepted', {
          orderId: order.id,
          txId,
          receivedAmount: amount,
          expectedAmount: Number(order.vnd),
          content: order.content,
          bankText: bankText.slice(0, 900),
          sender: this.getBankSender(tx),
          userId: String(order.discordId),
          player: order.player
        });
        const fresh = store.get(order.id);
        if (!fresh || fresh.status !== 'await_bank') continue;

        store.update(order.id, {
          status: 'processing_bank',
          bankTransactionId: txId,
          bankReceivedAt: new Date().toISOString(),
          bankReceivedAmount: amount,
          bankReceivedDescription: bankText.slice(0, 1500),
          bankSender: this.getBankSender(tx)
        });

        await this.editLiveOrderReply(order.id, {
          content:
            `✅ **BOT ĐÃ NHẬN TIỀN**\n\n` +
            `🧾 Đơn: **${order.id}**\n` +
            `👤 Người chuyển: **${this.getBankSender(tx)}**\n` +
            `💵 Số tiền nhận: **${this.formatVnd(amount)}**\n` +
            `📝 Nội dung: **${bankText}**\n` +
            `🏦 Mã TX: **${txId}**\n\n` +
            `⏳ **Bot đang Pay ${formatAmount(order.amount)} Money cho ${order.player}...**`,
          embeds: [this.bankReceivedEmbed(order, tx, '✅ ĐÃ NHẬN TIỀN • ĐANG PAY MONEY')],
          components: []
        });
        await this.safeDM(order.discordId,
          `✅ **AUTOBANK ĐÃ NHẬN TIỀN**\n\n` +
          `🧾 Mã đơn: **${order.id}**\n` +
          `👤 Người chuyển: **${this.getBankSender(tx)}**\n` +
          `💵 Số tiền thực nhận: **${this.formatVnd(amount)}**\n` +
          `📝 Nội dung nhận được: **${bankText}**\n` +
          `🏦 Mã giao dịch: **${txId}**\n` +
          `💎 Money sẽ chuyển: **${formatAmount(order.amount)}**\n` +
          `👤 IGN nhận Money: **${order.player}**\n\n` +
          `⏳ Bot đang thực hiện Auto Pay.`
        );

        await this.completeBankPay(order, { ...tx, id: txId, amount });
        return true;
      } finally {
        this.processing.delete(order.id);
      }
    }

    return false;
  }

  async retryPendingBankPays() {
    if (this.bankRetryRunning) return;
    this.bankRetryRunning = true;
    try {
      const orders = store.all().filter(o => o.type === 'ban' && ['await_game_pay', 'processing_bank'].includes(o.status) && o.bankTransactionId);
      for (const order of orders) {
        if (this.processing.has(order.id)) continue;
        this.processing.add(order.id);
        try {
          await this.completeBankPay(order, {
            id: order.bankTransactionId,
            transactionID: order.bankTransactionId,
            amount: Number(order.bankReceivedAmount || order.vnd),
            description: order.bankReceivedDescription || order.content || '',
            senderName: order.bankSender || null
          });
        } catch (error) {
          store.update(order.id, { lastError: String(error?.message || error) });
          if (process.env.DEBUG_PAYMENT === '1') console.warn(`[Bank Pay Retry] ${order.id}:`, error?.message || error);
        } finally {
          this.processing.delete(order.id);
        }
      }
    } finally {
      this.bankRetryRunning = false;
    }
  }

  async safeDM(userId, content, extra = {}) {
    const targetId = String(userId || '').trim();
    if (!/^\d{15,22}$/.test(targetId)) return null;
    const payloadText = String(content || '').slice(0, 1900);
    return this.dmQueue.enqueue(async () => {
      const timeoutMs = Math.max(3000, Number(process.env.DISCORD_OPERATION_TIMEOUT_MS) || 10000);
      const work = (async () => {
        const user = await this.client.users.fetch(targetId);
        if (!user) return null;
        return user.send({ content: payloadText, ...extra });
      })();
      let timerId = null;
      try { return await Promise.race([work, new Promise(resolve => { timerId = setTimeout(() => resolve(null), timeoutMs); })]); }
      finally { if (timerId) clearTimeout(timerId); }
    }, { priority: 5, meta: { userId: targetId } }).catch(error => { console.warn('[Payment DM]', error?.message || error); void this.logger.warn('Discord DM failed', { userId: targetId, error: error?.message || String(error) }); return null; });
  }


  async notifyAdmins(content) {
    void this.audit?.event(
      '🔔 AUDIT • ADMIN NOTICE',
      String(content).slice(0, 3600),
      [],
      { color: 0xFEE75C }
    );

    await Promise.allSettled([...this.adminIds].map(id => this.safeDM(id, content)));
  }

  async createTicketForOrder(interaction, order) {
    this.assertOwner(order, interaction);
    if (this.ticketProcessing.has(String(order?.id || ''))) {
      return interaction.reply({ ephemeral: true, content: '⏳ Ticket này đang được tạo. Vui lòng không bấm lại.' });
    }
    await interaction.deferReply({ ephemeral: true });
    if (order.ticketChannelId) {
      return interaction.editReply({ content: `🎫 Ticket đã tồn tại: <#${order.ticketChannelId}>` });
    }
    const lockKey = String(order.id);
    this.ticketProcessing.add(lockKey);
    let channel = null;
    try {

    const guildId = order.guildId || String(process.env.TICKET_GUILD_ID || '').trim();
    if (!guildId) throw new Error('Không xác định được server để tạo ticket.');
    const guild = await this.client.guilds.fetch(guildId);
    if (!guild) throw new Error('Bot không tìm thấy server ticket.');

    const overwrites = [
      { id: guild.roles.everyone.id, deny: [PermissionFlagsBits.ViewChannel] },
      {
        id: order.discordId,
        allow: [PermissionFlagsBits.ViewChannel, PermissionFlagsBits.SendMessages, PermissionFlagsBits.ReadMessageHistory, PermissionFlagsBits.AttachFiles]
      }
    ];
    for (const adminId of this.adminIds) {
      overwrites.push({
        id: adminId,
        allow: [PermissionFlagsBits.ViewChannel, PermissionFlagsBits.SendMessages, PermissionFlagsBits.ReadMessageHistory, PermissionFlagsBits.AttachFiles, PermissionFlagsBits.ManageChannels]
      });
    }

    const categoryId = String(process.env.TICKET_CATEGORY_ID || '').trim();
    channel = await guild.channels.create({
      name: `ticket-${String(order.id).toLowerCase().replace(/[^a-z0-9-]/g, '')}`.slice(0, 90),
      type: ChannelType.GuildText,
      ...(categoryId ? { parent: categoryId } : {}),
      permissionOverwrites: overwrites,
      reason: `Payment ticket ${order.id}`
    });

    await channel.send({
      content: `<@${order.discordId}> ${[...this.adminIds].map(id => `<@${id}>`).join(' ')}`.trim(),
      embeds: [new EmbedBuilder()
        .setTitle('🎫 PAYMENT TICKET')
        .setColor(0x5865F2)
        .setDescription('Kiểm tra trạng thái nhận tiền của đơn này.')
        .addFields(
          { name: '🧾 ORDER', value: `**${order.id}**`, inline: true },
          { name: '👤 IG', value: `**${order.player}**`, inline: true },
          { name: '💎 MONEY', value: `**${formatAmount(order.amount)}**`, inline: true },
          { name: '💵 VNĐ', value: `**${this.formatVnd(order.vnd)}**`, inline: true },
          { name: '📝 GAME PROOF', value: `\`${String(order.chatMessage || 'N/A').slice(0, 700)}\``, inline: false }
        )
        .setTimestamp()]
    });

    const updated = store.update(order.id, { ticketChannelId: channel.id, ticketCreatedAt: new Date().toISOString(), status: 'ticket_open' });
    if (!updated) throw new Error('Không thể lưu ticket vào state; ticket chưa được xác nhận hoàn tất.');
    const link = `https://discord.com/channels/${guild.id}/${channel.id}`;
    await this.notifyAdmins(`🎫 Ticket ${order.id}: ${link}`);
    return interaction.editReply({ content: `🎫 Đã tạo ticket: ${link}` });
    } catch (error) {
      if (channel && !store.get(order.id)?.ticketChannelId) {
        await channel.delete('Rollback ticket do bước tạo ticket thất bại').catch(() => {});
      }
      throw error;
    } finally {
      this.ticketProcessing.delete(lockKey);
    }
  }

  async finalizePay(order) {
    const id = String(order?.id || '');
    if (!id) throw new Error('Đơn Pay thiếu ID.');
    if (this.processing.has(id)) throw new Error('Đơn đang được xử lý.');
    const fresh = store.get(id);
    if (!fresh || fresh.type !== 'pay' || fresh.status !== 'pay_confirmed') throw new Error('Đơn Pay chưa được xác nhận.');

    this.processing.add(id);
    try {
      const marked = store.update(id, { status: 'processing_pay', processingAt: new Date().toISOString() });
      if (!marked) throw new Error('Không thể khóa trạng thái xử lý của đơn Pay.');
      const queueBefore = typeof this.localMcBot?.getPayQueueStatus === 'function'
        ? this.localMcBot.getPayQueueStatus()
        : null;
      if (queueBefore && (queueBefore.length > 0 || queueBefore.running)) {
        void this.notifyAdmins(
          `⏳ **PAY QUEUE**\n` +
          `Đơn: ${fresh.id}\n` +
          `👤 ${fresh.player}\n` +
          `💎 ${formatAmount(fresh.amount)}\n` +
          `📌 Queue trước khi thêm: ${queueBefore.length} đơn`
        );
      }

      const result = await this.pay(fresh.player, fresh.amount, 12000, fresh.id);
      void this.logger.info('Direct Pay succeeded', {
        orderId: id,
        userId: String(fresh.discordId),
        player: fresh.player,
        amount: Number(fresh.amount),
        command: `/pay ${fresh.player} ${Number(fresh.amount)}`,
        server: fresh.server || this.getKingMcServer(),
        requestId: fresh.id
      });
      const completed = store.update(id, { status: 'completed', mcResult: result, completedAt: new Date().toISOString() });
      if (!completed) {
        const error = new Error('Pay đã có phản hồi nhưng không thể lưu trạng thái hoàn tất. Kết quả cần kiểm tra từ Pay journal.');
        error.payOutcomeUnknown = true;
        throw error;
      }
      return result;
    } catch (error) {
      const status = error?.payOutcomeUnknown ? 'manual_review' : 'pay_failed';
      const extra = error?.payOutcomeUnknown
        ? { manualReviewAt: new Date().toISOString(), manualReviewReason: 'Kết quả Pay chưa xác định; không tự động gửi lại.' }
        : { failedAt: new Date().toISOString() };
      try {
        store.update(id, { status, lastError: String(error?.message || error), ...extra });
      } catch (stateError) {
        console.error(`[Pay State] Không thể ghi trạng thái ${id}:`, stateError?.stack || stateError?.message || stateError);
      }
      throw error;
    } finally {
      this.processing.delete(id);
    }
  }

  async handleInteraction(i) {
    const metricEnd = this.metrics.timed('interaction_ms', { kind: i?.commandName || i?.customId || 'interaction' });
    let rollbackPendingOrderId = null;
    let auditFailed = false;
    let auditError = '';
    void this.audit?.commandStart?.(i);
    const userKey = String(i?.user?.id || 'unknown');
    try {
      const gate = this.interactionLimiter.consume(userKey, 1);
      this.metrics.inc('interaction_total', 1, { name: i?.commandName || i?.customId || 'interaction' });
      void this.logger.info('Interaction received', { userId: userKey, command: i?.commandName || null, customId: i?.customId || null, guildId: i?.guildId || null, channelId: i?.channelId || null });
      if (!gate.allowed) { const error = new Error(`Bạn thao tác quá nhanh. Vui lòng thử lại sau ${Math.ceil(gate.retryAfterMs / 1000)} giây.`); error.code = 'RATE_LIMITED'; throw error; }
      if (i.isChatInputCommand() && ADMIN_COMMANDS.has(i.commandName)) {
        this.assertAdmin(i);
      }

      // /thumon và /banmon: phản hồi ngay bằng panel, không mở modal cấu hình.
      if (i.isChatInputCommand() && (i.commandName === 'thumon' || i.commandName === 'banmon')) {
        if (!i.channel?.isTextBased?.()) throw new Error('Lệnh phải được dùng trong kênh text.');
        const stock = parseAmount(i.options.getString('stock', true));
        const rate = moneyRate(i.options.getString('rt_1m', true));
        if (stock === 'all') throw new Error('Stock không được là `all`.');

        const panel = this.buildListingPanel(i.commandName, i.channel, stock, rate);
        panel.createdBy = i.user.id;
        await i.deferReply();
        store.addPanel(panel);
        try {
          await this.refreshBotName(900);
        } catch {}

        const message = await i.editReply({ embeds: [this.buildPanelEmbed(panel)], components: [this.buildPanelButtons(panel)] });
        store.updatePanel(panel.id, { messageId: message.id });

        // Nếu lúc phản hồi tên bot chưa kịp sync, edit panel ngay khi Worker trả lời.
        this.refreshBotName(2500).then(name => {
          if (!VALID_IGN.test(name)) return;
          const freshPanel = store.getPanel(panel.id);
          if (freshPanel) this.editPanel(panel.id, { ...freshPanel });
        }).catch(() => {});
        return true;
      }

      if (i.isChatInputCommand() && i.commandName === 'upstock') {
        const messageId = String(i.options.getString('message_id', true) || '').trim();
        const addStock = parseAmount(i.options.getString('stock', true));
        const newRateRaw = i.options.getString('rt_1m', false);
        if (!/^\d{15,22}$/.test(messageId)) throw new Error('Message ID không hợp lệ.');
        if (addStock === 'all' || !Number.isSafeInteger(Number(addStock)) || Number(addStock) <= 0) {
          throw new Error('Stock thêm phải là số Money hợp lệ, ví dụ `50m`.');
        }

        // /upstock dùng Message ID của chính panel Discord.
        // Không cần người dùng nhớ PANEL-xxxx: bot đọc customId của các nút trên message
        // để xác định panel chính xác rồi mới cập nhật stock.
        const panel = await this.resolvePanelFromMessage(i, messageId);
        if (!panel) throw new Error('Không tìm thấy panel từ Message ID này. Hãy dùng Message ID của đúng message panel.');

        return this.withStockLock(async () => {
          const freshPanel = store.getPanel(panel.id);
          if (!freshPanel) throw new Error('Panel không còn tồn tại trong dữ liệu.');

          const currentStock = Number(freshPanel.stock || 0);
          const nextStock = currentStock + Number(addStock);
          if (!Number.isSafeInteger(nextStock) || nextStock <= 0) throw new Error('Stock sau khi cộng vượt giới hạn an toàn.');

          const nextRate =
            newRateRaw == null || String(newRateRaw).trim() === ''
              ? Number(freshPanel.rate)
              : moneyRate(newRateRaw);

          const updated = store.updatePanel(freshPanel.id, {
            stock: nextStock,
            rate: nextRate,
            sold: false,
            enabled: true,
            restockedAt: new Date().toISOString(),
            restockedBy: i.user.id,
            restockedMessageId: messageId
          });
          if (!updated) throw new Error('Không thể cập nhật panel.');

          await this.editPanel(freshPanel.id, updated);
          await i.reply({
            ephemeral: true,
            content:
              `✅ **Đã UpStock**\n` +
              `🆔 Message ID: **${messageId}**\n` +
              `📌 Panel: **${freshPanel.id}**\n` +
              `📦 Stock: **${formatAmount(currentStock)} → ${formatAmount(nextStock)} Money**\n` +
              `💰 RT / 1M: **${nextRate.toLocaleString('vi-VN')}đ**`
          });
          return true;
        });
      }

      if (i.isChatInputCommand() && i.commandName === 'pay') {
        return i.showModal(this.buildPayModal());
      }

      if (i.isChatInputCommand() && ['status', 'checkbot', 'thongke', 'bdsd', 'lichsu'].includes(i.commandName)) {
        await i.deferReply({ ephemeral: true });
        if (i.commandName === 'status') return i.editReply({ embeds: [this.buildStatusEmbed(await this.getStatusData())] });
        if (i.commandName === 'checkbot') return i.editReply({ embeds: [this.buildCheckBotEmbed(await this.getBotCheckData())] });
        if (i.commandName === 'thongke') return i.editReply({ embeds: [this.buildStatsEmbed()] });
        if (i.commandName === 'bdsd') {
          const botData = await this.getBotCheckData().catch(error => ({ balanceError: error?.message || String(error), snapshot: this.getLocalSnapshot ? this.getLocalSnapshot() : null }));
          return i.editReply({ embeds: [this.buildBalanceMovementEmbed(botData)] });
        }
        return i.editReply({ embeds: [this.buildHistoryEmbed()] });
      }

      if (i.isButton() && i.customId.startsWith('panelsold:')) {
        this.assertAdmin(i);
        const panelId = i.customId.slice('panelsold:'.length);
        const panel = store.getPanel(panelId);
        if (!panel) throw new Error('Panel không còn tồn tại.');
        const updated = store.updatePanel(panelId, { sold: true, enabled: false, soldAt: new Date().toISOString(), soldBy: i.user.id });
        if (!updated) throw new Error('Không thể đánh dấu SOLD.');
        await this.editPanel(panelId, updated);
        return i.reply({ ephemeral: true, content: `✅ Panel **${panelId}** đã được đánh dấu **SOLD** và khóa đặt đơn.` });
      }

      if (i.isButton() && i.customId.startsWith('panelerror:')) {
        const panelId = i.customId.slice('panelerror:'.length);
        if (!store.getPanel(panelId)) throw new Error('Panel không còn tồn tại.');
        return i.showModal(this.buildPanelErrorModal(panelId));
      }

      if (i.isModalSubmit() && i.customId.startsWith('panelerror:')) {
        const panelId = i.customId.slice('panelerror:'.length);
        const panel = store.getPanel(panelId);
        if (!panel) throw new Error('Panel không còn tồn tại.');
        const detail = String(i.fields.getTextInputValue('error_detail') || '').trim();
        await this.notifyAdmins(`🐛 **BÁO LỖI PANEL**\n📌 Panel: **${panelId}**\n👤 User: <@${i.user.id}>\n📍 Channel: <#${panel.channelId}>\n📝 Lỗi: ${detail.slice(0, 1200)}`);
        return i.reply({ ephemeral: true, content: '✅ Đã gửi báo lỗi cho Admin.' });
      }

      if (i.isButton() && i.customId.startsWith('panelcalc:')) {
        const panelId = i.customId.slice('panelcalc:'.length);
        if (!store.getPanel(panelId)) throw new Error('Panel không còn tồn tại.');
        return i.showModal(this.buildPanelCalcModal(panelId));
      }

      if (i.isModalSubmit() && i.customId.startsWith('panelcalc:')) {
        const panelId = i.customId.slice('panelcalc:'.length);
        const panel = store.getPanel(panelId);
        if (!panel) throw new Error('Panel không còn tồn tại.');
        const parsed = parseMoneyOrVnd(i.fields.getTextInputValue('calc_value'));
        let money;
        let vnd;
        if (parsed.kind === 'money') { money = parsed.value; vnd = calcVnd(money, panel.rate); }
        else {
          vnd = parsed.value;
          money = Math.floor((vnd / Number(panel.rate)) * 1_000_000);
          if (!Number.isSafeInteger(money) || money <= 0) throw new Error('Số VNĐ này chưa đủ để quy đổi thành Money.');
        }
        return i.reply({ ephemeral: true, content:
          `🧮 **KẾT QUẢ TÍNH TIỀN**\n\n` +
          `📦 Panel: **${panel.id}**\n` +
          `💰 RT / 1M: **${Number(panel.rate).toLocaleString('vi-VN')}đ**\n` +
          `💎 Money: **${formatAmount(money)}**\n` +
          `💵 VNĐ: **${this.formatVnd(vnd)}**\n\n` +
          `↔️ **${formatAmount(money)} Money ⇄ ${this.formatVnd(vnd)}**` });
      }

      if (i.isButton() && i.customId.startsWith('paneltrade:')) {
        const panel = store.getPanel(i.customId.slice('paneltrade:'.length));
        if (!panel) throw new Error('Panel không còn tồn tại.');
        if (panel.sold === true || panel.enabled === false) throw new Error('Panel hiện đã SOLD/đóng giao dịch.');
        if (this.getAvailableStock(panel) <= 0) throw new Error('Panel đã hết stock khả dụng.');
        return i.showModal(this.buildTradeUserModal(panel));
      }

      if (i.isModalSubmit() && i.customId.startsWith('tradeform:')) {
        const panel = store.getPanel(i.customId.slice('tradeform:'.length));
        if (!panel) throw new Error('Panel không còn tồn tại.');
        const player = cleanName(i.fields.getTextInputValue('ingame'));
        let requestedAmount = parseAmount(i.fields.getTextInputValue('amount'));
        await i.deferReply({ ephemeral: true });
        const stockQueueBefore = this.getStockQueueStatus();
        if (stockQueueBefore.depth > 0) {
          await i.editReply({
            content:
              `⏳ **ĐƠN ĐÃ VÀO HÀNG ĐỢI STOCK**\n\n` +
              `📌 Hiện có **${stockQueueBefore.depth}** tác vụ đang khóa stock.\n` +
              `🔢 Vị trí dự kiến: **${stockQueueBefore.depth + 1}**\n` +
              `👤 IGN: **${player}**\n` +
              `💎 Yêu cầu: **${requestedAmount === 'all' ? 'TOÀN BỘ STOCK' : formatAmount(requestedAmount)} Money**\n\n` +
              `⏳ Bot sẽ xử lý tuần tự để không vượt stock hoặc tạo đơn trùng.`
          });
        }

        // Khóa toàn bộ chuỗi "đọc stock -> tính amount -> giữ stock -> tạo đơn".
        // Nếu chỉ khóa lúc decrement thì hai người có thể cùng thấy stock còn đủ và đặt vượt stock.
        const reserved = await this.withStockLock(async () => {
          const freshPanel = store.getPanel(panel.id);
          if (!freshPanel) throw new Error('Panel giao dịch không còn tồn tại.');

          const available = this.getAvailableStock(freshPanel);
          let amount = requestedAmount;
          if (amount === 'all') {
            if (freshPanel.type !== 'ban') throw new Error('`all` chỉ dùng cho **Mua Money** để lấy toàn bộ stock khả dụng.');
            amount = available;
            if (!Number.isSafeInteger(amount) || amount <= 0) throw new Error('Panel hiện không còn stock khả dụng.');
          }

          if (!Number.isSafeInteger(amount) || amount <= 0) throw new Error('Số Money không hợp lệ.');

          if (freshPanel.type === 'thu') {
            const duplicate = store.all().find(order =>
              order.type === 'thu' &&
              String(order.discordId) === String(i.user.id) &&
              RESERVABLE_STATUSES.has(String(order.status || '')) &&
              order.stockReserved === true &&
              !order.stockRestoredAt &&
              !this.isReservationExpired(order)
            );
            if (duplicate) throw new Error(`Bạn đang có đơn bán Money **${duplicate.id}** chưa hoàn tất. Hãy hoàn tất đơn hiện tại trước khi tạo đơn bán mới.`);
          }

          if (amount > available) {
            throw new Error(
              `Stock khả dụng hiện còn **${formatAmount(available)} Money**.\n` +
              `📦 Stock panel: **${formatAmount(freshPanel.stock)} Money**\n` +
              `🔒 Đang giữ cho đơn khác: **${formatAmount(this.getReservedStock(freshPanel.id))} Money**`
            );
          }

          const vnd = calcVnd(amount, freshPanel.rate);
          const id = makeId('KX');
          const now = Date.now();
          const order = store.add({
            id,
            type: freshPanel.type,
            panelId: freshPanel.id,
            server: this.getKingMcServer(),
            discordId: i.user.id,
            guildId: freshPanel.guildId || i.guildId || null,
            channelId: freshPanel.channelId || i.channelId || null,
            player,
            amount: Number(amount),
            rt: Number(freshPanel.rate),
            vnd,
            status: 'pending_confirm',
            stockReserved: true,
            stockDeductedAt: null,
            stockRestoredAt: null,
            stockDeductionMode: 'immediate_on_order',
            createdAt: new Date().toISOString(),
            createdAtMs: now
          });

          // Trừ stock ngay khi tạo đơn để panel không thể nhận thêm đơn vượt hàng tồn.
          // Hàm unlocked dùng chung lock của tradeform, tránh deadlock lock lồng nhau.
          await this.decrementPanelStockUnlocked(freshPanel.id, Number(amount), order.id);
          const deductedOrder = store.get(order.id) || order;
          return { order: deductedOrder, panel: store.getPanel(freshPanel.id) || freshPanel };
        });

        const { order, panel: updatedPanel } = reserved;
        void this.logger.info('Money trade order created', {
          orderId: order.id,
          type: order.type,
          userId: String(order.discordId),
          guildId: order.guildId,
          channelId: order.channelId,
          player: order.player,
          amount: Number(order.amount),
          rate: Number(order.rt),
          vnd: Number(order.vnd),
          panelId: order.panelId,
          stockAfter: Number(updatedPanel?.stock ?? 0),
          stockDeductionMode: order.stockDeductionMode,
          kingMcServer: order.server || this.getKingMcServer()
        });
        rollbackPendingOrderId = order.id;
        const id = order.id;
        const amount = Number(order.amount);
        const vnd = Number(order.vnd);
        const response = await i.editReply({
          content:
            (order.type === 'thu' ? '📤 **KIỂM TRA ĐƠN BÁN MONEY**' : '🛒 **KIỂM TRA ĐƠN MUA MONEY**') +
            `\n\n` +
            `🧾 Mã đơn: **${id}**\n` +
            `👤 IGN: **${player}**\n` +
            `💎 Money: **${formatAmount(amount)}**\n` +
            `💰 RT / 1M: **${Number(order.rt).toLocaleString('vi-VN')}đ**\n` +
            `💵 VNĐ: **${this.formatVnd(vnd)}**\n\n` +
            `⚠️ Kiểm tra đủ thông tin trước khi bấm **Xác nhận TT**.`,
          embeds: [this.buildOrderEmbed(order)],
          components: [this.buildConfirmRow(id)]
        });
        this.rememberLiveOrderReply(id, i, response);
        rollbackPendingOrderId = null;
        return response;
      }

      if (i.isModalSubmit() && i.customId === 'modal:pay') {
        const player = cleanName(i.fields.getTextInputValue('ingame'));
        const amount = parseAmount(i.fields.getTextInputValue('amount'));
        if (amount === 'all') throw new Error('Không dùng `all` cho /pay.');
        const now = Date.now();
        const order = store.add({ id: makeId('PAY'), type: 'pay', discordId: i.user.id, guildId: i.guildId || null, channelId: i.channelId || null, player, amount: Number(amount), status: 'pending_pay_confirm', createdAt: new Date(now).toISOString(), createdAtMs: now });
        rollbackPendingOrderId = order.id;
        const response = await i.reply({ ephemeral: true, content: '🔐 Kiểm tra thông tin trước khi Pay.', embeds: [this.buildOrderEmbed(order)], components: [this.buildConfirmRow(order.id)] });
        this.rememberLiveOrderReply(order.id, i, response);
        rollbackPendingOrderId = null;
        return response;
      }

      if (i.isButton() && i.customId.startsWith('cancel:')) {
        const id = i.customId.slice('cancel:'.length);
        const order = store.get(id);
        if (!order) throw new Error('Không tìm thấy đơn.');
        if (order.type === 'pay') this.assertAdmin(i); else this.assertOwner(order, i);
        if (this.processing.has(id)) throw new Error('Đơn đang được xử lý; không thể hủy lúc này.');
        if (['await_qr', 'admin_review', 'processing_bank', 'processing_pay', 'completed', 'ticket_open'].includes(order.status)) throw new Error('Đơn đã sang bước xử lý, không thể hủy.');
        this.processing.add(id);
        try {
          await i.deferUpdate();
          const fresh = store.get(id);
          if (!fresh || fresh.status !== order.status) throw new Error('Trạng thái đơn vừa thay đổi; vui lòng kiểm tra lại.');
          if (['thu', 'ban'].includes(String(fresh.type)) && fresh.stockDeductedAt && !fresh.stockRestoredAt) {
            await this.restorePanelStockForOrder(fresh, 'manual cancel');
          }
          const saved = store.update(id, { status: 'cancelled', stockReserved: false, cancelledAt: new Date().toISOString() });
          if (!saved) throw new Error('Không thể lưu trạng thái hủy đơn.');
          const updated = await i.editReply({ content: '❌ **Đã hủy đơn.**', embeds: [], components: [] });
          this.forgetLiveOrderReply(id);
          return updated;
        } finally {
          this.processing.delete(id);
        }
      }

      if (i.isButton() && i.customId.startsWith('confirm:')) {
        const id = i.customId.slice('confirm:'.length);
        if (i.message?.id) this.rememberLiveOrderReply(id, i, i.message);
        const order = store.get(id);
        if (!order) throw new Error('Không tìm thấy đơn.');
        if (order.type === 'pay') this.assertAdmin(i); else this.assertOwner(order, i);
        if (this.processing.has(id)) throw new Error('Đơn đang được xử lý; không thể xác nhận thêm lần nữa.');
        this.processing.add(id);
        try {
        await i.deferUpdate();
        const currentBeforeConfirm = store.get(id);
        if (!currentBeforeConfirm) throw new Error('Đơn không còn tồn tại.');
        if (!['pending_confirm', 'pending_pay_confirm'].includes(currentBeforeConfirm.status)) throw new Error('Đơn đã được xác nhận hoặc xử lý.');
        if (['pending_confirm', 'pending_pay_confirm'].includes(currentBeforeConfirm.status) && Date.now() - Number(currentBeforeConfirm.createdAtMs || new Date(currentBeforeConfirm.createdAt || 0).getTime() || 0) > RESERVATION_TTL_MS) {
          store.update(id, { status: 'cancelled', stockReserved: false, cancelledAt: new Date().toISOString(), cancelReason: 'confirmation expired' });
          await this.editLiveOrderReply(id, { content: `⏱️ **Đơn ${id} đã hết thời gian xác nhận. Vui lòng tạo đơn mới.**`, embeds: [], components: [] }).catch(() => {});
          this.forgetLiveOrderReply(id);
          throw new Error('Đơn đã hết thời gian xác nhận. Vui lòng tạo đơn mới.');
        }
        if (order.status !== 'pending_confirm' && order.status !== 'pending_pay_confirm') throw new Error('Đơn đã được xác nhận hoặc xử lý.');

        if (order.type === 'pay') {
          const confirmed = store.update(id, { status: 'pay_confirmed', confirmedAt: new Date().toISOString() });
          rollbackPendingOrderId = null;
          return i.editReply({ content: '✅ Đã xác nhận. Nhấn **Pay** để bot thực hiện.', components: [this.buildConfirmRow(id, true)], embeds: [this.buildOrderEmbed(confirmed || { ...order, status: 'pay_confirmed' })] });
        }

        const panel = store.getPanel(order.panelId);
        if (!panel) throw new Error('Panel không còn tồn tại.');
        // Đơn hiện tại đã giữ stock từ lúc khách nhập số tiền, phải loại chính nó khỏi phép tính.
        if (order.amount > this.getAvailableStock(panel, order.id)) {
          throw new Error(
            `Stock khả dụng không đủ cho đơn này.
` +
            `📦 Stock panel: **${formatAmount(panel.stock)} Money**
` +
            `🔒 Đơn khác đang giữ: **${formatAmount(this.getReservedStock(panel.id, order.id))} Money**
` +
            `💎 Đơn hiện tại: **${formatAmount(order.amount)} Money**`
          );
        }

        if (order.type === 'thu') {
          const botName = await this.refreshBotName(2500);
          if (!VALID_IGN.test(botName)) throw new Error('Chưa lấy được IGN bot Minecraft từ Worker.');
          store.update(id, {
            status: 'await_ingame',
            botName,
            awaitSinceAt: Date.now(),
            confirmedAt: new Date().toISOString()
          });
          void this.logger.info('THU Money confirmed; waiting game transfer', {
            orderId: order.id,
            userId: String(order.discordId),
            player: order.player,
            amount: Number(order.amount),
            vnd: Number(order.vnd),
            botName,
            command: `/pay ${botName} ${Number(order.amount)}`,
            server: order.server || this.getKingMcServer()
          });
          await i.editReply({
            content:
              `✅ **ĐƠN BÁN MONEY ĐÃ XÁC NHẬN**

` +
              `🧾 Mã đơn: **${order.id}**
` +
              `👤 IG khách: **${order.player}**
` +
              `🤖 IG bot nhận Money: **${botName}**
` +
              `💎 Money khách cần chuyển: **${formatAmount(order.amount)}**
` +
              `💰 RT / 1M: **${Number(order.rt).toLocaleString('vi-VN')}đ**
` +
              `💵 VNĐ dự kiến: **${this.formatVnd(order.vnd)}**

` +
              `📋 **COPY LỆNH PAY**

` +
              `💻 **Copy trên PC:**\n` +
              '```text\n' + `/pay ${botName} ${order.amount}` + '\n```\n' +
              `📱 **Copy trên điện thoại:**\n` +
              '`/pay ' + botName + ' ' + String(order.amount) + '`\n\n' +
              `⚠️ Chuyển đúng **${formatAmount(order.amount)} Money** vào **${botName}**.
` +
              `⏳ Hệ thống sẽ đọc chat. Khi nhận đủ, bot sẽ báo số Money nhận được và DM xin **mã QR**.`,
            embeds: [this.buildOrderEmbed({ ...order, botName }, '📤 BÁN MONEY • CHỜ CHUYỂN GAME')],
            components: []
          });
          this.rememberLiveOrderReply(order.id, i);
          rollbackPendingOrderId = null;
          return true;
        }

        if (!this.autoBankEnabled) throw new Error('AutoBank chưa hoạt động. Kiểm tra THUEAPIBANK_TOKEN và BANK_HISTORY_URL trước khi tạo đơn Mua Money.');
        this.assertBankConfig();
        const content = order.id;
        const qr = qrUrl({
          bankCode: process.env.BANK_CODE || 'MBBank',
          accountNo: String(process.env.ACCOUNT_NO || '').trim(),
          accountName: String(process.env.ACCOUNT_NAME || '').trim(),
          amount: order.vnd,
          content
        });

        // VietQR có thể không được Discord tải/render ổn định khi dùng trực tiếp
        // làm embed image. Tải QR về server trước rồi đính kèm trực tiếp vào
        // message Discord để QR luôn xuất hiện trong message.
        // Không chèn delay nhân tạo. Tải QR trực tiếp; nếu VietQR tạm thời không phản hồi
        // thì fallback sang URL QR để interaction không bị AbortError và đơn vẫn được tạo.
        let qrFile = null;
        let qrFileName = null;
        let qrAttachment = null;
        try {
          qrFile = await this.fetchAttachment(qr, 30000);
          qrFileName = `qr-${id}.${qrFile.extension}`;
          qrAttachment = new AttachmentBuilder(qrFile.buffer, { name: qrFileName });
        } catch (qrError) {
          console.warn(`[QR] Không tải được ảnh QR để đính kèm, fallback URL: ${qrError?.message || qrError}`);
        }
        const confirmedOrder = store.update(id, {
          status: 'await_bank',
          content,
          qrUrl: qr,
          qrFileName,
          confirmedAt: new Date().toISOString()
        });
        void this.logger.info('BAN Money confirmed; QR generated', {
          orderId: order.id,
          userId: String(order.discordId),
          player: order.player,
          amount: Number(order.amount),
          vnd: Number(order.vnd),
          bankCode: String(process.env.BANK_CODE || 'MBBank'),
          content,
          server: order.server || this.getKingMcServer()
        });
        if (!confirmedOrder) throw new Error('Không thể lưu trạng thái đơn sau khi tạo QR.');
        await i.editReply({
          content:
            `✅ **ĐƠN MUA MONEY ĐÃ XÁC NHẬN**

` +
            `🧾 Mã đơn: **${order.id}**
` +
            `👤 IGN nhận Money: **${order.player}**
` +
            `🤖 IG bot chuyển Money: **${this.getBotName()}**
` +
            `💎 Money sẽ nhận: **${formatAmount(order.amount)}**
` +
            `💰 RT / 1M: **${Number(order.rt).toLocaleString('vi-VN')}đ**
` +
            `💵 Số tiền phải chuyển: **${this.formatVnd(order.vnd)}**
` +
            `📝 Nội dung chuyển khoản: **${content}**

` +
            `📷 Quét QR bên dưới và chuyển **đúng số tiền + đúng nội dung**.
` +
            `⏳ Khi AutoBank nhận được, bot sẽ báo **số tiền + nội dung + người chuyển** rồi tự Pay Money cho **${order.player}**.`,
          embeds: [
            (() => {
              const embed = this.buildOrderEmbed(confirmedOrder, '🛒 MUA MONEY • CHỜ THANH TOÁN')
                .setDescription(
                  `💳 **QR CHUYỂN KHOẢN**\n\n` +
                  `🏦 Ngân hàng: **${String(process.env.BANK_CODE || 'MBBank')}**\n` +
                  `👤 Chủ TK: **${String(process.env.ACCOUNT_NAME || '').trim() || 'N/A'}**\n` +
                  `🔢 STK: **${String(process.env.ACCOUNT_NO || '').trim() || 'N/A'}**\n` +
                  `💵 Số tiền: **${this.formatVnd(order.vnd)}**\n` +
                  `📝 Nội dung: **${content}**\n\n` +
                  `⚠️ Không sửa số tiền hoặc nội dung.`
                );
              embed.setImage(qrFileName ? `attachment://${qrFileName}` : qr);
              return embed;
            })()
          ],
          ...(qrAttachment ? { files: [qrAttachment] } : {}),
          components: []
        });
        this.rememberLiveOrderReply(order.id, i);
        rollbackPendingOrderId = null;
        return true;
        } finally {
          this.processing.delete(id);
        }
      }

      if (i.isButton() && i.customId.startsWith('adminpaid:')) {
        this.assertAdmin(i);
        const id = i.customId.slice('adminpaid:'.length);
        const order = store.get(id);
        if (!order || order.type !== 'thu' || order.status !== 'admin_review') throw new Error('Đơn không còn chờ admin xác nhận.');
        if (this.processing.has(id)) throw new Error('Đơn đang được Admin khác xử lý.');
        this.processing.add(id);
        try {
          await i.deferUpdate();
          // Nếu stock đã trừ trước đó nhưng process chết trước khi ghi completed,
          // lần xác nhận lại chỉ hoàn thiện state, không gửi/chuyển gì thêm.
          try {
            await this.decrementPanelStock(order.panelId, order.amount, order.id);
          } catch (error) {
            store.update(id, { status: 'manual_review', stockReserved: true, lastError: String(error?.message || error) });
            await this.notifyAdmins(`⚠️ **THU MONEY • STOCK REVIEW**\nĐơn: ${order.id}\n${String(error?.message || error)}`);
            throw error;
          }

          const completed = store.update(id, {
            status: 'completed',
            stockReserved: false,
            stockDeductedAt: new Date().toISOString(),
            bankSentConfirmedAt: order.bankSentConfirmedAt || new Date().toISOString(),
            bankConfirmedBy: order.bankConfirmedBy || i.user.id,
            completedAt: new Date().toISOString()
          });
          if (!completed) throw new Error('Không thể lưu trạng thái hoàn tất của đơn.');
          void this.logger.info('THU Money completed by admin', {
            orderId: id,
            adminId: String(i.user.id),
            userId: String(order.discordId),
            player: order.player,
            amount: Number(order.amount),
            vnd: Number(order.vnd),
            stockDeductedAt: completed.stockDeductedAt || null,
            stockRestoredAt: completed.stockRestoredAt || null
          });

          await i.editReply({ content: `✅ **Đã xác nhận chuyển khoản. Đơn ${id} hoàn tất và stock đã trừ.**`, embeds: [], components: [] });
          await this.safeDM(order.discordId,
            `✅ **ADMIN ĐÃ XÁC NHẬN CHUYỂN KHOẢN**\n\n` +
            `🧾 Đơn: **${order.id}**\n` +
            `👤 IG: **${order.player}**\n` +
            `💎 Money game: **${formatAmount(order.amount)}**\n` +
            `💵 VNĐ: **${this.formatVnd(order.vnd)}**\n\n` +
            `🔎 Hãy kiểm tra số dư tài khoản.\n` +
            `⚠️ Nếu tiền chưa vào, bấm nút **Tạo Ticket** bên dưới.`,
            { components: [new ActionRowBuilder().addComponents(new ButtonBuilder().setCustomId(`ticket:${order.id}`).setLabel('🎫 Tạo Ticket nếu chưa nhận tiền').setStyle(ButtonStyle.Primary))] }
          );
          await this.sendLegitRequest({ ...order, status: 'completed' });
          await this.notifyAdmins(`✅ **THU MONEY HOÀN TẤT**\n${order.id}\nIG: ${order.player}\nMoney: ${formatAmount(order.amount)}\nVNĐ: ${this.formatVnd(order.vnd)}\nAdmin: ${i.user.id}`);
          return true;
        } finally {
          this.processing.delete(id);
        }
      }

      if (i.isButton() && i.customId.startsWith('adminreject:')) {
        this.assertAdmin(i);
        const id = i.customId.slice('adminreject:'.length);
        const order = store.get(id);
        if (!order || order.type !== 'thu' || order.status !== 'admin_review') throw new Error('Đơn không còn ở bước review.');
        if (this.processing.has(id)) throw new Error('Đơn đang được Admin khác xử lý.');
        // stockDeductedAt là dấu vết bền vững cho biết bước xác nhận thanh toán
        // đã chạy. Không được chuyển ngược về await_qr sau khi bước này bắt đầu.
        if (order.stockDeductedAt) throw new Error('Đơn đã thực hiện bước trừ stock; không thể yêu cầu QR lại. Hãy hoàn tất/review đơn.');
        this.processing.add(id);
        try {
          await i.deferUpdate();
          const updated = store.update(id, { status: 'await_qr', adminRejectedAt: new Date().toISOString() });
          if (!updated) throw new Error('Không thể cập nhật trạng thái đơn.');
          await i.editReply({ content: `⚠️ **Đã yêu cầu user gửi lại QR cho đơn ${id}.**`, embeds: [], components: [] });
          await this.safeDM(order.discordId, `⚠️ **Admin yêu cầu gửi lại QR** cho đơn **${id}**.\n\nHãy gửi lại ảnh mã QR chuyển khoản vào DM này.`);
          return true;
        } finally {
          this.processing.delete(id);
        }
      }

      if (i.isButton() && i.customId.startsWith('ticket:')) {
        const id = i.customId.slice('ticket:'.length);
        const order = store.get(id);
        return this.createTicketForOrder(i, order);
      }

      if (i.isButton() && i.customId.startsWith('paynow:')) {
        this.assertAdmin(i);
        const id = i.customId.slice('paynow:'.length);
        const order = store.get(id);
        if (!order || order.type !== 'pay' || order.status !== 'pay_confirmed') throw new Error('Đơn Pay chưa sẵn sàng.');
        const queueBefore = typeof this.localMcBot?.getPayQueueStatus === 'function' ? this.localMcBot.getPayQueueStatus() : null;
        const queueText = queueBefore && (queueBefore.length > 0 || queueBefore.running)
          ? `⏳ **ĐÃ ĐƯA ĐƠN VÀO HÀNG ĐỢI PAY**\n\n` +
            `🧾 Đơn: **${id}**\n` +
            `👤 IGN: **${order.player}**\n` +
            `💎 Money: **${formatAmount(order.amount)}**\n` +
            `📌 Đang xử lý: **${queueBefore.running ? '1' : '0'}** • Đang chờ trước đó: **${queueBefore.length}**\n\n` +
            `⏳ Bot sẽ thực hiện theo đúng thứ tự, không gửi trùng Pay.`
          : '⏳ **BOT ĐANG CHUẨN BỊ THỰC HIỆN PAY...**';
        await i.update({ content: queueText, components: [] });
        try {
          const result = await this.finalizePay(order);
          return i.editReply({ content: `✅ **PAY THÀNH CÔNG**\n${order.player} ← ${formatAmount(order.amount)} Money`, embeds: [this.buildOrderEmbed({ ...order, status: 'completed' }, '✅ PAY HOÀN TẤT').setDescription(result?.result?.message || result?.message || 'Minecraft đã nhận lệnh.')], components: [] });
        } catch (error) {
          if (error?.payOutcomeUnknown) {
            return i.editReply({
              content: `⚠️ **PAY CHƯA XÁC ĐỊNH**\n${String(error?.message || error)}\n\n🚫 Không bấm Pay lại. Hãy kiểm tra Minecraft/log và xử lý đơn **${id}**.`,
              components: []
            });
          }
          return i.editReply({ content: `❌ **PAY THẤT BẠI:** ${String(error?.message || error)}`, components: [] });
        }
      }

      return false;
    } catch (error) {
      auditFailed = true;
      auditError = String(error?.message || error);
      if (rollbackPendingOrderId) {
        try {
          const pending = store.get(rollbackPendingOrderId);
          if (pending && ['pending_confirm', 'pending_pay_confirm'].includes(pending.status)) {
            if (['thu', 'ban'].includes(String(pending.type)) && pending.stockDeductedAt && !pending.stockRestoredAt) {
              await this.restorePanelStockForOrder(pending, 'interaction response failed').catch(() => {});
            }
            store.update(rollbackPendingOrderId, { status: 'cancelled', stockReserved: false, cancelledAt: new Date().toISOString(), cancelReason: 'interaction response failed' });
          }
        } catch {}
      }
      const message = `❌ ${String(error?.message || error).slice(0, 1800)}`;
      if (i.deferred) await i.editReply({ content: message, embeds: [], components: [] }).catch(() => {});
      else if (i.replied) await i.followUp({ content: message, ephemeral: true }).catch(() => {});
      else await i.reply({ content: message, ephemeral: true }).catch(() => {});
      return true;
    } finally {
      metricEnd();
      this.metrics.inc(auditFailed ? 'interaction_error' : 'interaction_success', 1, { name: i?.commandName || i?.customId || 'interaction' });
      void this.audit?.commandResult?.(i, !auditFailed, auditError);
      void this.logger.info('Interaction finished', { userId: userKey, command: i?.commandName || null, customId: i?.customId || null, ok: !auditFailed, error: auditError || null });
    }
  }

  assertBankConfig() {
    const accountNo = String(process.env.ACCOUNT_NO || '').trim();
    const bankCode = String(process.env.BANK_CODE || 'MBBank').trim();
    const accountName = String(process.env.ACCOUNT_NAME || '').trim();
    if (!/^\d{4,32}$/.test(accountNo)) throw new Error('ACCOUNT_NO không hợp lệ; phải là chuỗi số 4-32 ký tự.');
    if (!/^[A-Za-z0-9._-]{2,40}$/.test(bankCode)) throw new Error('BANK_CODE không hợp lệ.');
    if (!accountName) throw new Error('Thiếu ACCOUNT_NAME.');
  }

  async getStatusData() {
    return this.statusCache.getOrSet('live', () => this._getStatusDataLive(), { ttlMs: 1500, staleMs: 5000, revalidate: true });
  }

  async _getStatusDataLive() {
    const ping = Number.isFinite(this.client.ws.ping) ? this.client.ws.ping : -1;
    let worker = null;
    let workerError = null;
    if (this.localMcBot) {
      worker = { online: !!this.localMcBot.isBotOnline, ready: !!this.localMcBot.isReady, latencyMs: 0, snapshot: this.getLocalSnapshot() };
    } else if (this.workerUrl) {
      try {
        const data = await this.fetchWorkerJson('/health', 5000);
        worker = { online: !!data.online, ready: !!data.ready, latencyMs: Number(data._latencyMs || 0), snapshot: data.mc || null };
      } catch (error) {
        workerError = error?.name === 'AbortError' ? 'Timeout' : String(error?.message || error);
      }
    } else workerError = 'Chưa cấu hình Worker URL.';

    return {
      ping,
      discordReady: !!this.client.isReady?.(),
      worker,
      workerError,
      stockQueue: this.getStockQueueStatus(),
      autoBank: this.autoBankEnabled,
      botName: this.getBotName(),
      uptimeMs: Math.floor(process.uptime() * 1000),
      orders: this.getOrdersSummary(),
      metrics: this.metrics.snapshot(),
      caches: { checkbot: this.checkbotCache.stats(), status: this.statusCache.stats(), discord: this.discordFetchCache.stats() },
      interactionRate: this.interactionLimiter.snapshot(),
      store: store.snapshot?.() || null
    };
  }

  buildStatusEmbed(data) {
    const o = data.orders;
    return new EmbedBuilder()
      .setTitle(`${this.icon('server', '📡')} KINGMC • SYSTEM STATUS`)
      .setColor(data.discordReady && data.worker?.online ? 0x57F287 : 0xFEE75C)
      .setDescription(
        `${data.discordReady ? '🟢' : '🔴'} Discord: **${data.discordReady ? 'ONLINE' : 'OFFLINE'}**\n` +
        `📶 Ping: **${data.ping >= 0 ? `${data.ping}ms` : 'N/A'}**\n` +
        `🤖 MC IGN: **${data.botName}**\n` +
        `🏦 AutoBank: **${data.autoBank ? 'ACTIVE' : 'NOT CONFIGURED'}**\n` +
        `⏱️ Uptime: **${this.formatDuration(data.uptimeMs)}**`
      )
      .addFields(
        { name: `${this.icon('bot', '🤖')} Worker / MC`, value: data.workerError ? `🔴 ${data.workerError}` : `${data.worker?.online ? '🟢' : '🔴'} Online: **${data.worker?.online ? 'YES' : 'NO'}**\n${data.worker?.ready ? '🟢' : '🟡'} Ready: **${data.worker?.ready ? 'YES' : 'NO'}**\n⏳ Pay Queue: **${Number(data.worker?.snapshot?.payQueueLength || 0)}**`, inline: true },
        { name: '📦 Stock Queue', value: `Đang khóa/đợi: **${Number(data.stockQueue?.depth || 0)}**\nĐang chờ: **${Number(data.stockQueue?.waiting || 0)}**`, inline: true },
        { name: `${this.icon('order', '📦')} Orders`, value: `Tổng: **${o.orders.length}**\n✅ Done: **${o.completed.length}**\n⚠️ Review: **${o.failed.length}**`, inline: true },
        { name: '🧠 CORE', value: `Rate-limit keys: **${data.interactionRate?.keys || 0}**\nCache checkbot: **${data.caches?.checkbot?.hitRate ?? 0}**\nQueue: **${data.worker?.snapshot?.payQueueLength || 0}**`, inline: false }
      )
      .setTimestamp();
  }

  async getBotCheckData() {
    const data = await this.checkbotCache.getOrSet('live', () => this.requestWorker('/api/checkbot'), { ttlMs: 2500, staleMs: 7500, revalidate: true });
    if (data?.stats) this.lastBotStats = data.stats;
    const remote = String(data?.snapshot?.username || '').trim();
    if (VALID_IGN.test(remote)) this.botName = remote;
    if (data.balance) {
      this.lastBotBalance = data.balance;
      this.lastBotBalanceAt = new Date().toISOString();
    }
    return {
      snapshot: data.snapshot || null,
      balance: data.balance || null,
      balanceError: data.balanceError || null,
      lastBotBalance: this.lastBotBalance,
      lastBotBalanceAt: this.lastBotBalanceAt,
      workerLatencyMs: Number(data._latencyMs || 0),
      stats: data.stats || this.lastBotStats || null,
      cache: this.checkbotCache.stats(),
      metrics: this.metrics.snapshot()
    };
  }

  buildCheckBotEmbed(data) {
    const s = data.snapshot || {};
    const queueLength = Number(s.payQueueLength || 0);
    const balanceText = data.balance || data.lastBotBalance || data.balanceError || 'N/A';
    return new EmbedBuilder()
      .setTitle('🤖 KINGMC • CHECK BOT')
      .setColor(s.online && s.ready ? 0x57F287 : 0xED4245)
      .setDescription(
        `👤 Ingame: **${s.username || this.getBotName()}**\n` +
        `🌐 Server: **${s.server || 'N/A'}**\n` +
        `📡 Status: **${s.online ? (s.ready ? 'ONLINE • READY' : 'ONLINE • STARTING') : 'OFFLINE'}**\n` +
        `⚙️ Action: **${s.currentAction || 'IDLE'}**\n` +
        `⏱️ Session: **${this.formatDuration(s.sessionPlayTimeMs || 0)}**\n` +
        `⏳ Pay Queue: **${queueLength}** ${s.payQueueRunning ? '• đang xử lý' : '• rảnh'}`
      )
      .addFields(
        { name: '💰 BALANCE', value: `**${String(balanceText).slice(0, 900)}**`, inline: false },
        { name: '📌 ACTION AGE', value: `**${this.formatDuration(s.actionAgeMs || 0)}**`, inline: true },
        { name: '📨 CHAT BUFFER', value: `**${String(s.chatBufferLength || 'N/A')}**`, inline: true },
        { name: '📡 WORKER LATENCY', value: `**${Number(data.workerLatencyMs || 0)}ms**`, inline: true },
        { name: '🧩 AFK', value: s.afkRoutineRunning ? '**RUNNING**' : '**STOPPED**', inline: true },
        { name: '📊 STATS', value: this.formatBotStats(data.stats), inline: false },
        { name: '⚠️ LAST ERROR', value: `\`${String(s.lastError || 'Không có').slice(0, 700)}\``, inline: true },
        { name: '🔌 LAST DISCONNECT', value: String(s.lastDisconnectAt || 'N/A').slice(0, 100), inline: true },
        { name: '📝 LAST KICK', value: `\`${String(s.lastKickReason || 'N/A').slice(0, 500)}\``, inline: false }
      )
      .setFooter({ text: data.lastBotBalanceAt ? `Balance cache: ${data.lastBotBalanceAt}` : 'Balance: live check' })
      .setTimestamp();
  }

  formatBotStats(stats) {
    if (!stats) return 'Chưa có dữ liệu Stats cache.';
    if (Array.isArray(stats.items)) {
      const lines = stats.items.slice(0, 12).map(item => {
        const name = String(item?.displayName || item?.name || 'Item').replace(/\s+/g, ' ').trim();
        const lore = Array.isArray(item?.lore) ? item.lore.filter(Boolean).join(' • ') : '';
        return `• ${name}${lore ? ` — ${lore.slice(0, 180)}` : ''}`;
      });
      return `**${String(stats.title || 'Minecraft Stats').replace(/[\`*_]/g, '')}**\n${lines.join('\n').slice(0, 950) || 'Không đọc được item Stats.'}`;
    }
    return `\`\`\`json\n${JSON.stringify(stats, null, 2).slice(0, 850)}\n\`\`\``;
  }

  getOrdersSummary() {
    const orders = store.all();
    const completed = orders.filter(o => o.status === 'completed');
    const payDone = completed.filter(o => o.type === 'pay');
    const thuDone = completed.filter(o => o.type === 'thu');
    const banDone = completed.filter(o => o.type === 'ban');
    const failed = orders.filter(o => ['pay_failed', 'manual_review'].includes(o.status));
    const cancelled = orders.filter(o => o.status === 'cancelled');
    return {
      orders,
      completed,
      payDone,
      thuDone,
      banDone,
      failed,
      cancelled,
      payKing: payDone.reduce((s, o) => s + Number(o.amount || 0), 0),
      thuKing: thuDone.reduce((s, o) => s + Number(o.amount || 0), 0),
      banKing: banDone.reduce((s, o) => s + Number(o.amount || 0), 0),
      thuCost: thuDone.reduce((s, o) => s + Number(o.vnd || 0), 0),
      banRevenue: banDone.reduce((s, o) => s + Number(o.vnd || 0), 0)
    };
  }

  buildStatsEmbed() {
    const s = this.getOrdersSummary();
    const net = s.banRevenue - s.thuCost;
    return new EmbedBuilder()
      .setTitle('📊 KINGMC • THỐNG KÊ')
      .setColor(net >= 0 ? 0x57F287 : 0xED4245)
      .setDescription(
        `📦 Tổng đơn: **${s.orders.length}**\n` +
        `✅ Hoàn tất: **${s.completed.length}**\n` +
        `📤 Money đã thu: **${formatAmount(s.thuKing)}**\n` +
        `📥 Money đã bán: **${formatAmount(s.banKing)}**\n` +
        `💵 Thu từ bán Money: **${this.formatVnd(s.banRevenue)}**\n` +
        `💵 Chi cho thu Money: **${this.formatVnd(s.thuCost)}**\n` +
        `🧮 Chênh lệch: **${this.formatVnd(net)}**`
      )
      .setTimestamp();
  }

  buildBalanceMovementEmbed(botData = null) {
    const orders = store.all();
    const completed = orders.filter(o => o.status === 'completed');
    const gameIn = orders
      .filter(o => o.type === 'thu' && o.gameReceivedAt)
      .reduce((s, o) => s + Number(o.gameReceivedAmount || o.amount || 0), 0);
    const gameOut = completed
      .filter(o => ['ban', 'pay'].includes(o.type))
      .reduce((s, o) => s + Number(o.amount || 0), 0);
    const bankInVnd = orders
      .filter(o => o.type === 'ban' && o.bankReceivedAt)
      .reduce((s, o) => s + Number(o.bankReceivedAmount || o.vnd || 0), 0);
    const bankOutVnd = completed
      .filter(o => o.type === 'thu')
      .reduce((s, o) => s + Number(o.vnd || 0), 0);
    const pending = orders.filter(o => !['completed', 'cancelled', 'pay_failed'].includes(String(o.status || '')));
    const queue = botData?.snapshot?.payQueueLength ?? this.localMcBot?.getPayQueueStatus?.().length ?? 0;
    const recent = orders
      .filter(o => ['thu', 'ban', 'pay'].includes(o.type))
      .slice(-6)
      .reverse()
      .map(o => `${o.id} • ${o.type.toUpperCase()} • ${o.status} • ${formatAmount(o.amount || 0)}`)
      .join('\n') || 'Chưa có giao dịch.';

    const recentGame = this.lastGamePayments
      .slice(0, 4)
      .map(x => `${x.orderId} • ${x.player} • ${formatAmount(x.amount)} • ${x.at}`)
      .join('\n') || 'Chưa ghi nhận payment game gần đây.';
    const recentBank = this.lastBankTransactions
      .slice(0, 4)
      .map(x => `${x.txId} • ${this.formatVnd(x.amount)} • ${x.sender}`)
      .join('\n') || 'Chưa ghi nhận giao dịch bank gần đây.';

    return new EmbedBuilder()
      .setTitle('📈 KINGMC • BIẾN ĐỘNG SỐ DƯ')
      .setColor(0x5865F2)
      .setDescription(
        `💰 **Live/Cache Balance:** **${String(botData?.balance || botData?.lastBotBalance || botData?.balanceError || this.lastBotBalance || 'N/A').slice(0, 700)}**\n` +
        `🤖 Bot: **${botData?.snapshot?.username || this.getBotName()}** • **${botData?.snapshot?.online ? 'ONLINE' : 'OFFLINE'}**\n` +
        `⏳ Pay Queue: **${queue}** • Đơn đang xử lý/chờ: **${pending.length}**`
      )
      .addFields(
        { name: '💎 GAME IN', value: `**${formatAmount(gameIn)}** Money\nTiền khách chuyển vào bot`, inline: true },
        { name: '💎 GAME OUT', value: `**${formatAmount(gameOut)}** Money\nBot chuyển cho khách`, inline: true },
        { name: '🏦 BANK IN', value: `**${this.formatVnd(bankInVnd)}**\nKhách chuyển khoản cho bot`, inline: true },
        { name: '🏦 BANK OUT', value: `**${this.formatVnd(bankOutVnd)}**\nBot chuyển VNĐ cho khách`, inline: true },
        { name: '🧾 HOÀN TẤT', value: `**${completed.length}** đơn`, inline: true },
        { name: '📦 PENDING', value: `**${pending.length}** đơn`, inline: true },
        { name: '🕘 GIAO DỊCH GẦN NHẤT', value: `\`\`\`\n${recent.slice(0, 900)}\n\`\`\``, inline: false },
        { name: '💎 GAME IN GẦN NHẤT', value: `\`\`\`\n${recentGame.slice(0, 900)}\n\`\`\``, inline: false },
        { name: '🏦 BANK IN GẦN NHẤT', value: `\`\`\`\n${recentBank.slice(0, 900)}\n\`\`\``, inline: false }
      )
      .setFooter({ text: this.lastBotBalanceAt ? `Balance cache cập nhật: ${this.lastBotBalanceAt}` : 'BDSD đọc từ order ledger + live checkbot' })
      .setTimestamp();
  }

  buildHistoryEmbed() {
    const events = store.history(30).slice().reverse();
    const lines = events.length
      ? events.map((e, n) => `${n + 1}. <t:${Math.floor(new Date(e.at).getTime() / 1000)}:t> ${e.orderId || e.panelId || 'SYSTEM'} • ${e.action || 'event'} • ${e.status || e.type || ''}`).join('\n')
      : 'Chưa có lịch sử.';
    return new EmbedBuilder()
      .setTitle('📜 KINGMC • LỊCH SỬ HỆ THỐNG')
      .setColor(0x5865F2)
      .setDescription(lines.slice(0, 3900))
      .setTimestamp();
  }

  formatVnd(value) {
    return `${Math.round(Number(value) || 0).toLocaleString('vi-VN')}đ`;
  }

  formatDuration(ms) {
    const total = Math.max(0, Math.floor(Number(ms) || 0) / 1000);
    const d = Math.floor(total / 86400);
    const h = Math.floor((total % 86400) / 3600);
    const m = Math.floor((total % 3600) / 60);
    const s = Math.floor(total % 60);
    return `${d ? `${d}d ` : ''}${h ? `${h}h ` : ''}${m ? `${m}m ` : ''}${s}s`;
  }
}

module.exports = PaymentService;
