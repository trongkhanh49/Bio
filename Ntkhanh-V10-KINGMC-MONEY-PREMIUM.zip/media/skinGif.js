'use strict';
const fs = require('fs');
const path = require('path');
const { spawn } = require('child_process');

// Pure JS GIF writer: 3-3-2 palette + LZW. Không cần native canvas/ImageMagick.
function palette332() {
  const palette = Buffer.alloc(256 * 3);
  let p = 0;
  for (let i = 0; i < 256; i++) {
    const r = (i >> 5) & 7;
    const g = (i >> 2) & 7;
    const b = i & 3;
    palette[p++] = Math.round(r * 255 / 7);
    palette[p++] = Math.round(g * 255 / 7);
    palette[p++] = Math.round(b * 255 / 3);
  }
  return palette;
}
function colorIndex(r,g,b) { return ((r >> 5) << 5) | ((g >> 6) << 2) | (b >> 6); }
function lzwEncode(indices, minCodeSize = 8) {
  const clear = 1 << minCodeSize, eoi = clear + 1, first = eoi + 1;
  let next = first, codeSize = minCodeSize + 1, dict = new Map();
  const codes = [clear];
  for (let i = 0; i < 256; i++) dict.set(String.fromCharCode(i), i);
  let prefix = '';
  for (const v of indices) {
    const c = String.fromCharCode(v);
    const candidate = prefix + c;
    if (dict.has(candidate)) prefix = candidate;
    else {
      codes.push(dict.get(prefix));
      if (next < 4096) {
        dict.set(candidate, next++);
        if (next === (1 << codeSize) && codeSize < 12) codeSize++;
      } else {
        codes.push(clear);
        dict = new Map(); for (let i = 0; i < 256; i++) dict.set(String.fromCharCode(i), i);
        next = first; codeSize = minCodeSize + 1;
      }
      prefix = c;
    }
  }
  if (prefix) codes.push(dict.get(prefix));
  codes.push(eoi);

  const out = []; let current = 0, bits = 0;
  dict = new Map(); next = first; codeSize = minCodeSize + 1;
  let emitted = 0;
  const emit = code => { current |= code << bits; bits += codeSize; while (bits >= 8) { out.push(current & 255); current >>>= 8; bits -= 8; } };
  for (const code of codes) {
    emit(code);
    if (code === clear) { next = first; codeSize = minCodeSize + 1; dict = new Map(); }
    else if (code !== eoi) {
      emitted++;
      if (emitted > 1 && next < 4096) {
        next++;
        if (next === (1 << codeSize) && codeSize < 12) codeSize++;
      }
    }
  }
  if (bits) out.push(current & 255);
  const blocks = [];
  for (let i = 0; i < out.length; i += 255) {
    const chunk = out.slice(i, i + 255); blocks.push(Buffer.from([chunk.length]), Buffer.from(chunk));
  }
  blocks.push(Buffer.from([0]));
  return Buffer.concat(blocks);
}
function encodeGif(width, height, frames, delayCs = 9) {
  const palette = palette332();
  const parts = [Buffer.from('GIF89a','ascii')];
  const screen = Buffer.alloc(7); screen.writeUInt16LE(width,0); screen.writeUInt16LE(height,2); screen[4] = 0xF7; screen[5] = 0; screen[6] = 0; parts.push(screen,palette);
  for (const frame of frames) {
    const gce = Buffer.from([0x21,0xF9,0x04,0x04,delayCs & 255,(delayCs>>8)&255,0,0]);
    const desc = Buffer.alloc(10); desc[0]=0x2C; desc.writeUInt16LE(0,1); desc.writeUInt16LE(0,3); desc.writeUInt16LE(width,5); desc.writeUInt16LE(height,7); desc[9]=0;
    const indices = Buffer.alloc(width*height);
    for(let i=0,j=0;i<indices.length;i++,j+=4) indices[i]=colorIndex(frame[j],frame[j+1],frame[j+2]);
    parts.push(gce,desc,Buffer.from([8]),lzwEncode(indices,8));
  }
  parts.push(Buffer.from([0x3B]));
  return Buffer.concat(parts);
}

function runSharp(buffer, width = 640, height = 640) {
  let sharp;
  try { sharp = require('sharp'); } catch { return null; }
  return Promise.resolve(sharp(buffer).resize(width, height, { fit:'contain', background:{r:8,g:12,b:22,alpha:1} }).raw().toBuffer({ resolveWithObject:true }));
}

async function buildSpinGifFromPngFrames(pngBuffers, outputPath, options = {}) {
  const width = Math.max(160, Number(options.width)||520);
  const height = Math.max(160, Number(options.height)||520);
  const rawFrames=[];
  for (const buffer of pngBuffers) {
    const result = await runSharp(buffer, width, height);
    if (!result?.data) throw new Error('Thiếu sharp để dựng GIF skin.');
    rawFrames.push(result.data);
  }
  const gif = encodeGif(width, height, rawFrames, Math.max(2, Number(options.delayCs)||9));
  fs.mkdirSync(path.dirname(outputPath), { recursive:true });
  fs.writeFileSync(outputPath, gif);
  return outputPath;
}

module.exports = { buildSpinGifFromPngFrames, encodeGif };
