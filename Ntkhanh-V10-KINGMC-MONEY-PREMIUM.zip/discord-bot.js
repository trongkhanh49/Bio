'use strict';

let started = false;

/**
 * Compatibility entrypoint for older deployments. The authoritative runtime is index.js;
 * keeping a second Discord/payment implementation here caused divergent commands and
 * could execute stale payment logic if another launcher imported this file.
 */
async function startDiscord() {
  if (started) return;
  started = true;
  require('./index.js');
}

module.exports = { startDiscord };
