'use strict';
const { EmbedBuilder } = require('discord.js');
const path = require('path');
const { TaskQueue } = require('./core/taskQueue');
const { StructuredLogger, redact } = require('./core/logger');
const { MetricsRegistry } = require('./core/metrics');

const DEFAULT_CHANNEL_ID = '1539656679119921252';
function trim(value,max=900){return String(value??'').replace(/\u0000/g,'').slice(0,max);}
function interactionKind(i){if(i?.isChatInputCommand?.())return'COMMAND';if(i?.isButton?.())return'BUTTON';if(i?.isModalSubmit?.())return'MODAL';if(i?.isStringSelectMenu?.())return'SELECT';return'INTERACTION';}
function getCommandOptions(i){if(!i?.isChatInputCommand?.())return'';try{return (i.options?.data||[]).flatMap(o=>o.options?.length?o.options.map(n=>`${n.name}=${trim(n.value,220)}`):[`${o.name}=${trim(o.value,220)}`]).join(' | ');}catch{return'';}}

class AuditLogger {
  constructor(client){
    this.client=client;
    this.channelId=String(process.env.AUDIT_LOG_CHANNEL_ID||DEFAULT_CHANNEL_ID).trim();
    this.enabled=process.env.AUDIT_LOG_ENABLED!=='0';
    this.maxEmbedText=3900;
    this.queue=new TaskQueue({name:'audit',concurrency:1,maxPending:1000});
    this.fileLogger=new StructuredLogger({name:'audit',dir:path.join(process.cwd(),'data','logs')});
    this.metrics=new MetricsRegistry();
    this.channelCache=null;
    this.channelCacheAt=0;
    this.channelCacheTtlMs=60_000;
  }

  async getChannel(){
    if(!this.enabled||!this.channelId)return null;
    if(this.channelCache && Date.now()-this.channelCacheAt<this.channelCacheTtlMs)return this.channelCache;
    try{const c=await this.client.channels.fetch(this.channelId);if(!c?.isTextBased?.()||typeof c.send!=='function')return null;this.channelCache=c;this.channelCacheAt=Date.now();return c;}
    catch(error){this.channelCache=null;console.warn('[Audit] Không lấy được kênh log:',error?.message||error);return null;}
  }

  enqueue(payload={}){
    const safe=redact(payload);
    void this.fileLogger.info('Discord audit event',safe);
    return this.queue.enqueue(()=>this._send(payload),{priority:Number(payload.priority||0),dedupeKey:payload.dedupeKey||''}).catch(error=>{this.metrics.inc('audit_failed');void this.fileLogger.error('Discord audit send failed',{error:error?.message,payload:safe});return false;});
  }

  async _send(payload){
    const channel=await this.getChannel();if(!channel)return false;
    const title=trim(payload.title||'KINGMC • AUDIT LOG',256), description=trim(payload.description||'',this.maxEmbedText);
    const color=Number.isInteger(payload.color)?payload.color:0x5865F2;
    const embed=new EmbedBuilder().setTitle(title).setColor(color).setDescription(description||'Không có mô tả.').setTimestamp();
    if(payload.fields?.length){const fields=payload.fields.filter(x=>x&&x.name).slice(0,25).map(x=>({name:trim(x.name,256),value:trim(x.value||'-',1024),inline:Boolean(x.inline)}));if(fields.length)embed.addFields(fields);}
    if(payload.footer)embed.setFooter({text:trim(payload.footer,2048)});
    await channel.send({embeds:[embed],allowedMentions:{parse:[]}});
    this.metrics.inc('audit_sent');
    return true;
  }

  commandStart(i){const kind=interactionKind(i),name=i?.commandName?`/${i.commandName}`:(i?.customId||kind),options=getCommandOptions(i);return this.enqueue({title:`📋 AUDIT • ${name} • START`,color:0x5865F2,description:'Bắt đầu xử lý interaction.',fields:[{name:'Loại',value:kind,inline:true},{name:'Người dùng',value:`${i?.user?.tag||i?.user?.username||'Unknown'} (<@${i?.user?.id||'0'}>)`,inline:true},{name:'User ID',value:String(i?.user?.id||'N/A'),inline:true},{name:'Guild',value:String(i?.guildId||'DM'),inline:true},{name:'Channel',value:String(i?.channelId||'N/A'),inline:true},{name:'Custom ID',value:trim(i?.customId||'N/A'),inline:false},...(options?[{name:'Options',value:`\`${options}\``,inline:false}]:[])],priority:10});}
  commandResult(i,success,errorMessage=''){const name=i?.commandName?`/${i.commandName}`:(i?.customId||interactionKind(i));this.metrics.inc(success?'command_success':'command_error',1,{command:name});return this.enqueue({title:`📋 AUDIT • ${name} • ${success?'SUCCESS':'ERROR'}`,color:success?0x57F287:0xED4245,description:success?'Interaction xử lý thành công.':trim(errorMessage||'Unknown error',1200),fields:[{name:'Người dùng',value:`${i?.user?.tag||i?.user?.username||'Unknown'} (<@${i?.user?.id||'0'}>)`,inline:true},{name:'User ID',value:String(i?.user?.id||'N/A'),inline:true},{name:'Guild',value:String(i?.guildId||'DM'),inline:true}],priority:20});}
  event(title,description,fields=[],options={}){return this.enqueue({title,description,fields,color:options.color,footer:options.footer,priority:options.priority||0,dedupeKey:options.dedupeKey});}
  worker(description,fields=[]){return this.event('⚙️ AUDIT • WORKER',description,fields,{color:0xFEE75C});}
  gamePayment(order,amount,message,extra={}){return this.event('💎 AUDIT • GAME PAYMENT','Phát hiện thông báo server xác nhận tiền vào.',[{name:'Đơn',value:String(order?.id||'Không ghép đơn'),inline:true},{name:'Người trả',value:String(extra.player||order?.player||'N/A'),inline:true},{name:'Số Money',value:String(amount||order?.amount||'N/A'),inline:true},{name:'MC Bot',value:String(extra.botName||order?.botName||'N/A'),inline:true},{name:'Trạng thái ghép',value:order?String(order.status||'N/A'):'UNMATCHED',inline:true},{name:'Server Message',value:`\`${trim(message||'N/A',900)}\``,inline:false}],{color:0x57F287});}
  bankTransaction(tx,matchedOrder=null){const amount=tx?.amount??tx?.transferAmount??tx?.creditAmount??tx?.receivedAmount??tx?.amountIn??tx?.transactionAmount??'N/A';return this.event('🏦 AUDIT • BANK MONEY IN','AutoBank phát hiện một giao dịch tiền vào.',[{name:'TX ID',value:trim(tx?.id||tx?.transactionID||tx?.transactionId||'N/A'),inline:true},{name:'Số tiền',value:String(amount),inline:true},{name:'Người chuyển',value:trim(tx?.senderName||tx?.fromName||tx?.payerName||tx?.accountName||tx?.sender||tx?.from||'API không trả'),inline:true},{name:'Nội dung',value:`\`${trim(tx?.description||tx?.content||tx?.transferContent||tx?.remark||tx?.memo||'N/A',900)}\``,inline:false},{name:'Đơn khớp',value:matchedOrder?String(matchedOrder.id):'CHƯA KHỚP',inline:true}],{color:0x57F287});}
  snapshot(){return {...this.metrics.snapshot(),queue:this.queue.snapshot()};}
}
module.exports={AuditLogger};
