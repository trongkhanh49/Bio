'use strict';
const assert = require('assert');
const Module = require('module');
const originalLoad = Module._load;
class OptionBuilder { constructor() { this.value = {}; } setName(v){this.value.name=v;return this;} setDescription(v){this.value.description=v;return this;} setRequired(v){this.value.required=!!v;return this;} setMinValue(v){this.value.min=v;return this;} addChoices(...v){this.value.choices=v;return this;} }
class CommandBuilder { constructor(){this.value={type:1,options:[]};} setName(v){this.value.name=v;return this;} setDescription(v){this.value.description=v;return this;} addSubcommand(fn){const x=new SubBuilder();fn(x);this.value.options.push(x.value);return this;} addStringOption(fn){const x=new OptionBuilder();fn(x);this.value.options.push(x.value);return this;} addIntegerOption(fn){const x=new OptionBuilder();fn(x);this.value.options.push(x.value);return this;} addBooleanOption(fn){const x=new OptionBuilder();fn(x);this.value.options.push(x.value);return this;} toJSON(){return JSON.parse(JSON.stringify(this.value));} }
class SubBuilder extends CommandBuilder { constructor(){super(); delete this.value.options; this.value.options=[]; } }
class EmbedBuilder { setTitle(){return this;} setColor(){return this;} setDescription(){return this;} setTimestamp(){return this;} addFields(){return this;} setFooter(){return this;} }
class SlashCommandBuilderFake extends CommandBuilder {}
Module._load = function(request, parent, isMain){ if(request==='discord.js') return {SlashCommandBuilder: SlashCommandBuilderFake, EmbedBuilder, AttachmentBuilder: class {constructor(){}}, ActionRowBuilder: class{}, ButtonBuilder: class{}, ButtonStyle:{}, ModalBuilder: class{}, TextInputBuilder: class{}, TextInputStyle:{}, ChannelType:{GuildText:0}, PermissionFlagsBits:{}, MessageFlags:{}}; return originalLoad.apply(this, arguments); };
const { V10CommandService } = require('../features/v10/command-service');
Module._load = originalLoad;
const commands = V10CommandService.buildCommands().map(x=>x.toJSON());
assert.equal(commands.length, 11, 'V10 command groups');
assert.deepEqual(commands.find(x=>x.name==='user').options.map(x=>x.name), ['sold','bought','orders','stats']);
assert.deepEqual(commands.find(x=>x.name==='bot').options.map(x=>x.name), ['info','status','uptime','ping','latency','health','stats','permissions','commands']);
assert.deepEqual(commands.find(x=>x.name==='system').options.map(x=>x.name), ['health','resources','cache','database','modules','dependencies','reload','maintenance']);
const { ConfigManager } = require('../core/config-manager');
const c = new ConfigManager(require('path').join(process.cwd(),'data','v10-test-config.json')); c.load(); c.setSystem('botHealth', false); assert.equal(c.isEnabled('botHealth'), false); require('fs').rmSync(c.file,{force:true});
const { SecurityManager } = require('../security/security-manager'); const sec = new SecurityManager(c); assert.equal(sec.enabled('antiSpam'), true); const status=sec.protectionStatus(); assert.ok(status.modules.antiSpam);
console.log('V10 smoke PASS:', commands.map(x=>x.name).join(', '));
