'use strict';
const assert = require('assert');
const { TTLCache } = require('../core/cache');
const { TokenBucketLimiter } = require('../core/rateLimiter');
const { TaskQueue } = require('../core/taskQueue');
const { ResourcePool } = require('../core/resourcePool');
const { inspectMinecraftMessage } = require('../core/messageGuard');
const { parseAmount } = require('../payment/amount-parser');
const payOps = require('../payment/pay-operations');

(async () => {
  assert.equal(parseAmount('1.5m'), 1500000);
  assert.equal(parseAmount('1q'), 1000000000000000);
  assert.equal(parseAmount('1_000_000'), 1000000);

  const cache = new TTLCache({ name: 'smoke', max: 10, ttlMs: 1000, staleMs: 1000 });
  let loads = 0;
  const first = await cache.getOrSet('x', async () => { loads++; return { ok: true }; });
  const second = await cache.getOrSet('x', async () => { loads++; return { ok: false }; });
  assert.deepEqual(first, second);
  assert.equal(loads, 1);

  const limiter = new TokenBucketLimiter({ capacity: 1, refillPerSecond: 0.01, maxKeys: 100 });
  assert.equal(limiter.consume('u').allowed, true);
  assert.equal(limiter.consume('u').allowed, false);

  const queue = new TaskQueue({ name: 'smoke', concurrency: 1, maxPending: 5 });
  const [a, b] = await Promise.all([
    queue.enqueue(() => Promise.resolve('a'), { priority: 0, meta: { test: 1 } }),
    queue.enqueue(() => Promise.resolve('b'), { priority: 5, meta: { test: 2 } })
  ]);
  assert.equal(a, 'a');
  assert.equal(b, 'b');
  assert.equal(queue.snapshot().completed, 2);

  let created = 0;
  const pool = new ResourcePool(async () => ({ id: ++created }), { size: 1, acquireTimeoutMs: 1000 });
  const held = await pool.acquire();
  const waiting = pool.acquire();
  setTimeout(() => pool.release(held), 20);
  const acquired = await waiting;
  assert.equal(created, 1);
  pool.release(acquired);
  await pool.close();

  const clean = inspectMinecraftMessage('Server: giao dich 50m cho Ntkhanh');
  assert.equal(clean.highRisk, false);
  const risky = inspectMinecraftMessage('FREE GIFT Nitro login https://discord.gg/abc123');
  assert.equal(risky.highRisk, true);
  // Quan trọng: regex anti-risk không bị stateful khi dùng liên tiếp.
  assert.equal(inspectMinecraftMessage('@everyone').highRisk, true);
  assert.equal(inspectMinecraftMessage('hello').highRisk, false);


  const nonexistent = payOps.get('__smoke_nonexistent__');
  assert.equal(nonexistent, null);
  console.log('SMOKE_OK');
})().catch(error => {
  console.error('SMOKE_FAIL', error?.stack || error);
  process.exit(1);
});
