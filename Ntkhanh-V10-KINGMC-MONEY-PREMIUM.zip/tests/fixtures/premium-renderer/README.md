# Premium renderer fixtures

These are deterministic Minecraft-style skin textures used to exercise the Premium PNG/GIF renderer. They are test assets, not fake runtime data and are never shown or loaded by the Money trading flow.
