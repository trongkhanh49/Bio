require('dotenv').config();
const http = require('http');
const crypto = require('crypto');
const { Client, GatewayIntentBits, Partials } = require('discord.js');
const PersistentBot = require('./mc-bot');
const PaymentService = require('./payment/service');
const CommandHandler = require('./handlers/commandHandler');
const { AuditLogger } = require('./audit');
const { ServerEmojiManager } = require('./emoji');
const { TokenBucketLimiter } = require('./core/rateLimiter');
const { StructuredLogger } = require('./core/logger');
const { MetricsRegistry } = require('./core/metrics');
const { ConfigManager } = require('./core/config-manager');
const { SystemManager } = require('./core/system-manager');
const { V10CommandService } = require('./features/v10/command-service');

const BOT_ROLE = String(process.env.BOT_ROLE || 'standalone').trim().toLowerCase();
const VALID_ROLES = new Set(['standalone', 'master', 'discord', 'worker', 'minecraft', 'mc']);
if (!VALID_ROLES.has(BOT_ROLE)) {
  console.error(`[Startup] BOT_ROLE không hợp lệ: ${BOT_ROLE}`);
  process.exit(1);
}
const IS_MC_ROLE = ['minecraft', 'worker', 'mc'].includes(BOT_ROLE);
const IS_DISCORD_ROLE = ['master', 'standalone', 'discord'].includes(BOT_ROLE);
const DISCORD_TOKEN = String(process.env.DISCORD_TOKEN || '').trim();
const CLIENT_ID = String(process.env.CLIENT_ID || '').trim();
const GUILD_ID = String(process.env.GUILD_ID || '').trim();
const WORKER_SECRET = String(process.env.WORKER_SECRET || '');
const ADMIN_ID = String(process.env.ADMIN_ID || '').trim();

const PAY_ADMIN_IDS = String(process.env.PAY_ADMIN_IDS || '').trim();
const rawPort = Number(process.env.PORT || 3000);
const PORT = Number.isInteger(rawPort) && rawPort > 0 && rawPort <= 65535 ? rawPort : 3000;
const rawMcPort = Number(process.env.MC_SERVER_PORT || 25565);
const MC_SERVER_PORT = Number.isInteger(rawMcPort) && rawMcPort > 0 && rawMcPort <= 65535 ? rawMcPort : 25565;
const MC_SERVER_HOSTS = String(process.env.MC_SERVER_HOSTS || 'sgp.kingmc.vn,kingmc.vn').split(',').map(x => x.trim()).filter(Boolean);
const STARTED_AT = Date.now();
const coreMetrics = new MetricsRegistry();
const appLogger = new StructuredLogger({ name: 'runtime', dir: require('path').join(process.cwd(), 'data', 'logs') });
const httpLimiter = new TokenBucketLimiter({ capacity: 120, refillPerSecond: 30, maxKeys: 10000 });
const configManager = new ConfigManager();
let systemManager = null;

process.on('unhandledRejection', error => {
  console.error('[Process] unhandledRejection:', error?.stack || error);
  void appLogger.error('Global unhandled rejection recovered at process boundary', { error: error?.stack || error?.message || String(error) });
});
process.on('uncaughtException', error => {
  console.error('[Process] uncaughtException:', error?.stack || error);
  void appLogger.fatal('Global uncaught exception; graceful process shutdown requested', { error: error?.stack || error?.message || String(error) });
  process.exitCode = 1;
  setTimeout(() => process.exit(1), 250).unref?.();
});

if (IS_MC_ROLE && !WORKER_SECRET) {
  console.error('[Startup] WORKER_SECRET bắt buộc với role worker/minecraft/mc. Dừng để tránh mở dịch vụ sai cấu hình.');
  process.exit(1);
}
if (IS_DISCORD_ROLE && !DISCORD_TOKEN) {
  console.error('[Startup] Thiếu DISCORD_TOKEN; Discord service không thể khởi động.');
  process.exit(1);
}
if (IS_DISCORD_ROLE && !CLIENT_ID) {
  console.error('[Startup] Thiếu CLIENT_ID; không thể đăng ký slash commands.');
  process.exit(1);
}

let localMcBot = null;
if (IS_MC_ROLE || BOT_ROLE === 'standalone') {
  const username = String(process.env.MC_USERNAME || 'NTK').trim().slice(0, 16);
  localMcBot = new PersistentBot(
    { username, authType: process.env.MC_AUTH_TYPE || 'offline', password: process.env.MC_PASSWORD || '' },
    MC_SERVER_HOSTS,
    MC_SERVER_PORT
  );
  localMcBot.on('error', error => { console.error('[MC-Bot]', error?.message || error); coreMetrics.inc('minecraft_connection_errors'); });

  const sendWorkerMasterLog = async (message, options = {}) => {
    if (!['worker', 'minecraft', 'mc'].includes(BOT_ROLE) || !process.env.MASTER_URL) return false;
    const payload = {
      message: String(message || '').slice(0, 1900),
      dm: options.dm !== false,
      auditOnly: options.auditOnly === true
    };
    try {
      const url = new URL('/api/notify', process.env.MASTER_URL);
      const transport = url.protocol === 'https:' ? require('https') : require('http');
      const encoded = JSON.stringify(payload);
      const request = transport.request(url, {
        method: 'POST',
        headers: {
          'content-type': 'application/json',
          'content-length': Buffer.byteLength(encoded),
          ...(WORKER_SECRET ? { 'x-worker-secret': WORKER_SECRET } : {})
        }
      });
      const timeout = setTimeout(() => {
        console.warn('[Worker notify] Master request timeout.');
        request.destroy();
      }, 5000);
      request.on('response', response => response.resume());
      request.on('close', () => clearTimeout(timeout));
      request.on('error', error => console.error('[Worker notify]', error?.message || error));
      request.end(encoded);
      return true;
    } catch (error) {
      console.error('[Worker notify setup]', error?.message || error);
      return false;
    }
  };

  localMcBot.on('notifyAdmin', message => {
    void sendWorkerMasterLog(message, { dm: true });
  });

  localMcBot.on('payQueued', data => {
    void sendWorkerMasterLog(
      `⏳ WORKER PAY QUEUED\n` +
      `Queue #${data?.queueId || 'N/A'}\n` +
      `Request: ${data?.requestId || 'N/A'}\n` +
      `IGN: ${data?.player || 'N/A'}\n` +
      `Money: ${data?.amount || 'N/A'}\n` +
      `Vị trí: ${data?.position ?? 'N/A'}`,
      { dm: false, auditOnly: true }
    );
  });

  localMcBot.on('payProcessing', data => {
    void sendWorkerMasterLog(
      `▶️ WORKER PAY PROCESSING\n` +
      `Queue #${data?.queueId || 'N/A'}\n` +
      `Request: ${data?.requestId || 'N/A'}\n` +
      `IGN: ${data?.player || 'N/A'}\n` +
      `Money: ${data?.amount || 'N/A'}`,
      { dm: false, auditOnly: true }
    );
  });

  localMcBot.on('payFinished', data => {
    void sendWorkerMasterLog(
      `${data?.success ? '✅' : data?.payOutcomeUnknown ? '⚠️' : '❌'} WORKER PAY FINISHED\n` +
      `Queue #${data?.queueId || 'N/A'}\n` +
      `Request: ${data?.requestId || 'N/A'}\n` +
      `IGN: ${data?.player || 'N/A'}\n` +
      `Money: ${data?.amount || 'N/A'}\n` +
      `Success: ${data?.success ? 'YES' : 'NO'}\n` +
      `Outcome Unknown: ${data?.payOutcomeUnknown ? 'YES' : 'NO'}\n` +
      `Error: ${String(data?.error || 'Không có').slice(0, 900)}`,
      { dm: false, auditOnly: true }
    );
  });
  localMcBot.connect();
}

systemManager = new SystemManager({ config: configManager, metrics: coreMetrics, logger: appLogger, localMcBot });
const applyRuntimeConfig = () => {
  try { localMcBot?.setAutoReconnect?.(configManager.isEnabled('autoReconnect')); } catch (error) { void appLogger.warn('Runtime config apply failed', { error: error?.message || String(error) }); }
};
configManager.on('reload', applyRuntimeConfig);
configManager.on('change', applyRuntimeConfig);
applyRuntimeConfig();

function authorized(req) {
  if (!WORKER_SECRET) return false;
  const supplied = String(req.headers['x-worker-secret'] || '');
  const a = Buffer.from(supplied);
  const b = Buffer.from(WORKER_SECRET);
  return a.length === b.length && a.length > 0 && crypto.timingSafeEqual(a, b);
}

function json(res, status, data) {
  res.writeHead(status, { 'content-type': 'application/json; charset=utf-8', 'cache-control': 'no-store' });
  res.end(JSON.stringify(data));
}

function readBody(req) {
  return new Promise((resolve, reject) => {
    const MAX_BODY_BYTES = 20000;
    const contentLength = Number(req.headers['content-length'] || 0);
    if (Number.isFinite(contentLength) && contentLength > MAX_BODY_BYTES) {
      try { req.resume(); } catch {}
      const error = new Error('Body too large'); error.code = 'BODY_TOO_LARGE'; return reject(error);
    }
    const chunks = [];
    let totalBytes = 0;
    let settled = false;
    const fail = error => {
      if (settled) return;
      settled = true;
      try { req.resume(); } catch {}
      reject(error);
    };
    req.on('data', chunk => {
      if (settled) return;
      const buffer = Buffer.isBuffer(chunk) ? chunk : Buffer.from(String(chunk));
      totalBytes += buffer.length;
      if (totalBytes > MAX_BODY_BYTES) {
        const error = new Error('Body too large');
        error.code = 'BODY_TOO_LARGE';
        fail(error);
        return;
      }
      chunks.push(buffer);
    });
    req.on('end', () => {
      if (settled) return;
      settled = true;
      const body = Buffer.concat(chunks).toString('utf8');
      try { resolve(JSON.parse(body || '{}')); }
      catch { const error = new Error('Invalid JSON'); error.code = 'INVALID_JSON'; reject(error); }
    });
    req.on('error', error => fail(error));
  });
}

function snapshot() {
  if (typeof localMcBot?.getStatusSnapshot === 'function') return localMcBot.getStatusSnapshot();
  return {
    username: localMcBot?.credentials?.username || null,
    server: `${MC_SERVER_HOSTS[0] || 'unknown'}:${MC_SERVER_PORT}`,
    online: !!localMcBot?.isBotOnline,
    ready: !!localMcBot?.isReady,
    currentAction: localMcBot?.currentAction || null,
    sessionPlayTimeMs: 0
  };
}

systemManager.start();

const server = http.createServer(async (req, res) => {
  req.setTimeout(Math.max(45000, Number(process.env.HTTP_REQUEST_TIMEOUT_MS) || 45000), () => {
    try { req.destroy(new Error('Request timeout')); } catch {}
  });
  try {
    const url = new URL(req.url, `http://${req.headers.host || 'localhost'}`);

    if (url.pathname === '/' || url.pathname === '/health') {
      return json(res, 200, {
        status: 'OK',
        role: BOT_ROLE,
        online: !!localMcBot?.isBotOnline,
        ready: !!localMcBot?.isReady,
        uptimeMs: Date.now() - STARTED_AT,
        mc: snapshot(),
        timestamp: new Date().toISOString(),
        v10: systemManager.status()
      });
    }

    const address = String(req.headers['x-forwarded-for'] || req.socket?.remoteAddress || 'unknown').split(',')[0].trim();
    const httpGate = httpLimiter.consume(address, 1);
    coreMetrics.inc('http_requests', 1, { path: url.pathname, method: req.method });
    if (!httpGate.allowed) return json(res, 429, { success: false, error: 'Too many requests', retryAfterMs: httpGate.retryAfterMs });
    if (!authorized(req)) { void appLogger.warn('API unauthorized request', { path: url.pathname, method: req.method, address }); return json(res, 401, { success: false, error: 'Unauthorized' }); }

    if (url.pathname === '/api/checkbot' && req.method === 'GET') {
      if (!localMcBot) return json(res, 503, { success: false, error: 'No Minecraft worker' });
      const current = snapshot();
      if (!current.online) return json(res, 200, { success: true, snapshot: current, balance: null, balanceError: 'Minecraft bot đang offline.' });

      let balance = null;
      let balanceError = null;
      let stats = localMcBot.lastStatsResult || null;
      let statsError = null;
      try {
        if (localMcBot.currentAction || localMcBot.targetPlayer) throw new Error(`Bot đang bận: ${localMcBot.currentAction || 'unknown'}.`);
        balance = await localMcBot.getBalance(localMcBot.credentials.username, Number(process.env.CHECKBOT_TIMEOUT_MS) || 12000);
      } catch (error) { balanceError = error?.message || String(error); }
      try {
        if (!localMcBot.currentAction && !localMcBot.targetPlayer && localMcBot.isBotOnline && localMcBot.isReady) {
          stats = await localMcBot.getStats(localMcBot.credentials.username, Number(process.env.CHECKBOT_STATS_TIMEOUT_MS) || 12000);
        }
      } catch (error) { statsError = error?.message || String(error); }
      return json(res, 200, { success: true, snapshot: localMcBot.getStatusSnapshot?.() || current, balance, balanceError, stats, statsError, metrics: coreMetrics.snapshot() });
    }

    if (url.pathname === '/api/chat' && req.method === 'GET') {
      if (!localMcBot) return json(res, 503, { success: false, error: 'No Minecraft worker' });
      const sinceValue = url.searchParams.get('since');
      const sinceRaw = sinceValue === null || sinceValue === '' ? 0 : Number(sinceValue);
      if (!Number.isSafeInteger(sinceRaw) || sinceRaw < 0) return json(res, 400, { success: false, error: 'since không hợp lệ.' });
      return json(res, 200, { success: true, messages: localMcBot.getChatSince(sinceRaw), nextSince: localMcBot.chatSequence });
    }

    if (url.pathname === '/api/pay' && req.method === 'POST') {
      if (!localMcBot) return json(res, 503, { success: false, error: 'No Minecraft worker' });
      const body = await readBody(req);
      const player = String(body.player || '').trim();
      const amount = Number(body.amount);
      const requestId = String(body.requestId || '').trim();
      const timeoutMsRaw = Number(body.timeoutMs || 12000);
      const timeoutMs = Number.isFinite(timeoutMsRaw) ? Math.max(3000, Math.min(timeoutMsRaw, 30000)) : 12000;
      if (!/^[A-Za-z0-9_]{3,16}$/.test(player)) return json(res, 400, { success: false, error: 'Tên Minecraft không hợp lệ.' });
      if (!Number.isSafeInteger(amount) || amount <= 0) return json(res, 400, { success: false, error: 'Số King xu không hợp lệ.' });
      if (!/^[A-Za-z0-9_-]{6,80}$/.test(requestId)) return json(res, 400, { success: false, error: 'requestId không hợp lệ.' });
      // Không từ chối request chỉ vì worker đang bận/offline tạm thời.
      // PersistentBot sẽ đưa Pay vào hàng đợi và tự chạy khi action slot rảnh.
      const result = await localMcBot.pay(player, amount, timeoutMs, requestId);
      coreMetrics.inc('http_pay_success');
      return json(res, 200, { success: true, result });
    }

    if (url.pathname === '/api/worker/control' && req.method === 'POST') {
      if (String(process.env.WORKER_CONTROL_ENABLED || '1') === '0') return json(res, 403, { success: false, error: 'Worker control đang bị tắt bởi config.' });
      if (!localMcBot) return json(res, 503, { success: false, error: 'No Minecraft worker' });
      const body = await readBody(req);
      const action = String(body.action || '').trim().toLowerCase();
      if (!['start', 'stop', 'restart', 'reconnect'].includes(action)) return json(res, 400, { success: false, error: 'Worker action không hợp lệ.' });
      if (action === 'start' || action === 'reconnect') localMcBot.connect();
      else if (action === 'stop') localMcBot.stop?.(`V10 ${action}`);
      else if (typeof localMcBot.restart === 'function') await localMcBot.restart('V10 restart');
      else { localMcBot.stop?.('V10 restart'); setTimeout(() => localMcBot.connect(), 2500).unref?.(); }
      if (systemManager.config?.isEnabled?.('workerManager')) systemManager.metrics.inc('worker_control_actions');
      void appLogger.info('Worker control', { action, actor: req.headers['x-worker-actor'] || 'remote-v10', path: url.pathname });
      return json(res, 200, { success: true, action, snapshot: snapshot() });
    }

    if (url.pathname === '/api/mc/command' && req.method === 'POST') {
      if (!localMcBot) return json(res, 503, { success: false, error: 'No Minecraft worker' });
      const body = await readBody(req);
      const command = String(body.command || '').replace(/^\//, '').trim();
      if (!command || command.length > 200) return json(res, 400, { success: false, error: 'Minecraft command không hợp lệ.' });
      if (!localMcBot.bot || !localMcBot.isBotOnline) return json(res, 409, { success: false, error: 'Minecraft bot đang offline.' });
      localMcBot.bot.chat(`/${command}`);
      void appLogger.info('Minecraft admin command', { command });
      return json(res, 200, { success: true, command, snapshot: snapshot() });
    }

    if (url.pathname === '/api/logs' && req.method === 'GET') {
      const scope = String(url.searchParams.get('scope') || '').trim().toLowerCase();
      const dir = require('path').join(process.cwd(), 'data', 'logs');
      const files = require('fs').existsSync(dir) ? require('fs').readdirSync(dir).filter(f => !scope || f.toLowerCase().includes(scope)).sort().slice(-10) : [];
      const chunks = files.map(file => ({ file, text: require('fs').readFileSync(require('path').join(dir, file), 'utf8').split(/\r?\n/).filter(Boolean).slice(-60) }));
      return json(res, 200, { success: true, scope, files: chunks });
    }

    if (url.pathname === '/api/v10/status' && req.method === 'GET') {
      return json(res, 200, { success: true, ...systemManager.status(), timestamp: new Date().toISOString() });
    }

    if (url.pathname === '/api/notify' && req.method === 'POST') {
      const body = await readBody(req);
      const messageText = String(body.message || '').trim();
      if (messageText && global.discordClient) {
        try {
          if (global.discordClient.auditLogger) {
            await global.discordClient.auditLogger.worker(messageText, [
              { name: 'Worker Role', value: BOT_ROLE, inline: true },
              { name: 'Host', value: MC_SERVER_HOSTS[0] || 'N/A', inline: true },
              { name: 'Time', value: new Date().toISOString(), inline: true },
              { name: 'Delivery', value: body.auditOnly ? 'AUDIT ONLY' : body.dm === false ? 'AUDIT (NO DM)' : 'AUDIT + DM', inline: true }
            ]);
          }
        } catch (error) {
          console.warn('[Notify Audit]', error?.message || error);
        }

        if (body.dm !== false && body.auditOnly !== true) {
          const admins = new Set([
            ...String(PAY_ADMIN_IDS || ADMIN_ID).split(',').map(x => x.trim()).filter(Boolean)
          ]);
          const paymentService = global.discordClient.paymentService;
          await Promise.all([...admins].map(id => {
            const dmText = `⚙️ **WORKER LOG**\n${messageText.slice(0, 1800)}`;
            return paymentService?.safeDM ? paymentService.safeDM(id, dmText) : Promise.resolve().then(async () => {
              try { await (await global.discordClient.users.fetch(id)).send(dmText); return true; }
              catch (error) { console.warn('[Notify DM]', error?.message || error); return false; }
            });
          }));
        }
      }
      return json(res, 200, { success: true });
    }

    return json(res, 404, { success: false, error: 'Not found' });
  } catch (error) {
    coreMetrics.inc('http_errors', 1, { code: error?.code || 'unknown' });
    void appLogger.error('HTTP request failed', { path: req.url, method: req.method, code: error?.code, error: error?.message || String(error) });
    console.error('[HTTP]', error?.stack || error?.message || error);
    const status = error?.code === 'BODY_TOO_LARGE' ? 413 : error?.code === 'INVALID_JSON' ? 400 : 500;
    return json(res, status, { success: false, error: String(error?.message || error) });
  }
});

server.on('error', error => console.error('[HTTP Server]', error?.stack || error?.message || error));
server.listen(PORT, () => { console.log(`[HTTP] :${PORT} role=${BOT_ROLE}`); void appLogger.info('HTTP server started',{port:PORT,role:BOT_ROLE}); });

if (IS_DISCORD_ROLE && DISCORD_TOKEN) {
  const client = new Client({
    intents: [
      GatewayIntentBits.Guilds,
      GatewayIntentBits.DirectMessages,
      GatewayIntentBits.MessageContent
    ],
    partials: [Partials.Channel]
  });
  global.discordClient = client;
  const auditLogger = new AuditLogger(client);
  client.auditLogger = auditLogger;
  const emojiManager = new ServerEmojiManager(client);
  client.emojiManager = emojiManager;

  systemManager.attach({ client });
  const payment = new PaymentService(client, localMcBot);
  client.paymentService = payment;
  const v10 = new V10CommandService({ client, payment, localMcBot, audit: auditLogger, config: configManager, logger: appLogger });
  client.v10 = v10;
  client.systemManager = systemManager;
  systemManager.attach({ client, jobQueue: v10.jobs.queue, scheduler: v10.scheduler });
  const commands = new CommandHandler(client);
  client.commandHandler = commands;
  commands.loadCommands();

  client.once('clientReady', async () => {
    console.log(`[Discord] Ready as ${client.user.tag}`); void appLogger.info('Discord ready',{tag:client.user.tag,guilds:client.guilds.cache.size});
    try {
      const emojiCount = await emojiManager.load();
      console.log(`[Emoji] ✅ Loaded ${emojiCount} custom emoji(s) from configured guilds.`);
    } catch (error) {
      console.warn('[Emoji] Load:', error?.message || error);
    }
    try {
      await commands.registerSlashCommands(DISCORD_TOKEN, CLIENT_ID, GUILD_ID);
    } catch (error) {
      console.error('[CommandHandler] Registration:', error?.stack || error?.message || error);
    }
  });

  client.on('interactionCreate', async interaction => {
    const gate = v10.security.limiter('interaction-global', { capacity: 25, refillPerSecond: 5 }).consume(String(interaction.user?.id || 'anonymous'), 1);
    if (!gate.allowed) {
      if (!interaction.replied && !interaction.deferred) await interaction.reply({ content: `⏳ Bạn thao tác quá nhanh. Thử lại sau khoảng ${Math.ceil(gate.retryAfterMs / 1000)}s.`, ephemeral: true }).catch(() => {});
      void appLogger.warn('Global interaction rate limit', { userId: interaction.user?.id, customId: interaction.customId, command: interaction.commandName, retryAfterMs: gate.retryAfterMs });
      return;
    }
    void auditLogger.commandStart(interaction);
    try {
      if (['bot','server','mc','mcworker','mcadmin','auto','security','backup','logs','system','user'].includes(String(interaction.commandName || ''))) {
        await v10.handle(interaction);
      } else {
        await payment.handleInteraction(interaction);
      }
    } catch (error) {
      console.error('[Interaction]', error?.stack || error?.message || error);
      void auditLogger.commandResult(interaction, false, error?.message || String(error));
      if (!interaction.replied && !interaction.deferred) {
        await interaction.reply({ content: '❌ Hệ thống đang bận, thử lại sau. Chi tiết đã được ghi log cho Admin.', ephemeral: true }).catch(() => {});
      } else if (interaction.deferred) {
        await interaction.editReply({ content: '❌ Hệ thống gặp lỗi. Event + stack đã được ghi log V10.', embeds: [], components: [] }).catch(() => {});
      }
    }
  });

  client.on('messageCreate', async message => {
    try {
      const result = v10.security.inspectMessage(message);
      if (!result.allowed) {
        const hardBlock = result.reasons.includes('anti-secret') || result.reasons.includes('anti-invite') || result.reasons.includes('anti-mention');
        if (hardBlock || process.env.SECURITY_AUTO_DELETE === '1') await message.delete().catch(() => {});
        await auditLogger.event('🛡️ SECURITY • MESSAGE EVENT', `Message security candidate: ${message.id}`, [
          { name: 'Guild', value: String(message.guildId || 'DM'), inline: true },
          { name: 'User', value: `<@${message.author?.id || '0'}>`, inline: true },
          { name: 'Reasons', value: result.reasons.join(', '), inline: false }
        ], { color: 0xED4245 });
      }
    } catch (error) {
      void appLogger.error('Security message handler failed', { error: error?.stack || error?.message || String(error) });
    }
  });

  const eventWindows = new Map();
  const markSecurityEvent = (type, guildId, meta = {}, threshold = 5) => {
    const key = `${guildId}:${type}`; const now = Date.now(); const list = (eventWindows.get(key) || []).filter(t => now - t < 60000); list.push(now); eventWindows.set(key, list);
    v10.security.record(type, { guildId, ...meta, countLast60s: list.length });
    if (list.length >= threshold) { void v10.security.logger.error(`Mass-action threshold detected: ${type}`, { guildId, ...meta, countLast60s: list.length, threshold }); void v10.security.logger.error('Anti-nuke protection requires admin review; no destructive auto-remediation was applied.', { guildId, type }); }
  };
  client.on('guildBanAdd', ban => { if (v10.security.enabled('antiMassBan')) markSecurityEvent('anti_mass_ban', ban.guild?.id, { userId: ban.user?.id }, 5); });
  client.on('guildMemberRemove', member => { if (v10.security.enabled('antiMassKick')) markSecurityEvent('anti_mass_kick', member.guild?.id, { userId: member.user?.id }, 8); });
  client.on('channelDelete', channel => { if (v10.security.enabled('antiMassChannelDelete')) markSecurityEvent('anti_mass_channel_delete', channel.guild?.id, { channelId: channel.id, name: channel.name }, 4); });
  client.on('channelCreate', channel => { if (v10.security.enabled('antiMassChannelCreate')) markSecurityEvent('anti_mass_channel_create', channel.guild?.id, { channelId: channel.id, name: channel.name }, 8); });
  client.on('roleDelete', role => { if (v10.security.enabled('antiMassRoleDelete')) markSecurityEvent('anti_mass_role_delete', role.guild?.id, { roleId: role.id, name: role.name }, 4); });
  client.on('roleCreate', role => { if (v10.security.enabled('antiMassRoleCreate')) markSecurityEvent('anti_mass_role_create', role.guild?.id, { roleId: role.id, name: role.name }, 8); });
  client.on('guildMemberAdd', member => { v10.security.recordMemberJoin(member); });
  client.on('webhookUpdate', channel => { if (v10.security.enabled('antiWebhookAbuse')) void v10.security.logger.warn('Webhook update detected', { guildId: channel?.guild?.id, channelId: channel?.id }); });

  client.on('error', error => { void appLogger.error('Discord client error',{error:error?.message||String(error)}); console.error('[Discord]', error?.stack || error?.message || error); });
  client.on('warn', warning => console.warn('[Discord]', warning));

  client.login(DISCORD_TOKEN).then(() => payment.start().catch(error => console.error('[Payment startup]', error))).catch(error => {
    console.error('[Discord login]', error?.stack || error?.message || error);
  });
} else if (IS_DISCORD_ROLE) {
  console.error('[Discord] Thiếu DISCORD_TOKEN, Discord service không thể khởi động.');
}

const shutdown = async (signal) => {
  void appLogger.info('Shutdown requested',{signal});
  try { await global.discordClient?.v10?.stop?.(); } catch {}
  try { systemManager.stop(); } catch {}
  try { await global.discordClient?.paymentService?.shutdown?.(); } catch {}
  try { localMcBot?.clearAllTimers?.(); } catch {}
  try { localMcBot?.stop?.(signal); } catch {}
  try { if (global.discordClient) await global.discordClient.destroy(); } catch {}
  try { server.close(); } catch {}
  setTimeout(() => process.exit(0), 250).unref?.();
};
for (const signal of ['SIGTERM','SIGINT']) process.once(signal, () => void shutdown(signal));
