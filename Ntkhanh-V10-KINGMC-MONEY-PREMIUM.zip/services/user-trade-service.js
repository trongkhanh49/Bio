'use strict';
const path = require('path');
const store = require('../payment/store');
const { formatAmount } = require('../payment/amount-parser');
const { StructuredLogger } = require('../core/logger');

class UserTradeService {
  constructor() {
    this.logger = new StructuredLogger({ name: 'user-trades', dir: path.join(process.cwd(), 'data', 'logs') });
  }

  normalize(order) {
    const direction = order?.type === 'thu' ? 'sold_to_bot' : order?.type === 'ban' ? 'bought_from_bot' : null;
    return {
      id: String(order?.id || ''),
      direction,
      status: String(order?.status || 'unknown'),
      player: String(order?.player || ''),
      amount: Number(order?.amount || 0),
      vnd: Number(order?.vnd || 0),
      rate: Number(order?.rt || order?.rate || 0),
      createdAt: order?.createdAt || null,
      updatedAt: order?.updatedAt || null,
      completedAt: order?.completedAt || order?.bankCompletedAt || order?.gameReceivedAt || null,
      channelId: order?.channelId || null,
      guildId: order?.guildId || null,
      bankReceivedAt: order?.bankReceivedAt || null,
      gameReceivedAt: order?.gameReceivedAt || null,
      gamePaidAt: order?.gamePaidAt || null,
      userId: String(order?.discordId || '')
    };
  }

  listForUser(userId) {
    const id = String(userId || '');
    return store.all().filter(o => String(o?.discordId || '') === id && (o.type === 'thu' || o.type === 'ban')).map(o => this.normalize(o));
  }

  sold(userId) { return this.listForUser(userId).filter(o => o.direction === 'sold_to_bot'); }
  bought(userId) { return this.listForUser(userId).filter(o => o.direction === 'bought_from_bot'); }

  summary(userId) {
    const sold = this.sold(userId);
    const bought = this.bought(userId);
    return {
      soldCount: sold.length,
      boughtCount: bought.length,
      soldCompleted: sold.filter(o => o.status === 'completed').length,
      boughtCompleted: bought.filter(o => o.status === 'completed').length,
      soldMoney: sold.filter(o => o.status === 'completed').reduce((s, o) => s + o.amount, 0),
      boughtMoney: bought.filter(o => o.status === 'completed').reduce((s, o) => s + o.amount, 0),
      soldVnd: sold.filter(o => o.status === 'completed').reduce((s, o) => s + o.vnd, 0),
      boughtVnd: bought.filter(o => o.status === 'completed').reduce((s, o) => s + o.vnd, 0),
      active: [...sold, ...bought].filter(o => !['completed', 'cancelled', 'pay_failed'].includes(o.status))
    };
  }

  formatRows(rows, limit = 12) {
    return rows.slice(0, limit).map((o, index) => {
      const date = o.createdAt ? `<t:${Math.floor(new Date(o.createdAt).getTime() / 1000)}:d>` : 'N/A';
      return `${index + 1}. **${o.id}** • ${formatAmount(o.amount)} Money • ${Number(o.vnd || 0).toLocaleString('vi-VN')}đ • **${o.status}** • ${date}`;
    }).join('\n') || 'Chưa có giao dịch.';
  }

  audit(userId, action, meta = {}) { return this.logger.info(`User trade view: ${action}`, { userId: String(userId), ...meta }); }
}

module.exports = { UserTradeService };
